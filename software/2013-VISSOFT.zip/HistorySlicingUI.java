package edu.uci.ics.cmi.HistorySlicing;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.apache.batik.bridge.UpdateManager;
import org.apache.batik.dom.svg.SVGDOMImplementation;
import org.apache.batik.dom.util.DOMUtilities;
import org.apache.batik.swing.JSVGCanvas;
import org.apache.batik.util.SVGConstants;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.svg.SVGDocument;

import edu.uci.ics.cmi.HistorySlicing.io.HistorySlicingDB;
import edu.uci.ics.cmi.HistorySlicing.model.HistorySlice;
import edu.uci.ics.cmi.HistorySlicing.model.HistorySlicingSeed;
import edu.uci.ics.cmi.HistorySlicing.workers.HistorySlicer;
import edu.uci.ics.cmi.SourceCodeRepository.model.CodeRepository;
import edu.uci.ics.cmi.SourceCodeRepository.model.CodeRepositoryCvs;
import edu.uci.ics.cmi.SourceCodeRepository.parser.CodeRepositoryParser;
import edu.uci.ics.cmi.SourceCodeRepository.parser.CodeRepositoryParserCvs;
import edu.uci.ics.cmi.io.FileAccess;
import edu.uci.ics.cmi.io.xml.XmlInterpreter;

public class HistorySlicingUI extends JFrame implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// Namespace string, to be used throughout the class
	protected final String svgNS =
			SVGDOMImplementation.SVG_NAMESPACE_URI;

	// Swing components
	protected JTextField txtInput = new JTextField(30);
//	protected JButton btnDisplay = new JButton ("Display");
//	protected JButton btnOpenFile = new JButton ("Load SVG...");

	protected JButton btnOpenSlice = new JButton ("Load Slice...");
	protected JButton btnSaveSlice = new JButton ("Save Slice...");

	protected JButton btnSave = new JButton ("Save SVG...");
	
	protected JButton btnLoadSeed = new JButton ("Load seed...");
	protected JButton btnLoadConfiguration = new JButton ("Load configuration...");
	
	protected JSVGCanvas canvas = new JSVGCanvas ();

	// File Chooser to name and place the file being saved
	// in a file system
	JFileChooser fcSave = new JFileChooser();
    // A file chooser
    private JFileChooser fcOpenFile = new JFileChooser();

	// The document to contain the text
	protected Document document;

	// A reference to the <text> element of our SVG document
//	protected Element textElement;

	
	protected FileAccess fileAccess;
	protected String configurationFile;

	protected Timestamp minDate;
	protected Timestamp maxDate;
	
    protected HistorySlice slice;
	protected HistorySlicingSeed seed;
	
	public void setSeed(HistorySlicingSeed seed) {
		this.seed = seed;
	}

	// Constructor
	public HistorySlicingUI (String appName) {
		// Everything is as usual here
		super ("History Slicer");
		this.setDefaultCloseOperation (JFrame.DISPOSE_ON_CLOSE);
		JPanel panel = new JPanel ();
		JPanel p = new JPanel ();

//		btnDisplay.addActionListener (this);
//		btnOpenFile.addActionListener (this);

		btnOpenSlice.addActionListener (this);
		btnSaveSlice.addActionListener (this);

		btnSave.addActionListener (this);
		
		btnLoadSeed.addActionListener(this);
		btnLoadConfiguration.addActionListener(this);

		canvas.setMySize (new Dimension (1500, 500));

		// The following line is needed for our canvas to react
		// on every change of the document associated with it
		canvas.setDocumentState (JSVGCanvas.ALWAYS_DYNAMIC);

//		p.add (txtInput);
//		p.add (btnDisplay);
//		p.add (btnOpenFile);

// UNCOMMENT THIS TO SHOW BUTTONS!!
//		p.add (btnOpenSlice);
//		p.add (btnSaveSlice);
//
		p.add (btnSave);
//		
//		p.add (btnLoadConfiguration);
//		p.add (btnLoadSeed);
//
		panel.setLayout (new BorderLayout () );
		panel.add ("North", p);
		panel.add ("Center", canvas);
		this.setContentPane (panel);
		this.pack ();
		this.setBounds (150, 150, this.getWidth (),
				this.getHeight () );

		// Creating the SVG document
		DOMImplementation dom =
				SVGDOMImplementation.getDOMImplementation ();
		document = dom.createDocument (svgNS, "svg", null);

		// Finally, the document is associated with the canvas
		canvas.setDocument (document);
		
		
		

		
		this.fileAccess = new FileAccess();
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date dateTemp = null;
		
		try {
			dateTemp = dateFormat.parse("2002-12-01 00:00:00");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		minDate = new Timestamp(dateTemp.getTime());
		
		try {
			dateTemp = dateFormat.parse("2011-06-01 00:00:00");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		maxDate = new Timestamp(dateTemp.getTime());
		
		this.configurationFile = "/Users/fservant/Documents/uci/2011-2012/workspaces/workspace/HistorySlicing/resources/HistorySlicing.properties";
		this.seed = new HistorySlicingSeed();		
		
	}

	// The entry point of the application
	public static void main (String[] args) {
		HistorySlicingUI writer = new HistorySlicingUI ("SVG Writer");
		
		
		writer.setVisible (true);
	}

	public void actionPerformed (ActionEvent ae) {

		// We might add more buttons later,
		// so let's do everything properly
		Object source = ae.getSource ();
//		if (source == btnDisplay) {
//			drawText (txtInput.getText () );
//		}

		if (source == btnSaveSlice) {
			// Show dialog to choose where and under which
			// name to save the file
			int returnVal = fcSave.showSaveDialog(this);

			// If button "Save" was pressed (not "Cancel")
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				// Get the file path and pass it to the method
				// that will perform saving
				File file = fcSave.getSelectedFile();
				try {
					saveSlice(slice, file.getPath());
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		if (source == btnSave) {
			// Show dialog to choose where and under which
			// name to save the file
			int returnVal = fcSave.showSaveDialog(this);

			// If button "Save" was pressed (not "Cancel")
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				// Get the file path and pass it to the method
				// that will perform saving
				File file = fcSave.getSelectedFile();
				saveToFile(file.getPath());
			}
		}

//		
//        if (source == btnOpenFile) {
//            int returnVal = fcOpenFile.showOpenDialog (this);
//            try {
//                // If after choosing a file the "Open" button
//                // was pressed
//                if (returnVal == JFileChooser.APPROVE_OPTION) {
//                    File file = fcOpenFile. getSelectedFile();
//                    canvas.setURI (file.toURL() .toString() );
//                }
//            } catch (IOException ioe) {
//                System.err.print (ioe.toString());
//            }
//        }
		
      if (source == btnOpenSlice) {
          int returnVal = fcOpenFile.showOpenDialog (this);
          // If after choosing a file the "Open" button
		  // was pressed
		  if (returnVal == JFileChooser.APPROVE_OPTION) {
		      File file = fcOpenFile. getSelectedFile();

		      HistorySlice slice = null;
		      try {
		    	  slice = (HistorySlice) fileAccess.readXmlObject(file.getPath());
		      } catch (IOException e) {
		    	  e.printStackTrace();
		      }
		      
		      drawSlice(slice);
		  }
      }
		
        if (source == btnLoadConfiguration) {
            int returnVal = fcOpenFile.showOpenDialog (this);
            // If after choosing a file the "Open" button
			// was pressed
			if (returnVal == JFileChooser.APPROVE_OPTION) {
			    File file = fcOpenFile.getSelectedFile();
			    this.configurationFile = file.getPath();
			}
        }
		
        if (source == btnLoadSeed) {
            
        	if (configurationFile == null)
        	{
        		JOptionPane.showMessageDialog(btnLoadSeed, "Please, open a configuration file first.");
        		return;
        	}
        	
        	int returnVal = fcOpenFile.showOpenDialog (this);
            // If after choosing a file the "Open" button
			// was pressed
			if (returnVal == JFileChooser.APPROVE_OPTION) {
			    File file = fcOpenFile.getSelectedFile();
			    
			    try {
					slice = performSlice(file.getPath());
				} catch (IOException e) {
					e.printStackTrace();
				} catch (ParseException e) {
					e.printStackTrace();
				} catch (SQLException e) {
					e.printStackTrace();
				} catch (InstantiationException e) {
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				}
			    
			    drawSlice(slice);
			}
        }
	
	}
	
	public void clearSeed()
	{
		seed = new HistorySlicingSeed();
	}
	
	public void addToSeed(String fileName, String revision, Integer [] seedLines)
	{
		seed.add(fileName, revision, seedLines);
	}
	
	public void performAndDisplaySlice() throws IOException, ParseException, SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException
	{
		double start = System.nanoTime();

		HistorySlice slice = performSlice(seed);

		double elapsed = (System.nanoTime() - start) * 1.0e-9;
		System.out.println("performSlice(seed) [" + elapsed  + " secs.]");
		start = System.nanoTime();
		
		drawSlice(slice);
		
		elapsed = (System.nanoTime() - start) * 1.0e-9;
		System.out.println("drawSlice(slice) [" + elapsed  + " secs.]");
	}
	
	protected HistorySlice performSlice() throws IOException, ParseException, SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException
	{
		return performSlice(seed);
	}
	
	protected HistorySlice performSlice(String seedFile) throws IOException, ParseException, SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException
	{
        HistorySlicingSeed seed = (HistorySlicingSeed) fileAccess.readXmlObject(seedFile);
		return performSlice(seed);
	}
	
	protected HistorySlice performSlice(HistorySlicingSeed seed) throws IOException, ParseException, SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException
	{
		double start = System.nanoTime();

		HistorySlicingDB db = new HistorySlicingDB(configurationFile);
		CodeRepository codeRepository = new CodeRepositoryCvs(configurationFile);
		CodeRepositoryParser codeRepositoryParser = new CodeRepositoryParserCvs();
		
		HistorySlicer slicer = new HistorySlicer(db, codeRepository, codeRepositoryParser, seed);

		double elapsed = (System.nanoTime() - start) * 1.0e-9;
		System.out.println("Initialize performSlice(seed) [" + elapsed  + " secs.]");
		start = System.nanoTime();
		
		slicer.execute();

		elapsed = (System.nanoTime() - start) * 1.0e-9;
		System.out.println("slicer.execute() [" + elapsed  + " secs.]");
		start = System.nanoTime();

		return slicer.getSlice();
	}
	
	protected void drawSlice(final HistorySlice slice)
	{
		if (slice == null)
			return;
		
		Runnable r = new HistorySlicingUIBuilder(document, svgNS, slice, minDate, maxDate);
		
		// Running our code in the UpdateManager thread
		UpdateManager um = canvas.getUpdateManager ();
		um.getUpdateRunnableQueue () .invokeLater (r);
	}

	private void saveSlice(HistorySlice slice, String file) throws IOException {

		if (slice == null)
			return;

		XmlInterpreter serializer = new XmlInterpreter();
		String serialized = serializer.toXML(slice);

		fileAccess.writeToFile(serialized, file);
	}

	// Saving SVG document to the specified file in the
	// filesystem
	private void saveToFile (String file) {
	    try {
	        FileWriter f = new FileWriter (file);
	        PrintWriter writer = new PrintWriter(f);
	        writer.write(
	                "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n");
	        writer.write ("<!DOCTYPE svg PUBLIC '");
	        writer.write (SVGConstants.SVG_PUBLIC_ID);
	        writer.write ("' '");
	        writer.write (SVGConstants.SVG_SYSTEM_ID);
	        writer.write ("'>\n\n");
	        SVGDocument svgDoc = canvas.getSVGDocument();
	        DOMUtilities.writeDocument (svgDoc, writer);
	        writer.close();
	    } catch (IOException ioe) {
	        System.err.println("10 problem: " + ioe.toString() );
	    }
	}
}