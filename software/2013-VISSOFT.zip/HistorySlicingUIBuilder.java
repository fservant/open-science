package edu.uci.ics.cmi.HistorySlicing;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;
import org.w3c.dom.events.Event;
import org.w3c.dom.events.EventListener;
import org.w3c.dom.events.EventTarget;
import org.w3c.dom.svg.SVGLocatable;
import org.w3c.dom.svg.SVGRect;

import edu.uci.ics.cmi.HistorySlicing.model.HistorySlice;
import edu.uci.ics.cmi.SourceCodeRepository.model.Commit;
import edu.uci.ics.cmi.SourceCodeRepository.model.Operation;

public class HistorySlicingUIBuilder implements Runnable {

	protected Document document;
	protected String svgNS;
	protected HistorySlice slice;
	protected Timestamp minDate;
	protected Timestamp maxDate;
	
	protected String colorFileName = "darkgreen";
	protected String colorMetaData = "darkgreen";

	protected String colorText = "dimgray";
	protected String colorHighlightedText = "blue";

	protected String colorTimeline = "whitesmoke";
	protected String colorHighlightedTimeline = "blue";
	protected String colorRulerDates = "grey";

	protected String colorMouseOverTimeline = "chocolate";

	protected String idFileName = "fileName";
	protected String idMetaData = "metaData";
	protected String idOperation = "operation";
	protected String idSnapshot = "snapshot";
	protected String idRulerDate = "rulerDate";
	protected String idRulerNotch = "rulerNotch";
	protected String idGlobalTimeline = "globalTimeline";
	protected String idTimelineBackground = "timeLineBackground";
	protected String idTimelineNotch = "timeLineNotch";
	protected String idTimelineConnectorUp = "timelineConnectorUp";
	protected String idTimelineConnectorStraight = "timelineConnectorStraight";
	protected String idTimelineConnectorDown = "timelineConnectorDown";
	protected String idFloatingMetaData = "floatingMetaData";
	
	protected float fontSize;
	
	
	public HistorySlicingUIBuilder(Document document, String svgNS, HistorySlice slice, Timestamp minDate, Timestamp maxDate) {
		super();
		this.document = document;
		this.svgNS = svgNS;
		this.slice = slice;
		this.minDate = minDate;
		this.maxDate = maxDate;	
	}

	public void run () {

		ArrayList<ArrayList<Element>> textLines = new ArrayList<ArrayList<Element>>();
		ArrayList<ArrayList<Float>> xSnapshots = new ArrayList<ArrayList<Float>>();
		ArrayList<Element> timeLine;
		
		Element textLine;
		SVGRect elementBox;
		
		// Start by setting the margins and font size
		fontSize = 0.6f;
		
		float xMargin = 10 * fontSize;
		float yMargin = 10 * fontSize;
		
		float x = xMargin;
		float y = 0;
		
		float highestX = 0; 
		
		// Start displaying the history slice
		String line = new String();
		for (int i = 0; i < slice.getNumberOfFiles(); i++)
		{
			textLines.add(new ArrayList<Element>());
			
			// Print file name
			line = slice.getFileName(i);
			textLine = createTextLine(x, y, fontSize, line, colorFileName, idFileName + "-" + i);
			textLines.get(i).add(textLine);
			displayElement(textLine);

			elementBox = measureElement(textLine);
			y += elementBox.getHeight();
			
			float xSnapshot = x;
			float ySnapshot = y;

			xSnapshots.add(new ArrayList<Float>());
			for (int j = 0; j < slice.getNumberOfCommits(i); j++)
			{
				float highestXSnapshot = 0;

				xSnapshots.get(i).add(xSnapshot);
				
				// Print information about commit
				line = buildMetaDataLine(slice.getCommit(i, j));
				textLine = createTextLine(xSnapshot, ySnapshot, fontSize, line, colorMetaData, idMetaData + "-" + i + "-" + j);
				textLines.get(i).add(textLine);
				displayElement(textLine);

				elementBox = measureElement(textLine);
				ySnapshot += elementBox.getHeight();

				if (highestXSnapshot < (xSnapshot + elementBox.getWidth()))
					highestXSnapshot = (xSnapshot + elementBox.getWidth());
				
				for (int k = 0; k < slice.getSnapshotSize(i, j); k++)
				{
					float operationWidth = 0;
					
					// If there was actually a change at this line
					if (slice.getChange(i, j, k) != null)
					{
						String color = colorText;
						
						if (slice.getChange(i, j, k).getOperation() != Operation.UNCHANGED)
							color = colorHighlightedText;

						// Print snapshot operation
						line = slice.getChange(i, j, k).getNewLine().toString();// + " " + slice.getChange(i, j, k).getOperation().toString();
						Element textLineOperation = createTextLine(xSnapshot, ySnapshot, fontSize, line, color, idOperation + "-" + i + "-" + j + "-" + k);
						textLines.get(i).add(textLineOperation);
						displayElement(textLineOperation);

						SVGRect elementOperationBox = measureElement(textLineOperation);
						operationWidth = elementOperationBox.getWidth();

						
						// Print snapshot line
						line = slice.getContents(i, j, k);
						if (line.trim().length() > 0)
						{
							textLine = createTextLine(xSnapshot + operationWidth, ySnapshot, fontSize, line, color, idSnapshot + "-" + i + "-" + j + "-" + k);
							textLines.get(i).add(textLine);
							displayElement(textLine);

							elementBox = measureElement(textLine);
							if (highestXSnapshot < (xSnapshot + operationWidth + elementBox.getWidth()))
								highestXSnapshot = (xSnapshot + operationWidth + elementBox.getWidth());
						}

//						if (slice.getChange(i, j, k).getOperation() != Operation.UNCHANGED)
//						{
//							Element background = createSquare(elementOperationBox.getX(), elementBox.getX() + elementBox.getWidth(), elementBox.getY(), elementBox.getY() + elementBox.getHeight(), "lightyellow");
//							textLines.get(i).add(background);
//
//							hideElement(textLineOperation);
//							hideElement(textLine);
//							displayElement(background);
//							displayElement(textLineOperation);
//							displayElement(textLine);
//						}

					}

					// Jump to the next line
					ySnapshot += elementBox.getHeight();
				}
				
				xSnapshot = xMargin + highestXSnapshot;
				ySnapshot = y;
			}

			elementBox = measureElement(textLines.get(i).get(textLines.get(i).size() - 1));
			y = elementBox.getY() + elementBox.getHeight() + yMargin;

			// Calculate longest file slice for time line
			if (highestX < (xSnapshot - xMargin))
				highestX = (xSnapshot - xMargin);
		}
		
		
		
		
		// Draw global time line
		y = yMargin;
		timeLine = createGlobalTimeLine(x, highestX, y, y + fontSize, minDate, maxDate, slice);

		elementBox = measureElement(timeLine.get(timeLine.size() - 1));
		y = elementBox.getY() + elementBox.getHeight();

		// Add margin
		y += yMargin;

		// Draw local time lines and move snapshot lines around
		for (int i = 0; i < slice.getNumberOfFiles(); i++)
		{
			float yLine = Float.parseFloat(textLines.get(i).get(0).getAttributeNS(null, "y"));
			yLine += y;
			textLines.get(i).get(0).setAttributeNS (null, "y", Float.toString(yLine));
			
			y += fontSize;	// Add small margin
			float yBeforeTimeLine = yLine + measureElement(textLines.get(i).get(0)).getHeight() + fontSize;

			timeLine = createTimeLineWithRuler(x, highestX, yBeforeTimeLine, yBeforeTimeLine + fontSize, minDate, maxDate, slice.getCommits(i), xSnapshots.get(i), i);
			
			elementBox = measureElement(timeLine.get(timeLine.size() - 1));

			float yAfterTimeLine = elementBox.getY() + elementBox.getHeight();

			float heightTimeLine = yAfterTimeLine - yBeforeTimeLine;
			y += heightTimeLine;
			
			for (int j = 1; j < textLines.get(i).size(); j++)
			{
				yLine = Float.parseFloat(textLines.get(i).get(j).getAttributeNS(null, "y"));
				yLine += y + fontSize;
				textLines.get(i).get(j).setAttributeNS (null, "y", Float.toString(yLine));
			}
		}
		
	}
	
	private String buildMetaDataLine(Commit commit) 
	{
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		String revisionDate = dateFormat.format(commit.getDate());
		
		return "rv" + commit.getRevision() + " (" + revisionDate + "). Author: " + commit.getAuthor();
	}

	protected ArrayList<Element> createGlobalTimeLine (float x1, float x2, float y1, float y2, Timestamp minDate, Timestamp maxDate, HistorySlice slice)
	{
		ArrayList<Element> elements = new ArrayList<Element>();
		float height = y2 - y1;

		ArrayList<Element> rulerElements = createTimeRuler(x1, x2, y1, y1 + height, minDate, maxDate, idGlobalTimeline);
		elements.addAll(rulerElements);
		
		SVGRect lastElementBox = measureElement(rulerElements.get(rulerElements.size() - 1));
		y1 = lastElementBox.getY() + lastElementBox.getHeight();

		for (int i = 0; i < slice.getNumberOfFiles(); i++)
		{
			ArrayList<Element> timeLineElements = createTimeLine(x1, x2, y1, y1 + height, minDate, maxDate, slice.getCommits(i), null, idGlobalTimeline + "-" + i);
			elements.addAll(timeLineElements);
			
			SVGRect box = measureElement(timeLineElements.get(timeLineElements.size() - 1));
			y1 += box.getHeight() + box.getHeight() / 5;
		}
		
		return elements;
	}
	
	protected ArrayList<Element> createTimeLineWithRuler(float x1, float x2, float y1, float y2, Timestamp minDate, Timestamp maxDate, List<Commit> positions, ArrayList<Float> xSnapshots, int i)
	{
		ArrayList<Element> elements = new ArrayList<Element>();
		float height = y2 - y1;

		ArrayList<Element> rulerElements = createTimeRuler(x1, x2, y1, y1 + height, minDate, maxDate, Integer.toString(i));
		elements.addAll(rulerElements);
		
		SVGRect lastElementBox = measureElement(rulerElements.get(rulerElements.size() - 1));
		y1 = lastElementBox.getY() + lastElementBox.getHeight();

		ArrayList<Element> timeLineElements = createTimeLine(x1, x2, y1, y1 + height, minDate, maxDate, positions, xSnapshots, Integer.toString(i));
		elements.addAll(timeLineElements);

		return elements;
	}

//	protected ArrayList<Element> createTimeRuler (float x1, float x2, float y1, float y2, Timestamp minDate, Timestamp maxDate)
//	{
//		ArrayList<Element> elements = new ArrayList<Element>();
//
//		float height = y2 - y1;
//		Element dateTemp = createTextLine(x1, y1, height, "88-88-8888", "black");
//		displayElement(dateTemp);
//		
//		float dateWidth = measureElement(dateTemp).getWidth();
//		hideElement(dateTemp);
//		
//		float stepRuler = 2 * dateWidth;
//		float stepsRuler = (x2 - x1) / stepRuler;
//		long stepRulerTime = (long) ((maxDate.getTime() - minDate.getTime()) / stepsRuler);
//		float stepDay = (x2 - x1) / daysBetween(minDate, maxDate);
//
//		float x = x1;
//		Timestamp t = new Timestamp(minDate.getTime());
//		while (x < x2)
//		{
//			DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");
//			String dateString = dateFormat.format(t);
//
//			Element date = createTextLine(x, y1, height, dateString, colorRulerDates);
//			elements.add(date);
//			displayElement(date);
//
//			float yRuler = y1 + measureElement(date).getHeight();
//			Element ruler = createSquare(x, x + stepDay, yRuler, yRuler + height, colorRulerDates);
//			elements.add(ruler);
//			displayElement(ruler);
//			
//			x += stepRuler;
//			t.setTime(t.getTime() + stepRulerTime);
//		}
//
//		return elements;
//	}
	
	protected ArrayList<Element> createTimeRuler (float x1, float x2, float y1, float y2, Timestamp minDate, Timestamp maxDate, String id)
	{
		ArrayList<Element> elements = new ArrayList<Element>();

		float height = y2 - y1;
		
		float stepDay = (x2 - x1) / daysBetween(minDate, maxDate);

		float x = x1;
		Calendar t = new GregorianCalendar();
		t.setTimeInMillis(minDate.getTime());
		int i = 0;
		while (x < x2)
		{
			DateFormat dateFormat = new SimpleDateFormat("MM/yy");
			String dateString = dateFormat.format(t.getTime());

			Element date = createTextLine(x, y1, height, dateString, colorRulerDates, idRulerDate + "-" + id + "-" + i);
			elements.add(date);
			displayElement(date);

			float yRuler = y1 + measureElement(date).getHeight();

			Element ruler = createSquare(x, x + stepDay, yRuler, yRuler + height, colorRulerDates, idRulerNotch + "-" + id + "-" + i);
			elements.add(ruler);
			displayElement(ruler);
			
			t.add(Calendar.MONTH, 1);
			Timestamp now = new Timestamp(t.getTimeInMillis());
			
			x = x1 + daysBetween(minDate, now) * stepDay;
			i++;
		}

		return elements;
	}

//	protected ArrayList<Element> createTimeLine(float x1, float x2, float y1, float y2, Timestamp minDate, Timestamp maxDate, List<Commit> positions, String id)
//	{
//		ArrayList<Element> elements = new ArrayList<Element>();
//		float height = 6 * (y2 - y1);
//
//		// Draw time line first
//		Element timeLine = createSquare(x1, x2, y1, y1 + height, colorTimeline, idTimelineBackground + "-" + id);
//		elements.add(timeLine);
//		displayElement(timeLine);
//
//		float stepDay = (x2 - x1) / daysBetween(minDate, maxDate);
//	
//		// Draw positions in time line for commits
//		for (int i = 0; i < positions.size(); i++)
//		{
//			Timestamp commitDate = positions.get(i).getDate();
//			float commitPos = daysBetween(minDate, commitDate) * stepDay;
//
//			Element change = createSquare(x1 + commitPos, x1 + commitPos + stepDay, y1, y1 + height, colorHighlightedTimeline, idTimelineNotch + "-" + id + "-" + i);
//			elements.add(change);
//			displayElement(change);
//		}
//
//		return elements;
//	}

	protected ArrayList<Element> createTimeLine(float x1, float x2, float y1, float y2, Timestamp minDate, Timestamp maxDate, List<Commit> positions, ArrayList<Float> xSnapshots, String id)
	{
		ArrayList<Element> elements = new ArrayList<Element>();
		float height = 6 * (y2 - y1);

		// Draw time line first
		Element timeLine = createSquare(x1, x2, y1, y1 + height, colorTimeline, idTimelineBackground + "-" + id);
		elements.add(timeLine);
		displayElement(timeLine);

		float stepDay = (x2 - x1) / daysBetween(minDate, maxDate);

		int linesLeft = 0;
		int linesRight = 0;
		int totalLines = 0;
		
		if (xSnapshots != null)
		{
			// Calculate how may lines go left. The rest go right
			for (int i = 0; i < positions.size(); i++)
			{
				Timestamp commitDate = positions.get(i).getDate();
				float commitPos = daysBetween(minDate, commitDate) * stepDay;

				if ( xSnapshots.get(i) < (x1 + commitPos) )
					linesLeft++;
				else
					linesRight++;
			}

			if (linesLeft < linesRight)
				totalLines = (linesRight + 1) * 2;
			else
				totalLines = (linesLeft + 1) * 2;
		}
		
		
		linesLeft = 0;
		linesRight = 0;

		// Draw positions in time line for commits
		for (int i = 0; i < positions.size(); i++)
		{
			Timestamp commitDate = positions.get(i).getDate();
			float commitPos = daysBetween(minDate, commitDate) * stepDay;

			Element change = createSquare(x1 + commitPos, x1 + commitPos + stepDay, y1, y1 + height, colorHighlightedTimeline, idTimelineNotch + "-" + id + "-" + i);
			elements.add(change);
			displayElement(change);
			registerListeners(change);
			
			if (xSnapshots != null)
			{
				// Draw lines that join commits in timeline to snapshots
				float stepLine = (height / 20);
				int lines;
				float straightLeft;
				float straightRight;
				if ( xSnapshots.get(i) < (x1 + commitPos) )
				{
					linesLeft++;
					lines = linesLeft * 2;

					straightLeft = xSnapshots.get(i);
					straightRight = x1 + commitPos + stepDay;
				}
				else
				{
					linesRight++;
					lines = totalLines - linesRight * 2;

					straightLeft = x1 + commitPos;
					straightRight = xSnapshots.get(i);
				}

				Element changeDown = createSquare(x1 + commitPos, x1 + commitPos + stepDay, y1 + height, y1 + height + stepLine * lines, colorHighlightedTimeline, idTimelineConnectorDown + "-" + id + "-" + i);
				elements.add(changeDown);
				displayElement(changeDown);
				registerListeners(changeDown);

				Element changeStraight = createSquare(straightLeft, straightRight, y1 + height + stepLine * lines, y1 + height + stepLine * (lines + 1), colorHighlightedTimeline, idTimelineConnectorStraight + "-" + id + "-" + i);
				elements.add(changeStraight);
				displayElement(changeStraight);
				registerListeners(changeStraight);

				Element changeUp = createSquare(xSnapshots.get(i), xSnapshots.get(i) + stepDay, y1 + height + stepLine * lines, y1 + height + stepLine * totalLines, colorHighlightedTimeline, idTimelineConnectorUp + "-" + id + "-" + i);
				elements.add(changeUp);
				displayElement(changeUp);
				registerListeners(changeUp);
			}
		}
		
		return elements;
	}
	
	protected Element createTextLine(float x, float y, float fontSize, String txt, String color, String id)
	{
		if (txt == null)
			return null;
		
		if (txt.trim().length() < 1)
			return null;
		
		// Pre-process tabs composed of spaces
		txt = txt.replaceAll("    ", "\t");
		
		// Pre-process tabs
		for (int i = 0; (i < txt.length()); i++)
			if (txt.charAt(i) == '\t')
				x += fontSize; 
			else
				break;
		txt = txt.trim();
		
		// Create the <text> element
		Element textElement = document.createElementNS (svgNS, "text");

		// Create the text node with the text
		// that will become the content of the <text>
		// element
		Text text = document.createTextNode (txt);
		textElement.appendChild (text);

		// Set the attributes of the <text> element
		textElement.setAttributeNS (null, "x", Double.toString(x));
		textElement.setAttributeNS (null, "y", Double.toString(y));
		textElement.setAttributeNS (null, "font-family", "Verdana, Arial, sans-serif");
		textElement.setAttributeNS (null, "font-size", Double.toString(fontSize));
		// Notice that we set the font color here
		textElement.setAttributeNS (null, "fill", color);
	    if (id != null)
	    	textElement.setAttributeNS (null, "id", id);

//		displayElement(textElement);

		return textElement;
	}
	
	protected Element createSquare(float x1, float x2, float y1, float y2, String color, String id)
	{
		Element square = document.createElementNS (svgNS, "rect");
	    square.setAttributeNS (null, "fill", color);
//	    square.setAttributeNS (null, "stroke", "indigo");
//	    square.setAttributeNS (null, "stroke-width", "5");
	    square.setAttributeNS (null, "width", Double.toString(x2 - x1));
	    square.setAttributeNS (null, "height", Double.toString(y2 - y1));
	    square.setAttributeNS (null, "x", Double.toString(x1));
	    square.setAttributeNS (null, "y", Double.toString(y1));
	    if (id != null)
	    	square.setAttributeNS (null, "id", id);
	
		return square;
	}

	protected void displayElement(Element element)
	{
		// Get a reference to the <svg> element of the
		// document
		Element root = document.getDocumentElement ();

		// And finally, the new element is appended to the
		// root
		root.appendChild (element);
	}
	
	protected void hideElements(ArrayList<Element> elements)
	{
		for (Element element: elements)
			hideElement(element);
	}
	
	protected void hideElement(Element element)
	{
		// Get a reference to the <svg> element of the
		// document
		Element root = document.getDocumentElement ();

		// And finally, the new element is appended to the
		// root
		root.removeChild(element);
	}
	
	protected SVGRect measureElement(Element element)
	{
		return ((SVGLocatable) element).getBBox();
	}
	
	protected float daysBetween(Timestamp older, Timestamp newer)
	{
		return (newer.getTime() - older.getTime()) / (24 * 60 * 60 * 1000);
	}
	
//	protected float monthsBetween(Timestamp older, Timestamp newer)
//	{
//		int monthCount=0;
//		Calendar cal = Calendar.getInstance();
//		
//		cal.setTimeInMillis(older.getTime());
//		int c1date=cal.get(Calendar.DATE);
//		int c1month=cal.get(Calendar.MONTH);
//		int c1year=cal.get(Calendar.YEAR);
//		
//		cal.setTimeInMillis(newer.getTime());
//		int c2date=cal.get(Calendar.DATE);
//		int c2month=cal.get(Calendar.MONTH);
//		int c2year=cal.get(Calendar.YEAR);
//
//		monthCount = ((c2year-c1year)*12) + (c2month-c1month) + ((c2date>=c1date)?1:0);
//
//		return monthCount;
//	}
	
	protected void registerListeners(Element element)
	{
		// Add a listener for the 'mouseover' event
		((EventTarget) element).addEventListener ("mouseover", new OnMouseAction (element.getAttributeNS(null, "id")), false);

		// Add a listener for the 'mouseout' event
		((EventTarget) element).addEventListener ("mouseout", new OnMouseAction (element.getAttributeNS(null, "id")), false);
	}

	
	public class OnMouseAction implements EventListener {
		protected String id;
		
		public OnMouseAction (String id)
		{
			this.id = id;
		}
		
		public void handleEvent (Event evt) {
			
			String[] tokens = id.split("-");
			
			String fileId = tokens[tokens.length - 2];
			String commitId = tokens[tokens.length - 1];
			
			String suffix = "-" + fileId + "-" + commitId;

			String color = new String();

			String [] prefixesMetadata = {idTimelineNotch + "-" + idGlobalTimeline, idTimelineNotch};
			for (String prefix: prefixesMetadata)
			{
				if (evt.getType() == "mouseover")
				{
					color = colorMouseOverTimeline;

					Element elt = document.getElementById (prefix + suffix);
					SVGRect place = measureElement(elt);
					
					float x = place.getX() + 2 * place.getWidth();
					float y = place.getY() + place.getHeight() * 9 / 10;
					
					String line = buildMetaDataLine(slice.getCommit(Integer.parseInt(fileId), Integer.parseInt(commitId)));
					Element textLine = createTextLine(x, y, fontSize, line, color, idFloatingMetaData + "-" + prefix + suffix);
					displayElement(textLine);
				}

				if (evt.getType() == "mouseout")
				{
					color = colorMouseOverTimeline;//colorHighlightedTimeline;
					
//					hideElement(document.getElementById (idFloatingMetaData + "-" + prefix + suffix));
				}

			}

			String [] prefixes = {idTimelineNotch + "-" + idGlobalTimeline, idTimelineNotch, idTimelineConnectorUp, idTimelineConnectorStraight, idTimelineConnectorDown};

			for (String prefix: prefixes)
			{
				Element elt = document.getElementById (prefix + suffix);
				if (elt != null)
					elt.setAttribute ("fill", color);
			}
			
			
		}
	}

	
}
