package edu.uci.ics.cmi.ExpertiseFinding.algorithms.fault;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

import edu.uci.ics.cmi.ExpertiseFinding.algorithms.ExpertiseFindingAlgorithm;
import edu.uci.ics.cmi.FaultLocalization.algorithms.FaultLocalizationAlgorithm;
import edu.uci.ics.cmi.FaultLocalization.model.SuspiciousnessMap;
import edu.uci.ics.cmi.HistorySlicing.parser.CommitProcessor;
import edu.uci.ics.cmi.Settings.ExpertiseFindingAlgorithmType;
import edu.uci.ics.cmi.Settings.Granularity;
import edu.uci.ics.cmi.Settings.Settings;
import edu.uci.ics.cmi.SourceCodeRepository.model.Commit;
import edu.uci.ics.cmi.SourceCodeRepository.model.Diff;

public class WhoseFault extends ExpertiseFindingAlgorithm {

	protected Integer formula;
	protected CommitProcessor commitProcessor;
	protected boolean lastChangeOnly = false;

	public WhoseFault(Settings settings, FaultLocalizationAlgorithm faultLocalizationAlgorithm) {
		super(settings, faultLocalizationAlgorithm);
		this.commitProcessor = new CommitProcessor();

		ExpertiseFindingAlgorithmType algorithmSelected = settings.getExpertiseFindingTechnique();
		switch (algorithmSelected)
		{
		case WhoseFault3:
			this.granularity = Granularity.TestCase;
			this.formula = 3;
			break;
		case WhoseFault3BugReport:
			this.granularity = Granularity.BugReport;
			this.formula = 3;
			break;
		case WhoseFault2:
			this.granularity = Granularity.TestCase;
			this.formula = 2;
			break;
		case WhoseFault2BugReport:
			this.granularity = Granularity.BugReport;
			this.formula = 2;
			break;
		case WhoseFault1:
			this.granularity = Granularity.TestCase;
			this.formula = 1;
			break;
		case WhoseFault1BugReport:
			this.granularity = Granularity.BugReport;
			this.formula = 1;
			break;
		default:
			this.granularity = null;
			this.formula = -1;
			break;
		}
	}

	@Override
	public ExpertiseFindingAlgorithm clone()
	{
		return new WhoseFault(settings, faultLocalizationAlgorithm);
	}

	@Override
	public boolean compute() throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException, IOException 
	{

		int numberOfTestCases = failToPassTestCases.size();
		for (int i = 0; i < numberOfTestCases; i++)
		{
			// Get lines with suspiciousness > 0
			int testId = failToPassTestCases.get(i);
			SuspiciousnessMap suspiciousnessMap = getSuspiciousnessMap(faultLocalizationAlgorithm.getSettings(), project, bugId, testId);

			// Per SuspiciousnessMap entry, get the life of that line
			String className = new String(); 
			List<Commit> commitsForFile = null;
			for (int j = 0; j < suspiciousnessMap.size(); j++)
			{
				if (className.compareTo(suspiciousnessMap.getClassName(j)) != 0)
				{
					className = suspiciousnessMap.getClassName(j);
					commitsForFile = getCommitsForFile(start, today, className);
				}

				contribute(i, commitsForFile, suspiciousnessMap.getLineNumber(j), suspiciousnessMap.getSuspiciousness(j), today, start);	
			}
		}
		
		return true;
	}
	
	protected SuspiciousnessMap getSuspiciousnessMap(Settings settings, String project, String bugId, Integer testId) throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException, IOException
	{
		return expertiseFindingDB.getSuspiciousnessMap(settings, project, bugId, testId);
	}
	
	protected List<Commit> getCommitsForFile(Timestamp start, Timestamp today, String className) throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException, IOException
	{
		String fileName = expertiseFindingDB.getFileName(project, className);
		
		// Get all commits that affect that file 
		List<Commit> commitsForFile = expertiseFindingDB.getCommitsWithAuthorIdUntil(project, fileName, today);

		if (commitsForFile.size() < 1)
			fileAccess.writeLog("EXCEPTION: No commits found for this file!! File: " + fileName);

		// Clean the list of commits (i.e. ignore branches and dead revisions)	
		commitsForFile = commitProcessor.cleanBackwards(commitsForFile);

		return commitsForFile;
	}
	
	protected void contribute(Integer test, List<Commit> commits, Integer lineNumber, Double suspiciousness, Timestamp today, Timestamp start) throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException
	{
		// Find, per COMMIT, what the oldLine was and what operation it was involved in 
		int j = 0;
		boolean stop = false;
		while ((j < commits.size()) && !stop)
		{
			Commit commit = commits.get(j);
			
			// Multiple commits may affect the same line (e.g. change and delete)
			List<Diff> diffs = expertiseFindingDB.getDiffs(settings, commit.getId(), lineNumber);
			for (Diff diff: diffs)
			{
				// Get each of the commits that involve an add or change
				switch (diff.getOperation())
				{
				default:
				case UNCHANGED:
					lineNumber = diff.getOldLine();
					break;
				case CHANGE:
					contribute(test, commit, lineNumber, suspiciousness, today, start);
					lineNumber = diff.getOldLine();
					if (lastChangeOnly)
						stop = true;
					break;
				case ADD:
				case INFERRED_ADD:
					contribute(test, commit, lineNumber, suspiciousness, today, start);
					stop = true;
					break;
				case DELETE:
				case INFERRED_DELETE:
					break;
				}
			}

			j++;
		}
		
	}
	
	protected void contribute(Integer test, Commit commit, Integer lineNumber, Double suspiciousness, Timestamp today, Timestamp start)
	{
		// Do not consider negative suspiciousness
		if (suspiciousness < 0)
			return;
		
		Integer id = commit.getAuthorId();
		Integer i = availableAuthors.get(id);
		
		Long commitLife;
		Long projectLife;
		Double recency;
		Double contribution;
		switch (formula)
		{
		case 1:
			//	EXPERTISE_1
			Long minutesAgo = (today.getTime() - commit.getDate().getTime()) / 60000;
			
			/* 
			 * contribution = suspiciousness * time_weight (1/days since change) 
			 * */
			scores[test][i] += (1/suspiciousness) * minutesAgo;
			break;
		case 2:
			//	EXPERTISE_2
			commitLife = commit.getDate().getTime() - start.getTime();
			projectLife = today.getTime() - start.getTime();

			recency = ((double) commitLife) / projectLife;
			contribution = suspiciousness * recency;
			
			scores[test][i] = (scores[test][i] + contribution) - (scores[test][i] * contribution);
			break;
		case 3:
			//	EXPERTISE_3
			commitLife = commit.getDate().getTime() - start.getTime();
			projectLife = today.getTime() - start.getTime();
			
			recency = ((double) commitLife) / projectLife;
			contribution = suspiciousness * recency;
			
			scores[test][i] += contribution;
			break;
		default:
		}
	
	}

	
}
