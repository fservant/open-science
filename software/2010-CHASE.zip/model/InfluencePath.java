package edu.uci.influence.model;

import java.util.LinkedList;

import edu.uci.influence.core.InfluenceCalculator;
import edu.uci.influence.model.Influence.DIRECTION;
import edu.uci.lighthouse.model.LighthouseAuthor;
import edu.uci.lighthouse.model.LighthouseEntity;

public class InfluencePath {

	private LinkedList<Influence> influences;
	private Double strength;

	public InfluencePath ()
	{
		this.influences = new LinkedList<Influence>();
		this.strength = 1.0;
	}
	
	public InfluencePath (Influence influence)
	{
		this.influences = new LinkedList<Influence>();
		this.strength = 1.0;
		
		this.influences.add(influence);
	}

	public InfluencePath (InfluencePath path, Influence influence)
	{
		this.influences = new LinkedList<Influence>(path.getInfluences());
		this.strength = new Double(path.getStrength());

		this.add(influence);
	}
	
	public String toString()
	{
		String s =  new String();
		s += "{";
		for (Influence i : influences)
		{
			s+=i;
		}
		s += "--";
		s += strength;
		s += "}";
		return s;
	}
	
	public LighthouseAuthor getAuthor() {
		return influences.getFirst().getAuthor();
	}

	public DIRECTION getDirection() {
		return influences.getFirst().getDirection();
	}

	public LighthouseEntity getSource() {
		return influences.getFirst().getSource();
	}
		
	public LighthouseEntity getDestination()
	{
		return influences.getLast().getDestination();
	}

	public Double getStrength() {
		return strength;
	}

	public LinkedList<Influence> getInfluences() {
		return influences;
	}

	public void setInfluences(LinkedList<Influence> influences) {
		this.influences = influences;
	}

	public void setStrength(Double strength) {
		this.strength = strength;
	}

	/* 
	 * Adds a new influence at the end of the path 
	 * (no matter the direction, because 
	 * it is represented in the Influence objects)
	 */
	public boolean add (Influence influence)
	{
		// Only if this path already has influences
		if (this.influences.size() > 0)
		{
			// Do not add the path if it does not have the same author
			// as this event.
			if (!influence.getAuthor().equals(this.getAuthor()))
				return false;

			// Do not add the path if it does not have the same direction
			// as this event.
			if (!influence.getDirection().equals(this.getDirection()))
				return false;

			// Do not add the path if it does not concatenate
			// correctly with this path
			if (!this.getDestination().equals(influence.getSource()))
				return false;
		}

		this.influences.add(influence);
		this.strength = InfluenceCalculator.influenceMath.concatenateStrengths(strength, influence.getStrength());
		return true;
	}

}
