package edu.uci.influence.model;

import edu.uci.lighthouse.model.LighthouseAuthor;
import edu.uci.lighthouse.model.LighthouseEntity;
import edu.uci.lighthouse.model.LighthouseRelationship;

public class Influence {

	public static enum DIRECTION {FORWARDS, BACKWARDS};

	private LighthouseAuthor author; // FIXME
	private DIRECTION direction;
	private Double strength;
	private LighthouseRelationship relationship;
	
	public Influence(
			LighthouseAuthor author, 
			DIRECTION direction,
			LighthouseRelationship relationship,
			Double strength)
	{
		this.author = author;
		this.direction = direction;
		this.relationship = relationship;
		this.strength = strength;
	}

	public String toString()
	{
		String s =  new String();
		s += "[";
		s += direction;
		s += "--";
		s += relationship;
		s += "--";
		s += strength;
		s += "--";
		s += author;
		s += "]";
		return s;
	}
	
	public Influence() {
	}

	public LighthouseAuthor getAuthor() {
		return author;
	}

	public DIRECTION getDirection() {
		return direction;
	}

	public LighthouseRelationship getRelationship() {
		return relationship;
	}

	public Double getStrength() {
		return strength;
	}
		
	public LighthouseEntity getSource()
	{
		/*
		 * Get the source of the influence
		 * depending on the direction
		 */
		switch (direction)
		{
		default:
		case FORWARDS:
			return relationship.getFromEntity();
		case BACKWARDS:
			return relationship.getToEntity();
		}
	}

	public LighthouseEntity getDestination()
	{
		/*
		 * Get the destination of the influence
		 * depending on the direction
		 */
		switch (direction)
		{
		default:
		case FORWARDS:
			return relationship.getToEntity();
		case BACKWARDS:
			return relationship.getFromEntity();
		}
	}

	public void setAuthor(LighthouseAuthor author) {
		this.author = author;
	}

	public void setDirection(DIRECTION direction) {
		this.direction = direction;
	}

	public void setStrength(Double strength) {
		this.strength = strength;
	}

	public void setRelationship(LighthouseRelationship relationship) {
		this.relationship = relationship;
	}

}
