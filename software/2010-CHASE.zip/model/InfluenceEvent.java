package edu.uci.influence.model;

import java.util.LinkedList;

import javax.persistence.Id;

import edu.uci.influence.core.InfluenceCalculator;
import edu.uci.influence.model.Influence.DIRECTION;
import edu.uci.lighthouse.model.LighthouseAuthor;
import edu.uci.lighthouse.model.LighthouseEntity;
import edu.uci.lighthouse.model.LighthouseEvent;

public class InfluenceEvent extends LighthouseEvent {
	
	@Id
	private Integer id;
	
	private LinkedList<InfluencePath> influencePaths;
	private Double strength;
	
	public InfluenceEvent(InfluencePath influencePath, LighthouseEvent source)
	{
		super(LighthouseEvent.TYPE.CUSTOM, influencePath.getAuthor(), influencePath.getDestination());
		this.influencePaths = new LinkedList<InfluencePath>();
		this.influencePaths.add(influencePath);
		this.strength = influencePath.getStrength();
		this.setTimestamp(source.getTimestamp());
	}
	
	public String toString()
	{
		String s =  new String();
		for (InfluencePath i : influencePaths)
		{
			s+=i + "\n";
		}
		s += "--";
		s += strength;
		return s;
	}
	
	/*
	 * Returns the direction of the influence
	 */
	public DIRECTION getDirection() {
		return influencePaths.getFirst().getDirection();
	}

	/*
	 * Returns the direction of the influence
	 */
	public LighthouseAuthor getAuthor() {
		return influencePaths.getFirst().getAuthor();
	}

	/*
	 * Returns the strength of the influence
	 */
	public Double getStrength() {
		return strength;
	}

	public LinkedList<InfluencePath> getInfluencePaths() {
		return influencePaths;
	}	

	public Object getArtifact() {
		return influencePaths.getFirst().getDestination();
	}

	public LinkedList<LighthouseEntity> getSources()
	{
		LinkedList<LighthouseEntity> sources = new LinkedList<LighthouseEntity>();
		
		for (InfluencePath path : influencePaths)
		{
			sources.add(path.getSource());
		}
		
		return sources;
	}
	
	/* 
	 * Adds a new influence path to the event
	 */
	public boolean add (InfluencePath influencePath)
	{
		// Only if this event already has influence paths
		if (this.influencePaths.size() > 0)
		{
			// Do not add the path if it does not have the same author
			// as this event.
			if (!influencePath.getAuthor().equals(this.getAuthor()))
				return false;

			// Do not add the path if it does not have the same direction
			// as this event.
			if (!influencePath.getDirection().equals(this.getDirection()))
				return false;

			// Do not add the path if it does not have the same destination
			// as this event.
			if (!influencePath.getDestination().equals(this.getArtifact()))
				return false;
		}
		
		this.influencePaths.add(influencePath);
		this.strength = InfluenceCalculator.influenceMath.combineStrengths(strength, influencePath.getStrength());
		return true;
	}

	/* 
	 * Combine this event with another one
	 */
	public boolean combine (InfluenceEvent influenceEvent)
	{
		// Only if this event already has influence paths
		if (this.influencePaths.size() > 0)
		{
			// Do not combine if it does not have the same author
			// as this event.
			if (!influenceEvent.getAuthor().equals(this.getAuthor()))
				return false;

			// Do not combine if it does not have the same direction
			// as this event.
			if (!influenceEvent.getDirection().equals(this.getDirection()))
				return false;

			// Do not combine if it does not have the same destination
			// as this event.
			if (!influenceEvent.getArtifact().equals(this.getArtifact()))
				return false;
		}
		
		LinkedList<InfluencePath> paths = influenceEvent.getInfluencePaths();
		for (InfluencePath path : paths)
			this.add(path);
		
		return true;
	}

	public String getIcon()
	{
		String iconName = "";

		switch (getDirection()) {
		case FORWARDS:
			iconName = "arrowRight";
			break;
		case BACKWARDS:
			iconName = "arrowLeft";
			break;
		} 
		Double number = getStrength() * 10;
		String iconNumber = number.toString().substring(0, 1); 

		System.out.println("/icons/" + iconName + iconNumber + ".png");
		System.out.flush();
		return "/icons/" + iconName + iconNumber + ".png";
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public void setInfluencePaths(LinkedList<InfluencePath> influencePaths) {
		this.influencePaths = influencePaths;
	}

	public void setStrength(Double strength) {
		this.strength = strength;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		InfluenceEvent other = (InfluenceEvent) obj;
		if (getAuthor() == null) {
			if (other.getAuthor() != null)
				return false;
		} else if (!getAuthor().equals(other.getAuthor()))
			return false;
		if (getArtifact() == null) {
			if (other.getArtifact() != null)
				return false;
		} else if (!getArtifact().equals(other.getArtifact()))
			return false;
		if (getDirection() == null) {
			if (other.getDirection() != null)
				return false;
		} else if (!getDirection().equals(other.getDirection()))
			return false;
		if (strength == null) {
			if (other.strength != null)
				return false;
		} else if (!strength.equals(other.strength))
			return false;
		return true;
	}

}
