package edu.uci.influence.model;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;

import edu.uci.influence.core.InfluenceCalculator;
import edu.uci.lighthouse.model.LighthouseClass;
import edu.uci.lighthouse.model.LighthouseEntity;
import edu.uci.lighthouse.model.LighthouseField;
import edu.uci.lighthouse.model.LighthouseInterface;
import edu.uci.lighthouse.model.LighthouseMethod;
import edu.uci.lighthouse.model.LighthouseModel;
import edu.uci.lighthouse.model.LighthouseRelationship;
import edu.uci.lighthouse.model.LighthouseRelationship.TYPE;

public class InfluenceModel {

	/*
	 * The original Lighthouse Model
	 */
	protected LighthouseModel model;

	/*
	 * The math for this model
	 */
//	protected InfluenceMath influenceMath;
	
	/*
	 * The direction for which this model is calculated.
	 * This affects the way in which one relationship
	 * prevails over others for the same destination,
	 * because we consider different weights for
	 * different directions
	 */
//	protected DIRECTION direction;
	
	/* 'relationshipsFrom' will store the relationships
	 * of the LighthouseModel sorted by: FROM, TYPE, TO
	 * It will be used to calculate influence
	 */
	protected HashMap<String, HashMap<String, LighthouseRelationship>> relationshipsFrom;
	
	/* 'relationshipsTo' will store the relationships
	 * of the LighthouseModel sorted by: TO, TYPE, FROM
	 * It will be used to calculate influence
	 */
	protected HashMap<String, HashMap<String, LighthouseRelationship>> relationshipsTo;

	/* 'relationshipsInside' will store all the 
	 * INSIDE relationships of the LighthouseModel 
	 * It will be used to infer relationships by inheritance
	 * sorted by: FROM
	 */
	protected HashMap<String, LighthouseRelationship> relationshipsInside;

	/* 'relationshipsInside' will store all the 
	 * EXTENDS, IMPLEMENTS relationships of the LighthouseModel 
	 * It will be used to infer relationships by inheritance
	 * sorted by: TO
	 */
	protected HashMap<String, LinkedList<LighthouseRelationship>> relationshipsInheritance;
	
	public InfluenceModel (LighthouseModel model)
	{
		this.model = model;
		this.restart();
	}

	public void restart ()
	{
		relationshipsFrom = new HashMap<String, HashMap<String, LighthouseRelationship>>();
		relationshipsTo = new HashMap<String, HashMap<String, LighthouseRelationship>>();
		relationshipsInside = new HashMap<String, LighthouseRelationship>();
		relationshipsInheritance = new HashMap<String, LinkedList<LighthouseRelationship>>();		
	}
	/*
	 * Add all the valid relationships to our internal hash maps.
	 * These hash maps are:
	 * relationshipsFrom: valid relationships sorted by FROM, TYPE, TO
	 * relationshipsTo: valid relationships sorted by TO, TYPE, FROM
	 * relationshipsInside: INSIDE relationships sorted by FROM 
	 */
	public void buildModel()
	{
		
		/* 
		 * Get all relationships of the model.
		 * 
		 * This iterates all the model.
		 */ 
		Collection<LighthouseRelationship> relationships = model.getRelationships();

		/* 
		 * Add all the valid relationships to our hash maps.
		 * 'addRelationship' will filter in order to
		 * add only the "valid" relationships.
		 *
		 * This iterates all the model.
		 */ 
		for (LighthouseRelationship r : relationships)
		{
			addRelationship(r);
		}
		
		/* 
		 * Add relationships inferred by inheritance
		 * e.g. (A USES B, C EXTENDS B) ---> A USES C (potentially)
		 *
		 * By iterating the 'relationships' array, I can afford  
		 * to modify our hash maps in each iteration of the loop.
		 * This also means that I will calculate inheritance-inferred
		 * relationships for every relationship in the model 
		 * (not just for the filtered ones).
		 * 
		 * NOTE: This loop cannot be joined with the previous one
		 * because 'resolveInheritance' uses our hash maps,
		 * and they have to be filled in before we can call it. 
		 *  
		 * This iterates all the model.
		 */ 
		for (LighthouseRelationship r : relationships)
		{
			Collection<LighthouseRelationship> resolvedByInheritance = resolveInheritance(r);
			for (LighthouseRelationship ri: resolvedByInheritance)
			{
				addRelationship(ri);
			}
		}
	}

	/*
	 * public method that updates our model 
	 * by recreating all relationships 
	 */
	public void updateRebuild()
	{
		restart();
		buildModel();
	}
	
	/*
	 * public method that updates our model 
	 * by adding a relationship 
	 */
	public void updateAdd(LighthouseRelationship r)
	{
		Collection<LighthouseRelationship> resolvedByInheritance = resolveInheritance(r);
		resolvedByInheritance.add(r);
		for (LighthouseRelationship ri: resolvedByInheritance)
		{
			addRelationship(ri);
		}
	}

	/*
	 * public method that updates our model 
	 * by removing a relationship 
	 */
	public void updateRemove(LighthouseRelationship r)
	{
		Collection<LighthouseRelationship> resolvedByInheritance = resolveInheritance(r);
		resolvedByInheritance.add(r);
		for (LighthouseRelationship ri: resolvedByInheritance)
		{
			removeRelationship(ri);
		}
	}
	
	protected void removeRelationship (LighthouseRelationship r)
	{
		String from = r.getFromEntity().getFullyQualifiedName();
		String to = r.getToEntity().getFullyQualifiedName();
		
		HashMap<String, LighthouseRelationship> mapTo = relationshipsFrom.get(from);
		if (mapTo != null)
		{
			mapTo.remove(r);
		}

		HashMap<String, LighthouseRelationship> mapFrom = relationshipsFrom.get(to);
		if (mapFrom != null)
		{
			mapFrom.remove(r);
		}
		
	}

	protected void addRelationship(LighthouseRelationship r)
	{
		// Get the FROM, TYPE, TO of the relationship
		String from = r.getFromEntity().getFullyQualifiedName();
		String to = r.getToEntity().getFullyQualifiedName();
		TYPE type = r.getType();

		/* 
		 * If it is an INSIDE relationship, 
		 * add it in a different structure
		 * 
		 */
		if (type == TYPE.INSIDE)
		{
			if (!relationshipsInside.containsKey(from))
			{
				relationshipsInside.put(from, r);
				return;
			}
		}
		
		/* 
		 * If it is an EXTENDS, IMPLEMENTS relationship, 
		 * add it in a different structure,
		 * but go on processing it
		 * 
		 */
		if ((type == TYPE.EXTENDS)
				|| (type == TYPE.IMPLEMENTS))
		{
			LinkedList<LighthouseRelationship> descendants = relationshipsInheritance.get(to);
			if (descendants == null)
			{
				descendants = new LinkedList<LighthouseRelationship>();
				relationshipsInheritance.put(to, descendants);
			}
			descendants.add(r);
		}

		/* 
		 * Add only valid relationships
		 */
		if (!isValidRelationship(r))
			return;
		
		/* 
		 * Add the relationship to the relationshipsFrom map.
		 * Only the strongest relationship will be considered
		 * for the same couple FROM, TO
		 */
		HashMap<String, LighthouseRelationship> mapTo = relationshipsFrom.get(from);
		if (mapTo == null)
		{
			mapTo = new HashMap<String, LighthouseRelationship>();
			relationshipsFrom.put(from, mapTo);
		}
		LighthouseRelationship savedRelationship = mapTo.get(to);
		mapTo.put(to, InfluenceCalculator.influenceMath.strongerRelationship(r, savedRelationship));
		
		/* 
		 * Add the relationship to the relationshipsTo map.
		 * Only the strongest relationship will be considered
		 * for the same couple FROM, TO
		 */
		HashMap<String, LighthouseRelationship> mapFrom = relationshipsTo.get(to);
		if (mapFrom == null)
		{
			mapFrom = new HashMap<String, LighthouseRelationship>();
			relationshipsTo.put(to, mapFrom);
		}
		savedRelationship = mapFrom.get(from);
		mapFrom.put(from, InfluenceCalculator.influenceMath.strongerRelationship(r, savedRelationship));
	}

	protected Boolean isValidRelationship(LighthouseRelationship r)
	{
		// No relationships with FROM == TO
		if  (r.getFromEntity().equals(r.getToEntity()))
		{
			return false;
		}
		// No INSIDE
		if (r.getType() == TYPE.INSIDE)
		{
			return false;
		}
		// No MODIFIED_BY
		if (r.getType() == TYPE.MODIFIED_BY)
		{
			return false;
		}
		// No Class/Interface USES Class/Interface
		// The TO is always a Class/Interface in USES. 
		// We don't compare the TO because it could also be Unresolved classes
		// We compare with LighthouseClass, because it contains both classes and interfaces
		if (r.getType() == TYPE.USES)
		{
			if (r.getFromEntity() instanceof LighthouseClass)
			{
				return false;
			}
		}
		
		return true;
	}
	
	public Collection<LighthouseRelationship> getRelationshipsFrom(LighthouseEntity e)
	{
		Collection<LighthouseRelationship> returnValue = new LinkedList<LighthouseRelationship>();
		
		String from = e.getFullyQualifiedName();
		HashMap<String, LighthouseRelationship> mapTo = relationshipsFrom.get(from);
		if (mapTo != null)
		{
			returnValue.addAll(mapTo.values());
		}

		return returnValue;
	}

	public Collection<LighthouseRelationship> getRelationshipsTo(LighthouseEntity e)
	{
		Collection<LighthouseRelationship> returnValue = new LinkedList<LighthouseRelationship>();
		
		String to = e.getFullyQualifiedName();
		HashMap<String, LighthouseRelationship> mapFrom = relationshipsTo.get(to);
		if (mapFrom != null)
		{
			returnValue.addAll(mapFrom.values());
		}

		return returnValue;
	}

	protected Collection<LighthouseEntity> getAllDescendants(LighthouseEntity e) {

		Collection<LighthouseEntity> result = new LinkedList<LighthouseEntity>();

		Collection<LighthouseRelationship> descendants = relationshipsInheritance.get(e.getFullyQualifiedName());
		
		if (descendants != null)
		{
			for (LighthouseRelationship r: descendants)
			{
				result.add(r.getFromEntity());
			}
		}

		if (result.size() > 0)
		{
			Collection<LighthouseEntity> nextLevelDescendants = new LinkedList<LighthouseEntity>();
			for (LighthouseEntity e2: result)
			{
				nextLevelDescendants.addAll(getAllDescendants(e2)); 
			}
			result.addAll(nextLevelDescendants);
		}
		
		return result;
	}

	protected LighthouseEntity getContainingClass (LighthouseEntity e)
	{
		LighthouseRelationship r = relationshipsInside.get(e.getFullyQualifiedName());
		if (r == null)
			return e;
		else
			return r.getToEntity();
	}
	
	/* 
	 * Add relationships inferred by inheritance
	 * e.g. (A USES B, C EXTENDS B) ---> A USES C (potentially)
	 */ 
	public Collection<LighthouseRelationship> resolveInheritance(LighthouseRelationship r)
	{
		LinkedList<LighthouseRelationship> inheritanceList = new LinkedList<LighthouseRelationship>();

		LighthouseEntity fromEntity = r.getFromEntity();
		LighthouseEntity toEntity = r.getToEntity();
		TYPE type = r.getType();

		if ( (type != TYPE.EXTENDS)
				&& (type != TYPE.IMPLEMENTS) )
		{
			if ((toEntity instanceof LighthouseClass)
					|| (toEntity instanceof LighthouseInterface)) {
				Collection<LighthouseEntity> children = getAllDescendants(toEntity);
				for (LighthouseEntity e : children) {
					LighthouseRelationship ir = new LighthouseRelationship(fromEntity, e, type); 
					inheritanceList.add(ir);
				}
			}
			if ((toEntity instanceof LighthouseField)
					|| (toEntity instanceof LighthouseMethod)) {
				LighthouseEntity containingClass = getContainingClass(toEntity);
				Collection<LighthouseEntity> children = getAllDescendants(containingClass);
				for (LighthouseEntity e : children) {
					String subClassEntityName = e.getFullyQualifiedName() + "." + toEntity.getShortName();
					LighthouseEntity subClassEntity = model.getEntity(subClassEntityName);
					if (subClassEntity != null) {
						LighthouseRelationship ir = new LighthouseRelationship(fromEntity, subClassEntity, type); 
						inheritanceList.add(ir);
					}
				}
			}
		}

		return inheritanceList;
	}
//
//	//TOREMOVE: Delete this method, it was only useful for a test
//	public String toString()
//	{
//		String modelString = new String();
//		
//		LinkedHashSet<LighthouseEvent> eventsHash = this.getListEvents();
//		for (LighthouseEvent event : eventsHash)
//		{
//			modelString += event.toString() + "\n";
//		}
//		
//		return modelString;
//	}
}
