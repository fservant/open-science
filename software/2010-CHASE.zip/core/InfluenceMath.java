package edu.uci.influence.core;

import edu.uci.influence.model.Influence.DIRECTION;
import edu.uci.lighthouse.model.LighthouseRelationship;
import edu.uci.lighthouse.model.LighthouseRelationship.TYPE;

public class InfluenceMath {

	protected Double [] strengthsForwards;
	protected Double [] strengthsBackwards;
	public DIRECTION direction;

	public InfluenceMath(DIRECTION direction)
	{
		this.strengthsForwards = new Double [TYPE.values().length];
		this.strengthsForwards[TYPE.CALL.ordinal()] = 0.4;
		this.strengthsForwards[TYPE.ACCESS.ordinal()] = 0.4;
		this.strengthsForwards[TYPE.RECEIVES.ordinal()] = 0.2;
		this.strengthsForwards[TYPE.RETURN.ordinal()] = 0.2;
		this.strengthsForwards[TYPE.HOLDS.ordinal()] = 0.2;
		this.strengthsForwards[TYPE.USES.ordinal()] = 0.2;
		this.strengthsForwards[TYPE.THROW.ordinal()] = 0.05;
		this.strengthsForwards[TYPE.EXTENDS.ordinal()] = 0.0005;
		this.strengthsForwards[TYPE.IMPLEMENTS.ordinal()] = 0.0005;
		this.strengthsBackwards = strengthsForwards;		

		this.direction = direction;	
	}
	
	public DIRECTION getDirection() {
		return direction;
	}

	public void setDirection(DIRECTION direction) {
		this.direction = direction;
	}

	public Double combineStrengths(Double a, Double b)
	{
		return (a + b - (a * b));
	}

	public Double concatenateStrengths(Double a, Double b)
	{
		return (a * b);
	}

	public LighthouseRelationship strongerRelationship(LighthouseRelationship a, LighthouseRelationship b)
	{
		if (a == null)
		{
			return b;
		}
		if (b == null)
		{
			return a;
		}
		if (getStrength(a) > getStrength(b))
		{
			return a;
		}
		else
		{
			return b;
		}
	}
	
	public Double getStrength(LighthouseRelationship r)
	{
		/*
		 * Get the strength of the relationship from the tables
		 */
		Double strength = 1.0;
		switch (direction)
		{
		default:
		case FORWARDS:
			strength = strengthsForwards[r.getType().ordinal()];
			break;
		case BACKWARDS:
			strength = strengthsBackwards[r.getType().ordinal()];
			break;
		}

		return strength;
	}
}
