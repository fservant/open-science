package edu.uci.influence.core;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import edu.uci.influence.model.InfluenceModel;
import edu.uci.lighthouse.model.LighthouseEvent;
import edu.uci.lighthouse.model.LighthouseModel;
import edu.uci.lighthouse.model.LighthouseModelManager;
import edu.uci.lighthouse.model.jpa.LHEventDAO;

public class InfluenceReplay {

//	private LighthouseModel model = new InfluenceModel();
	
	public void Replay ()
	{
		
	}
	
	public void run()
	{
//		System.out.println("Application started");
//		
//		// Get all the events in the database from point in time 0
//		List <LighthouseEvent> listEvents = getNewEventsFromDB(new Date(0));
//		
//		// Update the model
//		updateLighthouseModel(listEvents);
//		
//		System.out.println("List of events:\n");
//		for (LighthouseEvent event : listEvents)
//		{
//			System.out.println(event.toString());
//		}
//		
//		System.out.println("\nInfluence Model:\n" + model);
//		
//		System.out.println("Application finished");
//		System.out.flush();
	}
//	
//	/**
//	 * Timeout procedure will get all new events (timestamp > lastDBaccessTime)
//	 * @param lastDBaccessTime Last time that we accessed the database
//	 * @return 
//	 * */
//	public List<LighthouseEvent>  getNewEventsFromDB(Date lastDBaccessTime) {
//		Map<String, Object> parameters = new HashMap<String, Object>();
//		parameters.put("timestamp", lastDBaccessTime);
//		List<LighthouseEvent> listEvents = new LHEventDAO().executeNamedQuery("LighthouseEvent.findByTimestamp", parameters);
//		
//		return listEvents;
//	}
//
//	private void updateLighthouseModel(List<LighthouseEvent> listEvents) {
//		// Update the model
//		LighthouseModelManager modelManager = new LighthouseModelManager(model);
//		for (LighthouseEvent event : listEvents) {
//			modelManager.addEvent(event);
//		}
//	}

}
