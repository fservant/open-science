package edu.uci.influence.core;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;

import edu.uci.influence.model.Influence;
import edu.uci.influence.model.InfluenceEvent;
import edu.uci.influence.model.InfluenceModel;
import edu.uci.influence.model.InfluencePath;
import edu.uci.influence.model.Influence.DIRECTION;
import edu.uci.lighthouse.model.LighthouseAuthor;
import edu.uci.lighthouse.model.LighthouseEntity;
import edu.uci.lighthouse.model.LighthouseEvent;
import edu.uci.lighthouse.model.LighthouseMethod;
import edu.uci.lighthouse.model.LighthouseModel;
import edu.uci.lighthouse.model.LighthouseRelationship;

public class InfluenceCalculator {

	public static InfluenceMath influenceMath = new InfluenceMath(DIRECTION.FORWARDS);
	protected LighthouseAuthor author;
	protected Integer maxDistance;
	protected InfluenceModel influenceModel;
	protected LighthouseEvent source;
	
	/*
	 * Collection of entities that were influenced
	 * last time that an influence was calculated
	 */
//	protected LinkedList<LighthouseEntity> influencedEntities;
	
	/*
	 * Collection of entities that were influenced
	 * last time that an influence was calculated
	 */
	protected HashMap<LighthouseEntity, InfluenceEvent> influenceEventsForwards;
	/*
	 * Collection of entities that were influenced
	 * last time that an influence was calculated
	 */
	protected HashMap<LighthouseEntity, InfluenceEvent> influenceEventsBackwards;
	
	public InfluenceCalculator (LighthouseModel m, LighthouseAuthor author)
	{
		this.author = author;
		this.maxDistance = 100;
		this.influenceModel = new InfluenceModel(m);
		this.influenceModel.buildModel();

		LighthouseMethod e = new LighthouseMethod("edu.prenticehall.deitel.Deposit.execute()");
		
		System.out.println(this.influenceModel.getRelationshipsFrom(e));
		System.out.println(this.influenceModel.getRelationshipsTo(e));
		
	}
	
//	public Collection<LighthouseEntity> getInfluencedEntities() {
//		return influencedEntities;
//	}

	public Collection<InfluenceEvent> getInfluenceEvents() {
		LinkedList<InfluenceEvent> events = new LinkedList<InfluenceEvent>(); 
		events.addAll(influenceEventsForwards.values());
		events.addAll(influenceEventsBackwards.values());
		return events;
	}

	protected DIRECTION getDirection() {
		return InfluenceCalculator.influenceMath.getDirection();
	}

	protected void setDirection(DIRECTION direction) {
		InfluenceCalculator.influenceMath.setDirection(direction);
	}

	protected void restart()
	{
//		this.influencedEntities = new LinkedList<LighthouseEntity> ();
		this.influenceEventsForwards = new HashMap<LighthouseEntity, InfluenceEvent> ();
		this.influenceEventsBackwards = new HashMap<LighthouseEntity, InfluenceEvent> ();
	}
	
	public void updateRebuild()
	{
		this.influenceModel.updateRebuild();
	}
	
	protected void addInfluencePath (InfluencePath influencePath)
	{
		HashMap<LighthouseEntity, InfluenceEvent> influenceEvents = null;
		switch (this.getDirection())
		{
		default:
		case FORWARDS:
			influenceEvents = influenceEventsForwards;
			break;
		case BACKWARDS:
			influenceEvents = influenceEventsBackwards;
			break;
		}
		
		// Get the influenced entity
		LighthouseEntity influencedEntity = influencePath.getDestination();
		
		// Add the influenced entity to the collection of influenced entities
//		this.influencedEntities.add(influencedEntity);
		
		// Get the InfluenceEvent for this entity
		// and add this path to it
		InfluenceEvent event = influenceEvents.get(influencedEntity);
		if (event != null)
		{
			event.add(influencePath);
		}
		
		// If it doesn't exist, create a new one with this path and put it in the collection 
		else
		{
			event = new InfluenceEvent(influencePath, source);
			influenceEvents.put(influencedEntity, event);
		}
		
	}

	protected Influence createInfluence (LighthouseRelationship relationship)
	{
		/*
		 * Calculate the strength of the influence
		 */
		Double strength = influenceMath.getStrength(relationship); 

		/*
		 * Create the Influence object
		 */
		Influence influence = new Influence(
				author, 
				getDirection(), 
				relationship,
				strength);
		
		return influence;
	}

	
	protected void calculateInfluence (LighthouseRelationship relationship, InfluencePath tailPath, int maxDistance)
	{		
		/* 
		 * Base case
		 */
		if (maxDistance < 1)
		{
			return;
		}
		
		/*
		 * Find the relationships that go next in the chain at distance 1
		 */
		Collection<LighthouseRelationship> nextHop = null;
		switch (this.getDirection())
		{
		default:
		case FORWARDS:
			nextHop = influenceModel.getRelationshipsFrom(relationship.getToEntity());
			break;
		case BACKWARDS:
			nextHop = influenceModel.getRelationshipsTo(relationship.getFromEntity());
			break;
		}

		/* 
		 * Base case 2
		 * If none, return
		 */
		if (nextHop == null)
		{
			return;
		}
		
		// If this is the first call
		if (tailPath == null)
			tailPath = new InfluencePath();

		/*
		 * For each relationship at distance 1, 
		 * create an influence and continue
		 * the visits
		 */
		for (LighthouseRelationship r : nextHop)
		{
			Influence influence = createInfluence(r);
			InfluencePath influencePath = new InfluencePath (tailPath, influence);
			
			addInfluencePath(influencePath);
			
			calculateInfluence(r, influencePath, maxDistance - 1);
		}

	}

	public void calculateInfluence (LighthouseEvent source)
	{
		restart();
		
		this.source = source;
		Object o = source.getArtifact();
		if (o instanceof LighthouseEntity)
		{
			LighthouseEntity entity = (LighthouseEntity) o;
			/*
			 * Create a dummy relationship with the entity,
			 * get the equivalent relationships by inheritance,
			 * and process all of them
			 */
			LighthouseRelationship relationship = new LighthouseRelationship(entity, entity, null);
			Collection<LighthouseRelationship> relationships = influenceModel.resolveInheritance(relationship);
			relationships.add(relationship);
			
			for (LighthouseRelationship r : relationships)
			{
				this.setDirection(DIRECTION.FORWARDS);
				calculateInfluence(r, null, maxDistance);
				
				this.setDirection(DIRECTION.BACKWARDS);
				calculateInfluence(r, null, maxDistance);
			}
		}
	}
	
//	protected String influenceString (InfluencePath influence)
//	{
//		String returnValue = new String();
//		
//		DIRECTION direction = influence.getDirection();
//
//		/*
//		 * If the influence is backwards, 
//		 * print this relationship before the path.
//		 */
//		if (direction == DIRECTION.BACKWARDS)
//		{
//			returnValue += influence.getRelationship();
//		}
//
//		/* 
//		 * If the tail entity is not the same as the source,
//		 * follow the chain of relationships
//		 */
//		if (influence.getpreviousInfluence() != null)
//		{
//			if (direction == DIRECTION.BACKWARDS)
//				returnValue += ",";			
//			returnValue += influenceString( influence.getpreviousInfluence() );
//			if (direction == DIRECTION.FORWARDS)
//				returnValue += ",";			
//		}
//
//		/*
//		 * If the influence is forwards, 
//		 * print this relationship after the path.
//		 */
//		if (direction == DIRECTION.FORWARDS)
//		{
//			returnValue += influence.getRelationship();
//		}
//
//		return returnValue;
//	}
//
//	
//	public String influenceString()
//	{
//		ArrayList<String> influenceChains = new ArrayList<String>();
//		String returnValue = new String();
//
//		returnValue += "Influence by author: ";
//		returnValue += this.author.getName();
//		returnValue += "\n--------------------------------------------\n";
//		
//		LinkedList<InfluenceEvent> influenceEvents = new LinkedList<InfluenceEvent>();
//		
//		/* 
//		 * Get all entities of the model.
//		 * This iterates all the model.
//		 * 
//		 */ 
//		Collection<LighthouseEntity> entities = model.getEntities();
//		for (LighthouseEntity entity : entities)
//		{
//			Collection<LighthouseEvent> events = entity.getEvents();
//			for (LighthouseEvent event : events)
//			{
//				/*
//				 * If the entity has events 
//				 * and they are influence events, 
//				 * display them
//				 */
//				if (event instanceof InfluenceEvent)
//				{
//					InfluenceEvent influenceEvent = (InfluenceEvent) event;
//					influenceEvents.add(influenceEvent);
//					LinkedList<InfluencePath> influences = influenceEvent.getInfluencePaths();
//					for (InfluencePath i : influences)
//					{
//						influenceChains.add("\nDirection: " + i.getDirection() + " <" + influenceString(i) + ",>");
//					}
//				}
//			}
//		}
//		
//		for (InfluenceEvent influenceEvent : influenceEvents)
//		{
//			String s = "<" + influenceEvent.getArtifact().getFullyQualifiedName() + " " + influenceEvent.getStrength() + ">";
//			influenceChains.add("\nDirection: " + influenceEvent.getDirection() + " " + s);
//		}
//		
//		Collections.sort(influenceChains);
//		for (String s : influenceChains)
//		{
//			returnValue += s;
//		}
//		return returnValue;
//
//	}
}



















