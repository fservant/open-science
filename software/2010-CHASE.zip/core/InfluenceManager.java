package edu.uci.influence.core;

import java.util.Collection;

import edu.uci.influence.model.InfluenceEvent;
import edu.uci.lighthouse.model.LighthouseAuthor;
import edu.uci.lighthouse.model.LighthouseEvent;
import edu.uci.lighthouse.model.LighthouseModel;

public class InfluenceManager {

	private static InfluenceCalculator calculator;

//	public static InfluenceCalculator getCalculator()
//	{
//		if (calculator == null)
//		{
//			calculator = new InfluenceCalculator(LighthouseModel.getInstance(), new LighthouseAuthor(""));
//		}
//		// THIS 'ELSE' IS ONLY NECESSARY TEMPORARILY, 
//		// UNTIL WE FIGURE OUT A BETTER
//		// WAY OF UPDATING THE INFLUENCE MODEL
//		else
//		{
//			calculator.updateRebuild();
//		}
//		return calculator;
//	}
//	
//	public static void add (LighthouseRelationship r)
//	{
//		InfluenceManager.getInstance().updateAdd(r);
//	}
//	
//	public static void remove (LighthouseRelationship r)
//	{
//		InfluenceManager.getInstance().updateRemove(r);
//	}
//	
	public static Collection<InfluenceEvent> calculateInfluence (LighthouseEvent e, LighthouseAuthor author)
	{
		InfluenceCalculator calculator = new InfluenceCalculator(LighthouseModel.getInstance(), author);
		calculator.calculateInfluence(e);
		return calculator.getInfluenceEvents();
	}

//	public static void rebuild()
//	{
//		InfluenceManager.getCalculator().updateRebuild();
//	}
}
