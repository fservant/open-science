package edu.uci.ics.HistorySlicing;

/**
 * @author Francisco Servant <fservant@uci.edu> <www.fservant.com>
 * 
 * Class that represents a commit in the source code repository.
 */
public class Commit {
	
	/**
	 * Name of the file that was modified.
	 */
	public String fileName;
	
	/**
	 * Revision number that was created in this commit.
	 */
	public Integer revision;
}
