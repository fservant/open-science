package edu.uci.ics.HistorySlicing;

import java.util.List;

/**
 * @author Francisco Servant <fservant@uci.edu> <www.fservant.com>
 * 
 * Implementation of the History Slicing technique.
 */
public class HistorySlicer {

	public SourceCodeRepository sourceCodeRepository;
	
	/**
	 * Default constructor
	 */
	public HistorySlicer() {
		this.sourceCodeRepository = new SourceCodeRepository();
	}

	/**
	 * This method computes a history slice, given a history slicing criterion.
	 * 
	 * @param slicingCriterion It contains the revisions of the source code files
	 * 						   and the lines inside each of those revisions
	 * 						   that were selected as the history slicing criterion.
	 * 						   For example, lines 25-96 from file Browser.java at revision 1.120
	 * 						   and lines 125-280 from file Database.java at revision 1.87.
	 * @return It returns a history slice object that contains the resulting history slice.
	 */
	public HistorySlice computeSlice(HistorySlicingCriterion slicingCriterion) 
	{
		// Initialize history slice
		HistorySlice historySlice = new HistorySlice();
		
		// For every <source code file, revision> that was selected for the slicing criterion
		for (int i = 0; i < slicingCriterion.commits.size(); i++)
		{
			// Get commit representing the current revision
			Commit commit = slicingCriterion.commits.get(i);

			// Get historyGraphEdges (mappings between the current revision and its previous one).
			List<HistoryGraphEdge> historyGraphEdges = sourceCodeRepository.getHistoryGraphEdges(commit);

			// Create the snapshot that contains the lines of code of the slicing criterion for this <source code file, revision>
			HistoryGraphEdge [] snapshot = new HistoryGraphEdge[slicingCriterion.lines.get(i).length];
			for (int j = 0; j < snapshot.length; j++)
				snapshot[j] = historyGraphEdges.get(slicingCriterion.lines.get(i)[j] - 1);	// File lines start in 1. Java Lists start in 0.

			// First, add to the history slice the snapshot that represents 
			// the lines of code selected in the current <source code file, revision>
			// for the slicing criterion.
			historySlice.addFile();
			historySlice.add(commit, snapshot);

			// Get all commits that affected the file before this commit.
			List<Commit> commits = sourceCodeRepository.getCommitsUntil(commit);

			// Navigate through the history of this file
			// in reverse chronological order
			for (int j = 0; j < commits.size(); j++)
			{
				// Were the lines of code changed in this snapshot in this revision?  
				boolean snapshotChanged = false;

				// Get commit for current revision
				commit = commits.get(j);

				// Get historyGraphEdges (mappings between current revision and its previous one)
				historyGraphEdges = sourceCodeRepository.getHistoryGraphEdges(commit);

				// For every line of code inside the current snapshot
				for (int k = 0; k < snapshot.length; k++)
				{
					// Get snapshot of the lines of code in the previous revision of the file
					if (snapshot[k] != null)
						switch (snapshot[k].changeType)
						{
						case CHANGE:
						case UNCHANGED:
							snapshot[k] = historyGraphEdges.get(snapshot[k].oldLine - 1);	// File lines start in 1. Java Lists start in 0.
							break;
						case ADD:
							snapshot[k] = null;
							break;
						default:
							break;
						}

					// Were the lines of code changed in the snapshot in the previous revision?
					if (snapshot[k] != null)
						switch (snapshot[k].changeType)
						{
						case CHANGE:
						case ADD:
							snapshotChanged = true;
							break;
						default:
							break;
						}
				}

				// If the snapshot in the previous revision changed, add it to the history slice
				if (snapshotChanged)
					historySlice.add(commit, snapshot);

			}
		}
		
		return historySlice;
	}

}
