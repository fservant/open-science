package edu.uci.ics.HistorySlicing;

import java.util.LinkedList;

/**
 * @author Francisco Servant <fservant@uci.edu> <www.fservant.com>
 * 
 * Class that represents a history slice
 */
public class HistorySlice {
	
	/**
	 * Commits inside the history slice.
	 * 
	 * The first dimension of the list represents the 
	 * different source code files included in the history slice.
	 * 
	 * The second dimension represents, for each source code file,
	 * the commits that were included in the slice for that file.
	 *  
	 */
	public LinkedList<LinkedList<Commit>> commits;
	
	/**
	 * Source code lines inside the history slice.
	 * 
	 * The first dimension of the list represents the 
	 * different source code files included in the history slice.
	 * 
	 * The second dimension represents, for each source code file,
	 * the commits that were included in the slice for that file.
	 * 
	 * The third dimension represents for each commit that was
	 * included in the history slice, the lines of code that
	 * belong to the history slice
	 *  
	 */	
	public LinkedList<LinkedList<HistoryGraphEdge []>> lines;

	
	/**
	 * Constructor. It initializes the data structures. 
	 */
	public HistorySlice() {
		this.commits = new LinkedList<LinkedList<Commit>>();
		this.lines = new LinkedList<LinkedList<HistoryGraphEdge []>>();
	}
	
	/**
	 * It tells the history slice that the new information
	 * that will be inserted belongs now to a different
	 * source code file.
	 */
	public void addFile()
	{
		this.commits.add(new LinkedList<Commit>());
		this.lines.add(new LinkedList<HistoryGraphEdge []>());
	}

	/**
	 * It inserts a new set of lines within a commit
	 * into the history slice.
	 * 
	 * @param commit Commit that was selected to belong to the history slice.
	 * @param lines Lines within the revision created in this commit that 
	 * 				belong to the history slice.
	 */
	public void add(Commit commit, HistoryGraphEdge [] lines) {
		
		// Select the latest file
		int currentFile = this.commits.size() - 1;

		// Add commit
		this.commits.get(currentFile).add(commit);
		
		// Add lines
		HistoryGraphEdge [] snapshot = new HistoryGraphEdge[lines.length];
		for (int i = 0; i < lines.length; i++)
			snapshot[i] = lines[i];

		this.lines.get(currentFile).add(snapshot);
	}
	
}