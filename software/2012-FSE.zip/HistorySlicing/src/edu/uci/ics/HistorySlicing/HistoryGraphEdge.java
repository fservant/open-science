package edu.uci.ics.HistorySlicing;

/**
 * @author Francisco Servant <fservant@uci.edu> <www.fservant.com>
 * 
 * Class that represents an edge in the history graph.
 * 
 * For every two consecutive revisions of a source code file,
 * this class maps each line of code in the older revision
 * to its corresponding line of code in the newer revision.
 * 
 */
public class HistoryGraphEdge {
	
	/**
	 * Line number in the previous revision of the source code file.
	 */
	public Integer oldLine;
	
	/**
	 * Operation that made oldLine turn into newLine.
	 */
	public ChangeType changeType;
	
	/**
	 * Line number in the new revision of the source code file.
	 */
	public Integer newLine;
}
