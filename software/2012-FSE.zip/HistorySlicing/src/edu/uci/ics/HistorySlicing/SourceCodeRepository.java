package edu.uci.ics.HistorySlicing;

import java.util.List;

/**
 * @author Francisco Servant <fservant@uci.edu> <www.fservant.com>
 * 
 * Class that represents the source code repository of the software project.
 * 
 * This class needs to be implemented for the particular source code repository
 * that you use.
 * 
 */
public class SourceCodeRepository {

	/**
	 * Default constructor.
	 */
	public SourceCodeRepository() {
	}

	/**
	 * This method calls the source code repository and obtains a list of all
	 * the commits that affected a source code file before a specific revision.
	 * The name of the source code file and its revision are specified in
	 * the 'commit' parameter.
	 * 
	 * For example, in the CVS source code repository,
	 * one way to obtain this information would be by
	 * parsing the output of the 'cvs log' command.
	 * 
	 * @param commit Commit object that contains the name of the source code
	 * 				 file and the revision before which we want to obtain
	 * 				 all the revisions that affected this file.
	 * @return The list of all commits that affected this file before the
	 * 		   revision specified as a parameter, in reverse chronological order. 
	 */
	public List<Commit> getCommitsUntil(Commit commit) {
		// TODO Auto-generated method stub
		return null;
	}

	
	/**
	 * This method calls the source code repository and obtains
	 * a one-to-one mapping between all the lines of code of a source code file
	 * in a specified revision and its immediate preceding revision.
	 * 
	 * For example, in the CVS source code repository,
	 * one way to obtain this information would be by
	 * parsing the output of the 'cvs diff' command. 
	 * 
	 * A different way would be to obtain the contents
	 * of the specified revision and the contents of its preceding revision
	 * and parse them to calculate the differences between their abstract syntax trees.
	 * 
	 * @param commit Commit object that contains the name of a source code
	 * 				 file and a revision of this source code file.
	 * @return History Graph edges that represent a one-to-one mapping between
	 * 		   the lines of code in the revision of the source code file that
	 * 		   was specified as a parameter and its immediately preceding revision.
	 */
	public List<HistoryGraphEdge> getHistoryGraphEdges(Commit commit) {
		// TODO Auto-generated method stub
		return null;
	}

}
