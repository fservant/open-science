package edu.uci.ics.HistorySlicing;

import java.util.LinkedList;

/**
 * @author Francisco Servant <fservant@uci.edu> <www.fservant.com>
 * 
 * Class that represents a history slicing criterion.
 */
public class HistorySlicingCriterion {
	
	/**
	 * Commits inside the history slicing criterion.
	 * 
	 * A commit represents a revision of a source code file.
	 * Any set of source code files and revisions can be
	 * selected to become part of the history slicing criterion.
	 *  
	 */
	public LinkedList<Commit> commits;
	
	/**
	 * Source code lines selected for the history slicing criterion.
	 * 
	 * The first dimension represents the commits that are
	 * part of the history slicing criterion.
	 * 
	 * The second dimension represents for each commit that was
	 * included in the history slicing criterion, 
	 * the lines of code that were selected to become part of
	 * the history slicing criterion.
	 *  
	 */	
	public LinkedList<Integer []> lines;

	
	/**
	 * Constructor. It initializes the data structures. 
	 */
	public HistorySlicingCriterion() {
		this.commits = new LinkedList<Commit>();
		this.lines = new LinkedList<Integer []>();
	}
	
	/**
	 * It inserts a new set of lines within a commit
	 * into the history slicing criterion.
	 * 
	 * @param commit Revision of a file that was selected 
	 * 				 for the history slicing criterion.
	 * @param lines Lines within that revision that were
	 * 				selected for the history slicing criterion.
	 */
	public void add(Commit commit, Integer [] lines) {
		
		// Add commit
		this.commits.add(commit);
		
		// Add lines
		Integer [] snapshot = new Integer[lines.length];
		for (int i = 0; i < lines.length; i++)
			snapshot[i] = lines[i];

		this.lines.add(snapshot);
	}
	
}