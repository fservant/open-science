package edu.uci.ics.HistorySlicing;

/**
 * @author Francisco Servant <fservant@uci.edu> <www.fservant.com>
 * 
 * Class that represents the kind of change that made one line of code 
 * become another between two revisions of a source code file.
 */
public enum ChangeType {
	/**
	 * The line of code was deleted from the old revision.
	 */
	DELETE, 
	
	/**
	 * The line of code was added in the new revision.
	 */
	ADD, 
	
	/**
	 * The line of code was changed from the old revision to the new revision.
	 */
	CHANGE, 
	
	/**
	 * The line of code stayed unchanged between the old revision and the new revision.
	 */
	UNCHANGED
}