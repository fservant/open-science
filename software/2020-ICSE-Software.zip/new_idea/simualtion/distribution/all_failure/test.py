for item in range(1,4):
    print(item)