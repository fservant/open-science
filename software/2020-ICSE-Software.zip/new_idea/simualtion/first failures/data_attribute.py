import csv
import numpy as np
import xlwt
#from sklearn.cluster import KMeans
import time


book = xlwt.Workbook(encoding='utf-8', style_compression=0)
sheet = book.add_sheet('time', cell_overwrite_ok=True)



def get_median(data):
    data = sorted(data)
    size = len(data)
    if size % 2 == 0:  # 判断列表长度为偶数
        median = (data[size // 2] + data[size // 2 - 1]) / 2
        data[0] = median
    if size % 2 == 1:  # 判断列表长度为奇数
        median = data[(size - 1) // 2]
        data[0] = median
    return data[0]

project_names={'rails/rails','openSUSE/open-build-service', 'checkstyle/checkstyle', 'fog/fog', 'rapid7/metasploit-framework', 'opal/opal', 'github/linguist', 'dreamhead/moco', 'rubinius/rubinius', 'bbatsov/rubocop', 'yegor256/rultor', 'mbj/mutant', 'facebook/presto', 'languagetool-org/languagetool', 'ging/social_stream', 'SonarSource/sonarqube', 'caelum/vraptor4', 'thoughtbot/hound', 'cloudfoundry/cloud_controller_ng', 'maxcom/lorsource', 'rubygems/rubygems', 'bikeindex/bike_index', 'gradle/gradle', 'pry/pry', 'ManageIQ/manageiq', 'mitchellh/vagrant', 'orbeon/orbeon-forms', 'apache/flink', 'heroku/heroku', 'jruby/jruby', 'spree/spree', 'deeplearning4j/deeplearning4j'}
col=1
src_churn=[]
test_churn=[]
files_added=[]
files_deleted=[]
files_modified=[]
test_added=[]
test_deleted=[]
src_file=[]
document_file=[]
other_file=[]
#project_names=['github/linguist']
all_name=[]


for name in project_names:
    file_name = name + ".csv"
    file_name = file_name.split("/")[1]
    print(file_name)
    all_name.append(name)
    string="/Users/jinxianhao/Documents/src/python/CI/Data_Base/dataset/" + file_name

    csv_file = csv.reader(open(string, 'r'))
    pre = []
    final = []
    for item in csv_file:
        pre.append(item)

    for i in range(len(pre[0])):
        temp = []
        for index in range(1, len(pre)):
            # print(index)
            # print(pre[index][i])
            temp.append(pre[index][i])
        final.append(temp)
    print(len(final[42]))

    indices=[]
    for index in range(1, len(final[42])):
        if final[42][index] == 'passed':
            indices.append(index)
        else:
            if final[42][index - 1] == 'passed':
                indices.append(index)

    for item in indices:
        if final[42][item]=='failed' :#and float(final[24][item])>0:
            src_churn.append(float(final[23][item]))
            test_churn.append(float(final[24][item]))
            files_added.append(float(final[25][item]))
            files_deleted.append(float(final[26][item]))
            files_modified.append(float(final[27][item]))
            test_added.append(float(final[28][item]))
            test_deleted.append(float(final[29][item]))
            src_file.append(float(final[30][item]))
            document_file.append(float(final[31][item]))
            other_file.append(float(final[32][item]))



sheet.write(0, 1, get_median(src_churn))
sheet.write(1, 1, get_median(test_churn))
sheet.write(2, 1, get_median(files_added))
sheet.write(3, 1, get_median(files_deleted))
sheet.write(4, 1, get_median(files_modified))
sheet.write(5, 1, get_median(test_added))
sheet.write(6, 1, get_median(test_deleted))
sheet.write(7, 1, get_median(src_file))
sheet.write(8, 1, get_median(document_file))
sheet.write(9, 1, get_median(other_file))

print(len(src_churn))
#book.save(r'attribute_test_4.xls')
