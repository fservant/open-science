import csv
import numpy as np
import xlwt

book = xlwt.Workbook(encoding='utf-8', style_compression=0)
sheet = book.add_sheet('src_churn', cell_overwrite_ok=True)
sheet2 = book.add_sheet('test', cell_overwrite_ok=True)

all_result = []
for index in range(16):
    all_result.append([])

project_names={'rails/rails','openSUSE/open-build-service', 'checkstyle/checkstyle', 'fog/fog', 'rapid7/metasploit-framework', 'opal/opal', 'github/linguist', 'dreamhead/moco', 'rubinius/rubinius', 'bbatsov/rubocop', 'yegor256/rultor', 'mbj/mutant', 'facebook/presto', 'languagetool-org/languagetool', 'ging/social_stream', 'SonarSource/sonarqube', 'caelum/vraptor4', 'thoughtbot/hound', 'cloudfoundry/cloud_controller_ng', 'maxcom/lorsource', 'rubygems/rubygems', 'bikeindex/bike_index', 'gradle/gradle', 'pry/pry', 'ManageIQ/manageiq', 'mitchellh/vagrant', 'orbeon/orbeon-forms', 'apache/flink', 'heroku/heroku', 'jruby/jruby', 'spree/spree', 'deeplearning4j/deeplearning4j'}
#project_names=['bbatsov/rubocop']
project_names=['rails/rails', 'rubinius/rubinius', 'rspec/rspec-core', 'plataformatec/devise', 'rspec/rspec-rails', 'sferik/rails_admin', 'padrino/padrino-framework', 'activerecord-hackery/ransack', 'rspec/rspec-mocks', 'diaspora/diaspora', 'rubygems/rubygems', 'spree/spree', 'pry/pry', 'jruby/activerecord-jdbc-adapter', 'mikel/mail', 'amatsuda/kaminari', 'puppetlabs/puppet', 'jruby/jruby', 'openSUSE/open-build-service', 'fog/fog', 'refinery/refinerycms', 'opal/opal', 'rapid7/metasploit-framework', 'rails-api/active_model_serializers', 'slim-template/slim', 'rollbar/rollbar-gem', 'ruboto/ruboto', 'fluent/fluentd', 'checkstyle/checkstyle', 'toptal/chewy', 'SonarSource/sonarqube']
pos=0
for name in project_names:
    file_name = name + ".csv"
    file_name = file_name.split("/")[1]
    print(file_name)

    string="/Users/jinxianhao/Documents/src/python/CI/Data_Base/new_dataset/" + file_name
    csv_file = csv.reader(open(string, 'r'))
    pre = []
    final = []
    for item in csv_file:
        pre.append(item)

    for i in range(len(pre[0])):
        temp = []
        for index in range(1, len(pre)):
            # print(index)
            # print(pre[index][i])
            temp.append(pre[index][i])
        final.append(temp)
    print(len(final[42]))

    indices = []
    for index in range(len(final[42])):
        if final[42][index] == 'passed':
            indices.append(index)
        else:
            #if index != 0 or index != len(final[42]) - 1:
                if final[42][index - 1] == 'passed':
                    indices.append(index)
    # print(indices)

    src_churn=[]
    build_result=[]
    for item in indices:
        src_churn.append(float(final[23][item]))
        if final[42][item] == 'passed':
            build_result.append(1)
        else:
            build_result.append(0)

    result=[]
    for index in range(16):
        result.append([])
    final_result = []
    for index in range(16):
        final_result.append([])

    for index in range(len(src_churn)):
        if src_churn[index] == 0:
            result[0].append(build_result[index])
            all_result[0].append(build_result[index])
        elif src_churn[index] == 1:
            result[1].append(build_result[index])
            all_result[1].append(build_result[index])
        elif src_churn[index] == 2:
            result[2].append(build_result[index])
            all_result[2].append(build_result[index])
        elif src_churn[index] == 3:
            result[3].append(build_result[index])
            all_result[3].append(build_result[index])
        elif src_churn[index] == 4:
            result[4].append(build_result[index])
            all_result[4].append(build_result[index])
        elif src_churn[index] == 5:
            result[5].append(build_result[index])
            all_result[5].append(build_result[index])
        elif src_churn[index] >= 6 and src_churn[index] <= 10:
            result[6].append(build_result[index])
            all_result[6].append(build_result[index])
        elif src_churn[index] >= 11 and src_churn[index] <= 15:
            result[7].append(build_result[index])
            all_result[7].append(build_result[index])
        elif src_churn[index] >= 16 and src_churn[index] <= 20:
            result[8].append(build_result[index])
            all_result[8].append(build_result[index])
        elif src_churn[index] >= 21 and src_churn[index] <= 30:
            result[9].append(build_result[index])
            all_result[9].append(build_result[index])
        elif src_churn[index] >= 31 and src_churn[index] <= 50:
            result[10].append(build_result[index])
            all_result[10].append(build_result[index])
        elif src_churn[index] >= 51 and src_churn[index] <= 100:
            result[11].append(build_result[index])
            all_result[11].append(build_result[index])
        elif src_churn[index] >= 101 and src_churn[index] <= 200:
            result[12].append(build_result[index])
            all_result[12].append(build_result[index])
        elif src_churn[index] >= 201 and src_churn[index] <= 500:
            result[13].append(build_result[index])
            all_result[13].append(build_result[index])
        elif src_churn[index] >= 501 and src_churn[index] <= 1000:
            result[14].append(build_result[index])
            all_result[14].append(build_result[index])
        else:
            result[15].append(build_result[index])
            all_result[15].append(build_result[index])
    #print(result)

    for index in range(len(result)):
        if len(result[index]) >0 :
            final_result[index].append(1-sum(result[index])/len(result[index]))
        else:
            final_result[index].append("N/A")

    print(final_result)

    for index in range(len(final_result)):
        sheet.write(pos, 1, final_result[index][0])
        sheet.write(pos, 2, len(result[index]))
        pos=pos+1

for index in range(len(all_result)):
    sheet2.write(index, 1, (1-sum(all_result[index])/len(all_result[index])))
    sheet2.write(index, 2, len(all_result[index]))
    #pos=pos+1

book.save(r'src_churn1.xls')