import numpy as np
from sklearn.cluster import DBSCAN
from sklearn.cluster import AffinityPropagation
from sklearn.cluster import KMeans
import csv
import matplotlib.pyplot as plt
import xlwt

'''
X=np.array([1,2,3,4,5,11,12,13,14,15])
X=X.reshape(-1,1)
y_pred = DBSCAN().fit_predict(X)
y_pred = AffinityPropagation().fit_predict(X)
print(y_pred)
'''

def get_median(data):
    data = sorted(data)
    size = len(data)
    if size % 2 == 0:  # 判断列表长度为偶数
        median = (data[size // 2] + data[size // 2 - 1]) / 2
        data[0] = median
    if size % 2 == 1:  # 判断列表长度为奇数
        median = data[(size - 1) // 2]
        data[0] = median
    return data[0]

def plot(X):
    Sum_of_squared_distances = []
    K = range(1, 15)
    for k in K:
        km = KMeans(n_clusters=k)
        km = km.fit(X)
        Sum_of_squared_distances.append(km.inertia_)

    plt.plot(K, Sum_of_squared_distances, 'bx-')
    plt.xlabel('k')
    plt.ylabel('Sum_of_squared_distances')
    plt.title('Elbow Method For Optimal k')
    plt.show()

project_names=['rails/rails', 'myronmarston/vcr', 'concerto/concerto', 'benhoskings/babushka', 'rubinius/rubinius', 'rubychan/coderay', 'codeforamerica/adopt-a-hydrant', 'radiant/radiant', 'saberma/shopqi', 'rspec/rspec-core', 'engineyard/engineyard', 'plataformatec/devise', 'rspec/rspec-rails', 'karmi/retire', 'sferik/rails_admin', 'tdiary/tdiary-core', 'dkubb/veritas', 'sstephenson/sprockets', 'thoughtbot/factory_girl', 'weppos/whois', 'errbit/errbit', 'padrino/padrino-framework', 'thoughtbot/paperclip', 'plataformatec/simple_form', 'huerlisi/bookyt', 'hotsh/rstat.us', 'mperham/dalli', 'innoq/iqvoc', 'cheezy/page-object', 'justinfrench/formtastic', 'nov/fb_graph', 'assaf/vanity', 'activerecord-hackery/ransack', 'jimweirich/rake', 'rspec/rspec-mocks', 'neo4jrb/neo4j', 'diaspora/diaspora', 'test-unit/test-unit', 'Shopify/liquid', 'activeadmin/activeadmin', 'ari/jobsworth', 'thoughtbot/shoulda-matchers', 'rubygems/rubygems', 'rdoc/rdoc', 'spree/spree', 'rubyzip/rubyzip', 'pry/pry', 'jruby/activerecord-jdbc-adapter', 'sass/sass', 'jruby/warbler', 'fatfreecrm/fat_free_crm', 'rspec/rspec-expectations', 'excon/excon', 'typus/typus', 'heroku/heroku', 'nahi/httpclient', 'podio/podio-rb', 'maxdemarzi/neography', 'locomotivecms/engine', 'gedankenstuecke/snpr', 'peter-murach/github', 'jnicklas/capybara', 'travis-ci/travis-core', 'presidentbeef/brakeman', 'mikel/mail', 'randym/axlsx', 'kmuto/review', 'danielweinmann/catarse', 'middleman/middleman', 'rubyworks/facets', 'railsbp/rails_best_practices', 'comfy/comfortable-mexican-sofa', 'mongoid/moped', 'wr0ngway/rubber', 'rslifka/elasticity', 'lsegal/yard', 'NoamB/sorcery', 'puppetlabs/puppet', 'mitchellh/vagrant', 'ai/r18n', 'celluloid/celluloid', 'jordansissel/fpm', 'neo4jrb/neo4j-core', 'orbeon/orbeon-forms', 'redis/redis-rb', 'pivotal/pivotal_workstation', 'jruby/jruby', 'louismullie/treat', 'puma/puma', 'pophealth/popHealth', 'twitter/twitter-cldr-rb', 'gistflow/gistflow', 'adamfisk/LittleProxy', 'awestruct/awestruct', 'jnunemaker/httparty', 'Graylog2/graylog2-server', 'neuland/jade4j', 'sensu/sensu', 'shawn42/gamebox', 'applicationsonline/librarian', 'haml/haml', 'sporkmonger/addressable', 'google/google-api-ruby-client', 'elm-city-craftworks/practicing-ruby-web', 'sunlightlabs/scout', 'floere/phony', 'data-axle/cassandra_object', 'typhoeus/typhoeus', 'shoes/shoes4', 'troessner/reek', 'recurly/recurly-client-ruby', 'CloudifySource/cloudify', 'puppetlabs/puppetlabs-firewall', 'typhoeus/ethon', 'sparklemotion/nokogiri', 'tinkerpop/blueprints', 'tinkerpop/rexster', 'thinkaurelius/titan', 'openSUSE/open-build-service', 'engineyard/ey-cloud-recipes', 'git/git-scm.com', 'honeybadger-io/honeybadger-ruby', 'azagniotov/stubby4j', 'sferik/twitter', 'calagator/calagator', 'openshift/rhc', 'codefirst/AsakusaSatellite', 'DatabaseCleaner/database_cleaner', 'burke/zeus', 'fog/fog', 'twilio/twilio-java', 'twitter/commons', 'Albacore/albacore', 'prawnpdf/prawn', 'enspiral/loomio', 'refinery/refinerycms', 'sevntu-checkstyle/sevntu.checkstyle', 'opal/opal', 'graphhopper/graphhopper', 'sparklemotion/mechanize', 'SomMeri/less4j', 'tent/tentd', 'searchbox-io/Jest', 'square/dagger', 'google/truth', 'square/okhttp', 'square/retrofit', 'maxcom/lorsource', 'jneen/rouge', 'jmkgreen/morphia', 'SpontaneousCMS/spontaneous', 'everzet/capifony', 'killbill/killbill', 'scobal/seyren', 'intuit/simple_deploy', 'projectblacklight/blacklight', 'rapid7/metasploit-framework', 'amahi/platform', 'vcr/vcr', 'Findwise/Hydra', 'structr/structr', 'sachin-handiekar/jInstagram', 'nutzam/nutz', 'slim-template/slim', 'puppetlabs/puppetlabs-stdlib', 'puppetlabs/facter', 'phoet/on_ruby', 'dreamhead/moco', 'travis-ci/travis.rb', 'cloudfoundry/cloud_controller_ng', 'square/assertj-android', 'jmxtrans/jmxtrans', 'twitter/secureheaders', 'nanoc/nanoc', 'expertiza/expertiza', 'asciidoctor/asciidoctor', 'rubber/rubber', 'openMF/mifosx', 'mybatis/mybatis-3', 'test-kitchen/test-kitchen', 'owlcs/owlapi', 'engineyard/engineyard-serverside', 'selendroid/selendroid', 'ruboto/ruboto', 'openfoodfoundation/openfoodnetwork', 'stephanenicolas/robospice', 'joscha/play-authenticate', 'undera/jmeter-plugins', 'cantino/huginn', 'resque/resque', 'albertlatacz/java-repl', 'l0rdn1kk0n/wicket-bootstrap', 'dynjs/dynjs', 'abarisain/dmix', 'dropwizard/dropwizard', 'dropwizard/metrics', 'jberkel/sms-backup-plus', 'rubymotion/sugarcube', 'naver/yobi', 'Shopify/active_shipping', 'projecthydra/sufia', 'rubymotion/BubbleWrap', 'pivotal-sprout/sprout-osx-apps', 'chef/omnibus', 'JodaOrg/joda-time', 'EmmanuelOga/ffaker', 'kostya/eye', 'laurentpetit/ccw', 'puniverse/quasar', 'simpligility/android-maven-plugin', 'jsonld-java/jsonld-java', 'travis-ci/travis-cookbooks', 'FenixEdu/fenixedu-academic', 'threerings/playn', 'restlet/restlet-framework-java', 'jedi4ever/veewee', 'sensu/sensu-community-plugins', 'OpenRefine/OpenRefine', 'chef/chef', 'fluent/fluentd', 'perwendel/spark', 'joelittlejohn/jsonschema2pojo', 'jOOQ/jOOQ', 'springside/springside4', 'github/hub', 'johncarl81/parceler', 'discourse/onebox', 'julianhyde/optiq', 'ruby-ldap/ruby-net-ldap', 'DSpace/DSpace', 'jeremyevans/sequel', 'bikeindex/bike_index', 'doanduyhai/Achilles', 'rackerlabs/blueflood', 'rodjek/librarian-puppet', 'p6spy/p6spy', 'square/wire', 'Nodeclipse/nodeclipse-1', 'rebelidealist/stripe-ruby-mock', 'checkstyle/checkstyle', 'elastic/logstash', 'airlift/airlift', 'lenskit/lenskit', 'MiniProfiler/rack-mini-profiler', 'geoserver/geoserver', 'ocpsoft/rewrite', 'Unidata/thredds', 'torakiki/pdfsam', 'loopj/android-async-http', 'feedbin/feedbin', 'recruit-tech/redpen', 'brettwooldridge/HikariCP', 'puppetlabs/marionette-collective', 'iipc/openwayback', 'caelum/vraptor4', 'dianping/cat', 'jphp-compiler/jphp', 'mockito/mockito', 'oblac/jodd', 'facebook/buck', 'facebook/presto', 'jpos/jPOS', 'hamstergem/hamster', 'mongodb/morphia', 'realestate-com-au/pact', 'inaturalist/inaturalist', 'jtwig/jtwig', 'go-lang-plugin-org/go-lang-idea-plugin', 'square/picasso', 'voltrb/volt', 'zxing/zxing', 'openaustralia/morph', 'GlowstoneMC/Glowstone', 'owncloud/android', 'JakeWharton/u2020', 'rpush/rpush', 'OneBusAway/onebusaway-android', 'rabbit-shocker/rabbit', 'azkaban/azkaban', 'relayrides/pushy', 'deeplearning4j/deeplearning4j', 'github/developer.github.com', 'xetorthio/jedis', 'FasterXML/jackson-core', 'FasterXML/jackson-databind', 'protostuff/protostuff', 'atmos/heaven', 'MrTJP/ProjectRed', 'lemire/RoaringBitmap', 'apache/drill', 'Kapeli/cheatsheets', 'gradle/gradle', 'OpenGrok/OpenGrok', 'spring-io/sagan', 'mendhak/gpslogger', 'thoughtbot/hound', 'teamed/qulice', 'jcabi/jcabi-aspects', 'jcabi/jcabi-github', 'jcabi/jcabi-http', 'yegor256/rultor', 'querydsl/querydsl', 'codevise/pageflow', 'grails/grails-core', 'weld/core', 'thatJavaNerd/JRAW', 'bndtools/bnd', 'igniterealtime/Openfire', 'zendesk/samson', 'bndtools/bndtools', 'xtreemfs/xtreemfs', 'puniverse/capsule', 'broadinstitute/picard', 'github/github-services', 'gavinlaking/vedeu', 'haiwen/seadroid', 'AChep/AcDisplay', 'GoClipse/goclipse', 'hsz/idea-gitignore', 'jsprit/jsprit', 'dblock/waffle', 'numenta/htm.java', 'rightscale/praxis', 'google/error-prone', 'datastax/ruby-driver', 'iluwatar/java-design-patterns', 'Netflix/Hystrix', 'oyachai/HearthSim', 'jayway/JsonPath', 'exteso/alf.io', 'spring-cloud/spring-cloud-config', 'validator/validator', 'HubSpot/jinjava', 'connectbot/connectbot', 'google/physical-web', 'myui/hivemall', 'MarkUsProject/Markus', 'jMonkeyEngine/jmonkeyengine', 'davidmoten/rxjava-jdbc', 'qos-ch/logback', 'Homebrew/homebrew-science', 'GoogleCloudPlatform/DataflowJavaSDK', 'SoftInstigate/restheart', 'naver/pinpoint', 'KronicDeth/intellij-elixir', 'embulk/embulk', 'loomio/loomio', 'openstreetmap/openstreetmap-website', 'activescaffold/active_scaffold', 'tananaev/traccar', 'SonarSource/sonarqube', 'grpc/grpc-java', 'psi-probe/psi-probe', 'orientation/orientation', 'square/keywhiz', 'aws/aws-sdk-java', 'Shopify/shipit-engine', 'perfectsense/brightspot-cms', 'jamesagnew/hapi-fhir']



duration=[]
source_num=[]
source_num=[53819, 3033, 5167, 5289, 415786, 9680, 13826, 10610, 9928, 5052, 4460, 3230, 1872, 2527, 4626, 18435, 3036, 2395, 1587, 11103, 3226, 7700, 3159, 1751, 4789, 2105, 1332, 4506, 5795, 2724, 4044, 2363, 2619, 3596, 3154, 3600, 16739, 6524, 2328, 6354, 15153, 3504, 17088, 16548, 12032, 2859, 6565, 7132, 11448, 7685, 8486, 3174, 1864, 3483, 6048, 4596, 4366, 2455, 9812, 4714, 4198, 6329, 10569, 11928, 16856, 5182, 9429, 5184, 7116, 21429, 3182, 5484, 2405, 8453, 3032, 14359, 2436, 84443, 26106, 2552, 2694, 2115, 2919, 56972, 2970, 2373, 148743, 5421, 3348, 1776, 4556, 2556, 3390, 3921, 1563, 60167, 5377, 2560, 7774, 3380, 2744, 2368, 3084, 2288, 5189, 11108, 1445, 1098, 11721, 3067, 2093, 46692, 1790, 1830, 12037, 16161, 11258, 18190, 29143, 2954, 1838, 2997, 3568, 2530, 4073, 8892, 2892, 1783, 696, 125772, 8892, 26549, 3011, 8476, 19970, 6976, 6748, 19234, 27416, 4483, 19930, 4450, 4468, 3695, 2536, 15686, 3246, 23560, 10439, 12399, 16177, 1554, 63403, 3732, 2286, 6279, 598804, 5133, 3033, 13181, 59020, 3329, 48791, 1552, 3095, 5761, 2262, 5998, 3426, 13728, 18617, 6268, 1558, 6776, 27297, 8895, 8453, 51859, 18886, 4840, 121745, 7162, 26310, 3323, 25745, 7095, 5856, 28265, 7629, 2024, 2993, 13655, 25041, 22162, 12060, 7605, 6632, 6956, 7798, 4984, 6618, 3213, 3314, 4682, 30169, 3672, 4242, 10577, 35792, 15339, 6482, 8597, 320895, 32317, 122503, 14989, 15015, 44909, 49634, 9737, 4194, 3826, 98041, 8611, 699, 4577, 2068, 95265, 2464, 210877, 31415, 9899, 17358, 16185, 1197, 4120, 6434, 92286, 2408, 28991, 11456, 24578, 27541, 1749, 303998, 29431, 429028, 9755, 4934, 7444, 4729, 2296, 12567, 34716, 11214, 65988, 59233, 33268, 82612, 197810, 149663, 43503, 15402, 12399, 5825, 50757, 7118, 38405, 4615, 6658, 34688, 4561, 21968, 27970, 5857, 3950, 23655, 27697, 26612, 1402, 41251, 2140, 12640, 18237, 50343, 46324, 2565, 9634, 6696, 187386, 28421, 167848, 31402, 11458, 7802, 2475, 3765, 2370, 15360, 3178, 5530, 48110, 5153, 62271, 55502, 6403, 71235, 197546, 9471, 40734, 157570, 4826, 25958, 8628, 18305, 21749, 21248, 37444, 4427, 17544, 5786, 14740, 4157, 20796, 11046, 8725, 13000, 25357, 4604, 7942, 3532, 33077, 8998, 15279, 2060, 21994, 20245, 207832, 3281, 29163, 21412, 56486, 11518, 101107, 32303, 10462, 19970, 12181, 9288, 18196, 155481, 35640, 13811, 1447, 8163, 1033909, 3724, 35716, 533998]


X=np.array(source_num)
X=X.reshape(-1,1)
#plot(X)
n_clusters=4
y_pred0 = KMeans(n_clusters=n_clusters).fit_predict(X)
cluster=[]
detail=[]
result=[]
for index in range(n_clusters):
   cluster.append([])
   detail.append([])
   result.append([])
#cluster1=[[],[],[]]

for index in range(len(y_pred0)):
        for item in range(n_clusters):
            if y_pred0[index] == item:
                cluster[item].append(index)
                detail[item].append(source_num[index])
for item in detail:
    print(get_median(item))
#print(y_pred0)

for nameindex in range(len(project_names)):
    file_name = project_names[nameindex] + ".csv"
    file_name = file_name.split("/")[1]
    print(file_name)

    string = "/Users/jinxianhao/Documents/src/python/CI/Data_Base/all_dataset/" + file_name
    csv_file = csv.reader(open(string, 'r'))
    pre = []
    final = []
    for item in csv_file:
        pre.append(item)

    for i in range(len(pre[0])):
        temp = []
        for index in range(1, len(pre)):
            # print(index)
            # print(pre[index][i])
            temp.append(pre[index][i])
        final.append(temp)

    dur=[]
    source=[]

    for index in range(len(final[35])):
        try:
            source.append(float(final[34][index]))
            dur.append(float(final[43][index]))
        except:
            index=index

    duration.append(get_median(dur))
    #test_density.append(sum(test_line)/len(test_line))
    source_num.append(round(get_median(source)))

print(source_num)
#'''

for index in range(len(cluster)):
    for item in cluster[index]:
        try:
            result[index].append(duration[item])
        except:
            print(item)

for item in result:
    print(get_median(item))
    print(sum(item)/len(item))

book = xlwt.Workbook(encoding='utf-8', style_compression=0)
sheet1 = book.add_sheet('source_line', cell_overwrite_ok=True)
sheet2 = book.add_sheet('test_case', cell_overwrite_ok=True)
sheet3 = book.add_sheet('assert_case', cell_overwrite_ok=True)
col=0

for index in range(len(result)):
    string='cluster '+ str(index)
    for item in result[index]:
        sheet1.write(col,0,string)
        sheet1.write(col,1,item)
        col=col+1
book.save(r'cluster_box_duration_source.xls')
#'''