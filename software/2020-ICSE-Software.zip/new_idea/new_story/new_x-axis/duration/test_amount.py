import numpy as np
from sklearn.cluster import DBSCAN
from sklearn.cluster import AffinityPropagation
from sklearn.cluster import KMeans
import csv
import matplotlib.pyplot as plt
import xlwt

'''
X=np.array([1,2,3,4,5,11,12,13,14,15])
X=X.reshape(-1,1)
y_pred = DBSCAN().fit_predict(X)
y_pred = AffinityPropagation().fit_predict(X)
print(y_pred)
'''

def get_median(data):
    data = sorted(data)
    size = len(data)
    if size % 2 == 0:  # 判断列表长度为偶数
        median = (data[size // 2] + data[size // 2 - 1]) / 2
        data[0] = median
    if size % 2 == 1:  # 判断列表长度为奇数
        median = data[(size - 1) // 2]
        data[0] = median
    return data[0]

def plot(X):
    Sum_of_squared_distances = []
    K = range(1, 15)
    for k in K:
        km = KMeans(n_clusters=k)
        km = km.fit(X)
        Sum_of_squared_distances.append(km.inertia_)

    plt.plot(K, Sum_of_squared_distances, 'bx-')
    plt.xlabel('k')
    plt.ylabel('Sum_of_squared_distances')
    plt.title('Elbow Method For Optimal k')
    plt.show()

project_names=['rails/rails', 'myronmarston/vcr', 'concerto/concerto', 'benhoskings/babushka', 'rubinius/rubinius', 'rubychan/coderay', 'codeforamerica/adopt-a-hydrant', 'radiant/radiant', 'saberma/shopqi', 'rspec/rspec-core', 'engineyard/engineyard', 'plataformatec/devise', 'rspec/rspec-rails', 'karmi/retire', 'sferik/rails_admin', 'tdiary/tdiary-core', 'dkubb/veritas', 'sstephenson/sprockets', 'thoughtbot/factory_girl', 'weppos/whois', 'errbit/errbit', 'padrino/padrino-framework', 'thoughtbot/paperclip', 'plataformatec/simple_form', 'huerlisi/bookyt', 'hotsh/rstat.us', 'mperham/dalli', 'innoq/iqvoc', 'cheezy/page-object', 'justinfrench/formtastic', 'nov/fb_graph', 'assaf/vanity', 'activerecord-hackery/ransack', 'jimweirich/rake', 'rspec/rspec-mocks', 'neo4jrb/neo4j', 'diaspora/diaspora', 'test-unit/test-unit', 'Shopify/liquid', 'activeadmin/activeadmin', 'ari/jobsworth', 'thoughtbot/shoulda-matchers', 'rubygems/rubygems', 'rdoc/rdoc', 'spree/spree', 'rubyzip/rubyzip', 'pry/pry', 'jruby/activerecord-jdbc-adapter', 'sass/sass', 'jruby/warbler', 'fatfreecrm/fat_free_crm', 'rspec/rspec-expectations', 'excon/excon', 'typus/typus', 'heroku/heroku', 'nahi/httpclient', 'podio/podio-rb', 'maxdemarzi/neography', 'locomotivecms/engine', 'gedankenstuecke/snpr', 'peter-murach/github', 'jnicklas/capybara', 'travis-ci/travis-core', 'presidentbeef/brakeman', 'mikel/mail', 'randym/axlsx', 'kmuto/review', 'danielweinmann/catarse', 'middleman/middleman', 'rubyworks/facets', 'railsbp/rails_best_practices', 'comfy/comfortable-mexican-sofa', 'mongoid/moped', 'wr0ngway/rubber', 'rslifka/elasticity', 'lsegal/yard', 'NoamB/sorcery', 'puppetlabs/puppet', 'mitchellh/vagrant', 'ai/r18n', 'celluloid/celluloid', 'jordansissel/fpm', 'neo4jrb/neo4j-core', 'orbeon/orbeon-forms', 'redis/redis-rb', 'pivotal/pivotal_workstation', 'jruby/jruby', 'louismullie/treat', 'puma/puma', 'pophealth/popHealth', 'twitter/twitter-cldr-rb', 'gistflow/gistflow', 'adamfisk/LittleProxy', 'awestruct/awestruct', 'jnunemaker/httparty', 'Graylog2/graylog2-server', 'neuland/jade4j', 'sensu/sensu', 'shawn42/gamebox', 'applicationsonline/librarian', 'haml/haml', 'sporkmonger/addressable', 'google/google-api-ruby-client', 'elm-city-craftworks/practicing-ruby-web', 'sunlightlabs/scout', 'floere/phony', 'data-axle/cassandra_object', 'typhoeus/typhoeus', 'shoes/shoes4', 'troessner/reek', 'recurly/recurly-client-ruby', 'CloudifySource/cloudify', 'puppetlabs/puppetlabs-firewall', 'typhoeus/ethon', 'sparklemotion/nokogiri', 'tinkerpop/blueprints', 'tinkerpop/rexster', 'thinkaurelius/titan', 'openSUSE/open-build-service', 'engineyard/ey-cloud-recipes', 'git/git-scm.com', 'honeybadger-io/honeybadger-ruby', 'azagniotov/stubby4j', 'sferik/twitter', 'calagator/calagator', 'openshift/rhc', 'codefirst/AsakusaSatellite', 'DatabaseCleaner/database_cleaner', 'burke/zeus', 'fog/fog', 'twilio/twilio-java', 'twitter/commons', 'Albacore/albacore', 'prawnpdf/prawn', 'enspiral/loomio', 'refinery/refinerycms', 'sevntu-checkstyle/sevntu.checkstyle', 'opal/opal', 'graphhopper/graphhopper', 'sparklemotion/mechanize', 'SomMeri/less4j', 'tent/tentd', 'searchbox-io/Jest', 'square/dagger', 'google/truth', 'square/okhttp', 'square/retrofit', 'maxcom/lorsource', 'jneen/rouge', 'jmkgreen/morphia', 'SpontaneousCMS/spontaneous', 'everzet/capifony', 'killbill/killbill', 'scobal/seyren', 'intuit/simple_deploy', 'projectblacklight/blacklight', 'rapid7/metasploit-framework', 'amahi/platform', 'vcr/vcr', 'Findwise/Hydra', 'structr/structr', 'sachin-handiekar/jInstagram', 'nutzam/nutz', 'slim-template/slim', 'puppetlabs/puppetlabs-stdlib', 'puppetlabs/facter', 'phoet/on_ruby', 'dreamhead/moco', 'travis-ci/travis.rb', 'cloudfoundry/cloud_controller_ng', 'square/assertj-android', 'jmxtrans/jmxtrans', 'twitter/secureheaders', 'nanoc/nanoc', 'expertiza/expertiza', 'asciidoctor/asciidoctor', 'rubber/rubber', 'openMF/mifosx', 'mybatis/mybatis-3', 'test-kitchen/test-kitchen', 'owlcs/owlapi', 'engineyard/engineyard-serverside', 'selendroid/selendroid', 'ruboto/ruboto', 'openfoodfoundation/openfoodnetwork', 'stephanenicolas/robospice', 'joscha/play-authenticate', 'undera/jmeter-plugins', 'cantino/huginn', 'resque/resque', 'albertlatacz/java-repl', 'l0rdn1kk0n/wicket-bootstrap', 'dynjs/dynjs', 'abarisain/dmix', 'dropwizard/dropwizard', 'dropwizard/metrics', 'jberkel/sms-backup-plus', 'rubymotion/sugarcube', 'naver/yobi', 'Shopify/active_shipping', 'projecthydra/sufia', 'rubymotion/BubbleWrap', 'pivotal-sprout/sprout-osx-apps', 'chef/omnibus', 'JodaOrg/joda-time', 'EmmanuelOga/ffaker', 'kostya/eye', 'laurentpetit/ccw', 'puniverse/quasar', 'simpligility/android-maven-plugin', 'jsonld-java/jsonld-java', 'travis-ci/travis-cookbooks', 'FenixEdu/fenixedu-academic', 'threerings/playn', 'restlet/restlet-framework-java', 'jedi4ever/veewee', 'sensu/sensu-community-plugins', 'OpenRefine/OpenRefine', 'chef/chef', 'fluent/fluentd', 'perwendel/spark', 'joelittlejohn/jsonschema2pojo', 'jOOQ/jOOQ', 'springside/springside4', 'github/hub', 'johncarl81/parceler', 'discourse/onebox', 'julianhyde/optiq', 'ruby-ldap/ruby-net-ldap', 'DSpace/DSpace', 'jeremyevans/sequel', 'bikeindex/bike_index', 'doanduyhai/Achilles', 'rackerlabs/blueflood', 'rodjek/librarian-puppet', 'p6spy/p6spy', 'square/wire', 'Nodeclipse/nodeclipse-1', 'rebelidealist/stripe-ruby-mock', 'checkstyle/checkstyle', 'elastic/logstash', 'airlift/airlift', 'lenskit/lenskit', 'MiniProfiler/rack-mini-profiler', 'geoserver/geoserver', 'ocpsoft/rewrite', 'Unidata/thredds', 'torakiki/pdfsam', 'loopj/android-async-http', 'feedbin/feedbin', 'recruit-tech/redpen', 'brettwooldridge/HikariCP', 'puppetlabs/marionette-collective', 'iipc/openwayback', 'caelum/vraptor4', 'dianping/cat', 'jphp-compiler/jphp', 'mockito/mockito', 'oblac/jodd', 'facebook/buck', 'facebook/presto', 'jpos/jPOS', 'hamstergem/hamster', 'mongodb/morphia', 'realestate-com-au/pact', 'inaturalist/inaturalist', 'jtwig/jtwig', 'go-lang-plugin-org/go-lang-idea-plugin', 'square/picasso', 'voltrb/volt', 'zxing/zxing', 'openaustralia/morph', 'GlowstoneMC/Glowstone', 'owncloud/android', 'JakeWharton/u2020', 'rpush/rpush', 'OneBusAway/onebusaway-android', 'rabbit-shocker/rabbit', 'azkaban/azkaban', 'relayrides/pushy', 'deeplearning4j/deeplearning4j', 'github/developer.github.com', 'xetorthio/jedis', 'FasterXML/jackson-core', 'FasterXML/jackson-databind', 'protostuff/protostuff', 'atmos/heaven', 'MrTJP/ProjectRed', 'lemire/RoaringBitmap', 'apache/drill', 'Kapeli/cheatsheets', 'gradle/gradle', 'OpenGrok/OpenGrok', 'spring-io/sagan', 'mendhak/gpslogger', 'thoughtbot/hound', 'teamed/qulice', 'jcabi/jcabi-aspects', 'jcabi/jcabi-github', 'jcabi/jcabi-http', 'yegor256/rultor', 'querydsl/querydsl', 'codevise/pageflow', 'grails/grails-core', 'weld/core', 'thatJavaNerd/JRAW', 'bndtools/bnd', 'igniterealtime/Openfire', 'zendesk/samson', 'bndtools/bndtools', 'xtreemfs/xtreemfs', 'puniverse/capsule', 'broadinstitute/picard', 'github/github-services', 'gavinlaking/vedeu', 'haiwen/seadroid', 'AChep/AcDisplay', 'GoClipse/goclipse', 'hsz/idea-gitignore', 'jsprit/jsprit', 'dblock/waffle', 'numenta/htm.java', 'rightscale/praxis', 'google/error-prone', 'datastax/ruby-driver', 'iluwatar/java-design-patterns', 'Netflix/Hystrix', 'oyachai/HearthSim', 'jayway/JsonPath', 'exteso/alf.io', 'spring-cloud/spring-cloud-config', 'validator/validator', 'HubSpot/jinjava', 'connectbot/connectbot', 'google/physical-web', 'myui/hivemall', 'MarkUsProject/Markus', 'jMonkeyEngine/jmonkeyengine', 'davidmoten/rxjava-jdbc', 'qos-ch/logback', 'Homebrew/homebrew-science', 'GoogleCloudPlatform/DataflowJavaSDK', 'SoftInstigate/restheart', 'naver/pinpoint', 'KronicDeth/intellij-elixir', 'embulk/embulk', 'loomio/loomio', 'openstreetmap/openstreetmap-website', 'activescaffold/active_scaffold', 'tananaev/traccar', 'SonarSource/sonarqube', 'grpc/grpc-java', 'psi-probe/psi-probe', 'orientation/orientation', 'square/keywhiz', 'aws/aws-sdk-java', 'Shopify/shipit-engine', 'perfectsense/brightspot-cms', 'jamesagnew/hapi-fhir']



duration=[]
test_num=[]
test_num=[116764, 5168, 2040, 5755, 170141, 1368, 307, 6761, 7347, 8221, 2386, 6195, 2270, 6228, 7566, 3882, 7831, 3076, 3830, 42026, 3969, 10546, 7060, 4159, 1822, 3219, 1747, 1575, 4602, 9404, 6402, 2813, 1760, 5164, 6502, 6692, 11595, 5769, 3393, 6321, 9805, 4065, 20730, 20582, 9579, 2836, 7761, 6985, 14546, 1867, 11516, 7386, 1321, 1941, 5102, 3099, 379, 4693, 2901, 840, 9198, 1359, 10370, 8513, 10506, 4986, 4785, 2176, 19, 9545, 6503, 3420, 3204, 1661, 38, 12484, 3076, 106015, 13540, 1648, 1399, 905, 2875, 1944, 3794, 39, 383834, 1164, 1418, 872, 5465, 1294, 2015, 1817, 2342, 14967, 2094, 1998, 2313, 2003, 3008, 6058, 1846, 1310, 2839, 446, 1006, 2329, 6630, 6878, 1650, 4070, 5022, 1882, 0, 12677, 7991, 6136, 21179, 0, 537, 3034, 4462, 6219, 4879, 7108, 1565, 2241, 192, 34325, 2072, 13458, 2344, 8881, 7254, 3478, 10448, 10744, 11716, 6234, 2715, 4946, 5737, 2450, 2688, 20822, 4300, 4566, 1689, 17942, 17254, 593, 41521, 1406, 2663, 4298, 12262, 333, 5168, 7293, 13763, 892, 18773, 3013, 3994, 6611, 1660, 4017, 1599, 28306, 0, 2483, 227, 10119, 6590, 15100, 1661, 1078, 28018, 13176, 50936, 2058, 5189, 2361, 8409, 8406, 254, 27126, 6148, 2595, 488, 3083, 6387, 0, 11386, 5556, 2187, 6320, 2222, 4562, 8748, 4246, 39, 5223, 54516, 2120, 7909, 157, 7773, 35294, 2511, 180, 2272, 4733, 29494, 264, 77, 5473, 73144, 7987, 1807, 4516, 5814, 4178, 0, 3234, 82, 35375, 1306, 15842, 56192, 6230, 29061, 6923, 208, 2506, 15652, 1473, 2631, 34153, 6440, 18807, 14619, 1101, 148209, 17464, 77747, 8767, 0, 528, 4657, 3958, 11875, 5840, 12687, 12347, 4954, 21692, 39432, 131353, 51877, 37144, 72, 17942, 981, 17887, 2813, 5440, 3421, 2422, 7316, 814, 965, 2548, 0, 3534, 3552, 1042, 7421, 1431, 2846, 0, 7459, 8673, 32823, 25686, 508, 0, 4932, 50082, 0, 27690, 7465, 4962, 283, 3636, 2707, 1458, 13866, 1874, 3629, 53458, 7599, 7570, 71966, 1815, 22690, 1808, 10696, 305, 27126, 1277, 12023, 9122, 228, 24, 135, 3157, 285, 14710, 7318, 10904, 4415, 21403, 9591, 1333, 16646, 14431, 3617, 795, 2288, 422, 4044, 1036, 8, 2659, 19850, 24502, 2563, 27756, 0, 47278, 4040, 28124, 11897, 3048, 7254, 15127, 2968, 3168, 153405, 12596, 1537, 988, 6600, 15575, 3704, 0, 65905]

X=np.array(test_num)
X=X.reshape(-1,1)
#plot(X)
n_clusters=4
y_pred0 = KMeans(n_clusters=n_clusters).fit_predict(X)
cluster=[]
detail=[]
result=[]
for index in range(n_clusters):
   cluster.append([])
   detail.append([])
   result.append([])
#cluster1=[[],[],[]]
for index in range(len(y_pred0)):
        for item in range(n_clusters):
            if y_pred0[index] == item:
                cluster[item].append(index)
                detail[item].append(test_num[index])
for item in detail:
    print(get_median(item))
#print(y_pred0)
#'''
for nameindex in range(len(project_names)):
    file_name = project_names[nameindex] + ".csv"
    file_name = file_name.split("/")[1]
    print(file_name)

    string = "/Users/jinxianhao/Documents/src/python/CI/Data_Base/all_dataset/" + file_name
    csv_file = csv.reader(open(string, 'r'))
    pre = []
    final = []
    for item in csv_file:
        pre.append(item)

    for i in range(len(pre[0])):
        temp = []
        for index in range(1, len(pre)):
            # print(index)
            # print(pre[index][i])
            temp.append(pre[index][i])
        final.append(temp)

    dur=[]
    test_line=[]
    test_case=[]
    assert_case=[]

    for index in range(len(final[35])):
        try:
            test_line.append(float(final[35][index])*float(final[34][index])/1000)
            test_case.append(float(final[36][index])*float(final[34][index])/1000)
            assert_case.append(float(final[37][index])*float(final[34][index])/1000)
            dur.append(float(final[43][index]))
        except:
            index=index

    duration.append(get_median(dur))
    #test_density.append(sum(test_line)/len(test_line))
    test_num.append(round(get_median(test_line)))
    '''
print(test_num)
'''

for index in range(len(cluster)):
    for item in cluster[index]:
        try:
            result[index].append(duration[item])
        except:
            print(item)

for item in result:
    print(get_median(item))
    print(sum(item)/len(item))

book = xlwt.Workbook(encoding='utf-8', style_compression=0)
sheet1 = book.add_sheet('test_line', cell_overwrite_ok=True)
sheet2 = book.add_sheet('test_case', cell_overwrite_ok=True)
sheet3 = book.add_sheet('assert_case', cell_overwrite_ok=True)
col=0

for index in range(len(result)):
    string='cluster '+ str(index)
    for item in result[index]:
        sheet1.write(col,0,string)
        sheet1.write(col,1,item)
        col=col+1
book.save(r'cluster_box_duration.xls')
#'''