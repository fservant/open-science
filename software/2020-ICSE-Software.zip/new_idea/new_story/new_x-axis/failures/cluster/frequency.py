import numpy as np
from sklearn.cluster import DBSCAN
from sklearn.cluster import AffinityPropagation
from sklearn.cluster import KMeans
import csv
import matplotlib.pyplot as plt
import xlwt
import time

'''
X=np.array([1,2,3,4,5,11,12,13,14,15])
X=X.reshape(-1,1)
y_pred = DBSCAN().fit_predict(X)
y_pred = AffinityPropagation().fit_predict(X)
print(y_pred)
'''

def get_median(data):
    data = sorted(data)
    size = len(data)
    if size % 2 == 0:  # 判断列表长度为偶数
        median = (data[size // 2] + data[size // 2 - 1]) / 2
        data[0] = median
    if size % 2 == 1:  # 判断列表长度为奇数
        median = data[(size - 1) // 2]
        data[0] = median
    return data[0]

def plot(X):
    Sum_of_squared_distances = []
    K = range(1, 15)
    for k in K:
        km = KMeans(n_clusters=k)
        km = km.fit(X)
        Sum_of_squared_distances.append(km.inertia_)

    plt.plot(K, Sum_of_squared_distances, 'bx-')
    plt.xlabel('k')
    plt.ylabel('Sum_of_squared_distances')
    plt.title('Elbow Method For Optimal k')
    plt.show()

project_names=['rails/rails', 'myronmarston/vcr', 'concerto/concerto', 'benhoskings/babushka', 'rubinius/rubinius', 'rubychan/coderay', 'codeforamerica/adopt-a-hydrant', 'radiant/radiant', 'saberma/shopqi', 'rspec/rspec-core', 'engineyard/engineyard', 'plataformatec/devise', 'rspec/rspec-rails', 'karmi/retire', 'sferik/rails_admin', 'tdiary/tdiary-core', 'dkubb/veritas', 'sstephenson/sprockets', 'thoughtbot/factory_girl', 'weppos/whois', 'errbit/errbit', 'padrino/padrino-framework', 'thoughtbot/paperclip', 'plataformatec/simple_form', 'huerlisi/bookyt', 'hotsh/rstat.us', 'mperham/dalli', 'innoq/iqvoc', 'cheezy/page-object', 'justinfrench/formtastic', 'nov/fb_graph', 'assaf/vanity', 'activerecord-hackery/ransack', 'jimweirich/rake', 'rspec/rspec-mocks', 'neo4jrb/neo4j', 'diaspora/diaspora', 'test-unit/test-unit', 'Shopify/liquid', 'activeadmin/activeadmin', 'ari/jobsworth', 'thoughtbot/shoulda-matchers', 'rubygems/rubygems', 'rdoc/rdoc', 'spree/spree', 'rubyzip/rubyzip', 'pry/pry', 'jruby/activerecord-jdbc-adapter', 'sass/sass', 'jruby/warbler', 'fatfreecrm/fat_free_crm', 'rspec/rspec-expectations', 'excon/excon', 'typus/typus', 'heroku/heroku', 'nahi/httpclient', 'podio/podio-rb', 'maxdemarzi/neography', 'locomotivecms/engine', 'gedankenstuecke/snpr', 'peter-murach/github', 'jnicklas/capybara', 'travis-ci/travis-core', 'presidentbeef/brakeman', 'mikel/mail', 'randym/axlsx', 'kmuto/review', 'danielweinmann/catarse', 'middleman/middleman', 'rubyworks/facets', 'railsbp/rails_best_practices', 'comfy/comfortable-mexican-sofa', 'mongoid/moped', 'wr0ngway/rubber', 'rslifka/elasticity', 'lsegal/yard', 'NoamB/sorcery', 'puppetlabs/puppet', 'mitchellh/vagrant', 'ai/r18n', 'celluloid/celluloid', 'jordansissel/fpm', 'neo4jrb/neo4j-core', 'orbeon/orbeon-forms', 'redis/redis-rb', 'pivotal/pivotal_workstation', 'jruby/jruby', 'louismullie/treat', 'puma/puma', 'pophealth/popHealth', 'twitter/twitter-cldr-rb', 'gistflow/gistflow', 'adamfisk/LittleProxy', 'awestruct/awestruct', 'jnunemaker/httparty', 'Graylog2/graylog2-server', 'neuland/jade4j', 'sensu/sensu', 'shawn42/gamebox', 'applicationsonline/librarian', 'haml/haml', 'sporkmonger/addressable', 'google/google-api-ruby-client', 'elm-city-craftworks/practicing-ruby-web', 'sunlightlabs/scout', 'floere/phony', 'data-axle/cassandra_object', 'typhoeus/typhoeus', 'shoes/shoes4', 'troessner/reek', 'recurly/recurly-client-ruby', 'CloudifySource/cloudify', 'puppetlabs/puppetlabs-firewall', 'typhoeus/ethon', 'sparklemotion/nokogiri', 'tinkerpop/blueprints', 'tinkerpop/rexster', 'thinkaurelius/titan', 'openSUSE/open-build-service', 'engineyard/ey-cloud-recipes', 'git/git-scm.com', 'honeybadger-io/honeybadger-ruby', 'azagniotov/stubby4j', 'sferik/twitter', 'calagator/calagator', 'openshift/rhc', 'codefirst/AsakusaSatellite', 'DatabaseCleaner/database_cleaner', 'burke/zeus', 'fog/fog', 'twilio/twilio-java', 'twitter/commons', 'Albacore/albacore', 'prawnpdf/prawn', 'enspiral/loomio', 'refinery/refinerycms', 'sevntu-checkstyle/sevntu.checkstyle', 'opal/opal', 'graphhopper/graphhopper', 'sparklemotion/mechanize', 'SomMeri/less4j', 'tent/tentd', 'searchbox-io/Jest', 'square/dagger', 'google/truth', 'square/okhttp', 'square/retrofit', 'maxcom/lorsource', 'jneen/rouge', 'jmkgreen/morphia', 'SpontaneousCMS/spontaneous', 'everzet/capifony', 'killbill/killbill', 'scobal/seyren', 'intuit/simple_deploy', 'projectblacklight/blacklight', 'rapid7/metasploit-framework', 'amahi/platform', 'vcr/vcr', 'Findwise/Hydra', 'structr/structr', 'sachin-handiekar/jInstagram', 'nutzam/nutz', 'slim-template/slim', 'puppetlabs/puppetlabs-stdlib', 'puppetlabs/facter', 'phoet/on_ruby', 'dreamhead/moco', 'travis-ci/travis.rb', 'cloudfoundry/cloud_controller_ng', 'square/assertj-android', 'jmxtrans/jmxtrans', 'twitter/secureheaders', 'nanoc/nanoc', 'expertiza/expertiza', 'asciidoctor/asciidoctor', 'rubber/rubber', 'openMF/mifosx', 'mybatis/mybatis-3', 'test-kitchen/test-kitchen', 'owlcs/owlapi', 'engineyard/engineyard-serverside', 'selendroid/selendroid', 'ruboto/ruboto', 'openfoodfoundation/openfoodnetwork', 'stephanenicolas/robospice', 'joscha/play-authenticate', 'undera/jmeter-plugins', 'cantino/huginn', 'resque/resque', 'albertlatacz/java-repl', 'l0rdn1kk0n/wicket-bootstrap', 'dynjs/dynjs', 'abarisain/dmix', 'dropwizard/dropwizard', 'dropwizard/metrics', 'jberkel/sms-backup-plus', 'rubymotion/sugarcube', 'naver/yobi', 'Shopify/active_shipping', 'projecthydra/sufia', 'rubymotion/BubbleWrap', 'pivotal-sprout/sprout-osx-apps', 'chef/omnibus', 'JodaOrg/joda-time', 'EmmanuelOga/ffaker', 'kostya/eye', 'laurentpetit/ccw', 'puniverse/quasar', 'simpligility/android-maven-plugin', 'jsonld-java/jsonld-java', 'travis-ci/travis-cookbooks', 'FenixEdu/fenixedu-academic', 'threerings/playn', 'restlet/restlet-framework-java', 'jedi4ever/veewee', 'sensu/sensu-community-plugins', 'OpenRefine/OpenRefine', 'chef/chef', 'fluent/fluentd', 'perwendel/spark', 'joelittlejohn/jsonschema2pojo', 'jOOQ/jOOQ', 'springside/springside4', 'github/hub', 'johncarl81/parceler', 'discourse/onebox', 'julianhyde/optiq', 'ruby-ldap/ruby-net-ldap', 'DSpace/DSpace', 'jeremyevans/sequel', 'bikeindex/bike_index', 'doanduyhai/Achilles', 'rackerlabs/blueflood', 'rodjek/librarian-puppet', 'p6spy/p6spy', 'square/wire', 'Nodeclipse/nodeclipse-1', 'rebelidealist/stripe-ruby-mock', 'checkstyle/checkstyle', 'elastic/logstash', 'airlift/airlift', 'lenskit/lenskit', 'MiniProfiler/rack-mini-profiler', 'geoserver/geoserver', 'ocpsoft/rewrite', 'Unidata/thredds', 'torakiki/pdfsam', 'loopj/android-async-http', 'feedbin/feedbin', 'recruit-tech/redpen', 'brettwooldridge/HikariCP', 'puppetlabs/marionette-collective', 'iipc/openwayback', 'caelum/vraptor4', 'dianping/cat', 'jphp-compiler/jphp', 'mockito/mockito', 'oblac/jodd', 'facebook/buck', 'facebook/presto', 'jpos/jPOS', 'hamstergem/hamster', 'mongodb/morphia', 'realestate-com-au/pact', 'inaturalist/inaturalist', 'jtwig/jtwig', 'go-lang-plugin-org/go-lang-idea-plugin', 'square/picasso', 'voltrb/volt', 'zxing/zxing', 'openaustralia/morph', 'GlowstoneMC/Glowstone', 'owncloud/android', 'JakeWharton/u2020', 'rpush/rpush', 'OneBusAway/onebusaway-android', 'rabbit-shocker/rabbit', 'azkaban/azkaban', 'relayrides/pushy', 'deeplearning4j/deeplearning4j', 'github/developer.github.com', 'xetorthio/jedis', 'FasterXML/jackson-core', 'FasterXML/jackson-databind', 'protostuff/protostuff', 'atmos/heaven', 'MrTJP/ProjectRed', 'lemire/RoaringBitmap', 'apache/drill', 'Kapeli/cheatsheets', 'gradle/gradle', 'OpenGrok/OpenGrok', 'spring-io/sagan', 'mendhak/gpslogger', 'thoughtbot/hound', 'teamed/qulice', 'jcabi/jcabi-aspects', 'jcabi/jcabi-github', 'jcabi/jcabi-http', 'yegor256/rultor', 'querydsl/querydsl', 'codevise/pageflow', 'grails/grails-core', 'weld/core', 'thatJavaNerd/JRAW', 'bndtools/bnd', 'igniterealtime/Openfire', 'zendesk/samson', 'bndtools/bndtools', 'xtreemfs/xtreemfs', 'puniverse/capsule', 'broadinstitute/picard', 'github/github-services', 'gavinlaking/vedeu', 'haiwen/seadroid', 'AChep/AcDisplay', 'GoClipse/goclipse', 'hsz/idea-gitignore', 'jsprit/jsprit', 'dblock/waffle', 'numenta/htm.java', 'rightscale/praxis', 'google/error-prone', 'datastax/ruby-driver', 'iluwatar/java-design-patterns', 'Netflix/Hystrix', 'oyachai/HearthSim', 'jayway/JsonPath', 'exteso/alf.io', 'spring-cloud/spring-cloud-config', 'validator/validator', 'HubSpot/jinjava', 'connectbot/connectbot', 'google/physical-web', 'myui/hivemall', 'MarkUsProject/Markus', 'jMonkeyEngine/jmonkeyengine', 'davidmoten/rxjava-jdbc', 'qos-ch/logback', 'Homebrew/homebrew-science', 'GoogleCloudPlatform/DataflowJavaSDK', 'SoftInstigate/restheart', 'naver/pinpoint', 'KronicDeth/intellij-elixir', 'embulk/embulk', 'loomio/loomio', 'openstreetmap/openstreetmap-website', 'activescaffold/active_scaffold', 'tananaev/traccar', 'SonarSource/sonarqube', 'grpc/grpc-java', 'psi-probe/psi-probe', 'orientation/orientation', 'square/keywhiz', 'aws/aws-sdk-java', 'Shopify/shipit-engine', 'perfectsense/brightspot-cms', 'jamesagnew/hapi-fhir']



fail_length=[]
time_length=[]
time_length=[4120.0, 49481, 6011.5, 61462.5, 9313.0, 2251.5, 105424, 14381, 9587, 21163, 60542.0, 38561, 43303.5, 23282, 40710, 39504.5, 2570.0, 4276.5, 14968.5, 12739, 36573, 12689.5, 15015.5, 41517.5, 12276, 14489.0, 66263, 5793, 7794, 35261, 9670.0, 92531.0, 74849.0, 4602, 29782.0, 14145.0, 4052, 874.0, 17432.5, 18896.5, 40728, 25504, 4680.5, 3898, 3926.5, 118127, 9613, 74323, 74935, 45469, 12507.0, 41279, 24113, 1914, 4235.0, 7114, 67976, 14164.5, 39729, 9787, 6403.5, 34483, 12616.5, 35242.5, 4448, 7013, 14712.5, 6236.0, 19904.5, 2489.5, 53072, 8658.0, 1929, 11543, 2271, 11667.0, 69793.0, 9095.0, 1194.5, 6203, 6670.5, 4816.5, 18952.5, 15640, 3771.0, 5285.5, 4402.0, 7757, 8671.5, 13568, 47810, 4780, 64019, 1282, 84283.5, 4629, 1088, 3345.5, 50816.0, 3231, 36559, 2838, 69301.5, 8309.5, 3543, 3684.0, 9106.0, 37094, 24249, 28078.5, 72444.0, 4805.0, 60561.0, 24773.5, 30487, 27032, 26838, 43359.0, 5642, 103831.5, 126558.5, 13314.0, 1189.0, 34033, 10838, 13296.5, 6813.5, 69516, 11719.0, 8467.5, 1634.5, 17278, 12143.0, 15014.5, 2191, 22437.0, 37997, 4750.0, 19917.5, 35475, 7978.5, 7969, 39633.5, 6381.0, 68072, 8540, 16059, 9405, 23280.0, 22166.0, 16898.5, 110968.5, 12405.5, 38452, 8319, 5588, 4340, 28194, 49481, 33921, 18338.0, 39926.0, 28671, 49687.5, 112437, 68976.0, 44178, 85232.5, 10498.5, 6491.0, 33882, 30438, 17156, 3814, 7171.0, 4537, 11543, 5917, 47939.0, 45153.5, 44459.0, 81100, 13465.0, 24623.0, 8830.0, 6380.5, 11738.0, 43079.0, 19947.5, 15907, 5650.5, 14571.0, 44914.5, 5921, 21437, 21041.0, 6642.0, 39351.0, 3425, 22346, 4023.5, 16523, 6346.0, 48496, 23590, 13451.0, 40712.5, 15104.5, 20202, 21125, 4027.0, 12197.0, 6026, 68899.5, 8864.0, 24982, 6952.5, 51141.5, 6877, 25620.5, 30464, 55928.5, 4276, 11850.5, 31402, 55501.5, 76758.0, 25550, 7300.5, 12101, 92925.5, 5908, 8053.5, 14486.0, 24510.5, 13831.0, 6746.0, 71834, 76348.5, 3376, 12250.5, 61191.5, 28422.5, 136212.5, 17025.5, 39616, 30818.0, 52747, 6226.0, 7624.0, 18868, 808.5, 59448.5, 15566.5, 5265, 5867, 17480.0, 18166, 64542, 7211, 6137, 86086, 9668.5, 22166.0, 8477, 11719.5, 2308, 8483.5, 17821, 6384, 62325.0, 3402, 75819.0, 15924.0, 3679, 3503.5, 7485.0, 1102, 76865, 9152, 7410.5, 25719.0, 38268.5, 42074.0, 10076, 15257, 18124.0, 44145.0, 2077, 73092.5, 17139, 4431.0, 74610, 67002.5, 5394, 6457, 64333, 86352, 64364, 86387.0, 3906.5, 10060, 644.0, 10375.0, 15592, 2965.5, 14494.0, 12432.0, 5200, 21975.5, 60263, 9186, 21543.0, 24401, 442.5, 14834, 9086.0, 79675, 8717.5, 6785, 30821, 8445.5, 50464, 69889, 22605.5, 53028.5, 7997.5, 34874.0, 5124, 9689.5, 73636, 4760.5, 12807.5, 9013, 9799, 18802.5, 9988, 7650.5, 1352.5, 6021.5, 5010.5, 17090, 33104, 6915, 40649.5, 2873, 2191, 71447.0, 79340.0, 4839, 3201.0, 8597.0, 9477, 1006.0, 4434.0, 100298.0, 7904.5, 4074.5, 15093.0]

#'''
X=np.array(time_length)
X=X.reshape(-1,1)
plot(X)
n_clusters=3
y_pred0 = KMeans(n_clusters=n_clusters).fit_predict(X)
cluster=[]
detail=[]
result=[]
for index in range(n_clusters):
   cluster.append([])
   detail.append([])
   result.append([])
#cluster1=[[],[],[]]
for index in range(len(y_pred0)):
        for item in range(n_clusters):
            if y_pred0[index] == item:
                cluster[item].append(index)
                detail[item].append(time_length[index])
for item in detail:
    print(get_median(item))
#'''
for nameindex in range(len(project_names)):
    file_name = project_names[nameindex] + ".csv"
    file_name = file_name.split("/")[1]
    print(file_name)

    string = "/Users/jinxianhao/Documents/src/python/CI/Data_Base/all_dataset/" + file_name
    csv_file = csv.reader(open(string, 'r'))
    pre = []
    final = []
    for item in csv_file:
        pre.append(item)

    for i in range(len(pre[0])):
        temp = []
        for index in range(1, len(pre)):
            # print(index)
            # print(pre[index][i])
            temp.append(pre[index][i])
        final.append(temp)

    indices = []
    for index in range(len(final[42])):
        if final[42][index] == 'passed':
            if final[42][index - 1] == 'failed':
                indices.append(index)
    if final[42][len(final[42]) - 1] == 'failed':
        indices.append(len(final[42]))
    #print(final[42])
    #print(indices)
    timestamp = []
    for item in final[41]:
        tm = time.strptime(item, '%Y-%m-%d %H:%M:%S')
        times = int(time.mktime(tm))
        timestamp.append(times)

    frequency = []
    for index in range(1, len(timestamp)):
        frequency.append(timestamp[index] - timestamp[index - 1])

    fails=[]
    for item in indices:
        tmp = 0
        temp = item - 1

        while (final[42][temp - 1] != 'failed'):
            temp = temp - 1
            if temp <= 0:
                break

        if temp >= 1:
            fails.append(item-temp)
    if final[42][0]=='failed':
        fails.append(1)
    if len(fails)!=0:
        fail_length.append(get_median(fails))
    else:
        fail_length.append(0)
    #test_density.append(sum(test_line)/len(test_line))
    time_length.append(get_median(frequency))
    #'''
#print(time_length)
#'''

for index in range(len(cluster)):
    for item in cluster[index]:
        try:
            result[index].append(fail_length[item])
        except:
            print(item)

for item in result:
    print(get_median(item))
    print(sum(item)/len(item))

book = xlwt.Workbook(encoding='utf-8', style_compression=0)
sheet1 = book.add_sheet('test_line', cell_overwrite_ok=True)
sheet2 = book.add_sheet('test_case', cell_overwrite_ok=True)
sheet3 = book.add_sheet('assert_case', cell_overwrite_ok=True)
col=0

for index in range(len(result)):
    string='cluster '+ str(index)
    for item in result[index]:
        sheet1.write(col,0,string)
        sheet1.write(col,1,item)
        col=col+1
book.save(r'cluster_fail_length_frequency.xls')
#'''