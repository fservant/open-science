from scipy import stats
a=[3,1,2,3,4,5,6]
list2={}.fromkeys(a).keys()
print(sorted(list2))
print(a)
from decimal import *
a=Decimal(50.11111).quantize(Decimal('0.00'))
b=float(a*100)
print(b)
a=[0.1,0.8,0.2,0.1,0.3]
print(stats.chisquare(a))