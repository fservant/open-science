import numpy as np
from sklearn.cluster import DBSCAN
from sklearn.cluster import AffinityPropagation
from sklearn.cluster import KMeans
import csv
import matplotlib.pyplot as plt
import xlwt
import time
import scipy.stats as stats

'''
X=np.array([1,2,3,4,5,11,12,13,14,15])
X=X.reshape(-1,1)
y_pred = DBSCAN().fit_predict(X)
y_pred = AffinityPropagation().fit_predict(X)
print(y_pred)
'''

def get_median(data):
    data = sorted(data)
    size = len(data)
    if size % 2 == 0:  # 判断列表长度为偶数
        median = (data[size // 2] + data[size // 2 - 1]) / 2
        data[0] = median
    if size % 2 == 1:  # 判断列表长度为奇数
        median = data[(size - 1) // 2]
        data[0] = median
    return data[0]

def plot(X):
    Sum_of_squared_distances = []
    K = range(1, 15)
    for k in K:
        km = KMeans(n_clusters=k)
        km = km.fit(X)
        Sum_of_squared_distances.append(km.inertia_)

    plt.plot(K, Sum_of_squared_distances, 'bx-')
    plt.xlabel('k')
    plt.ylabel('Sum_of_squared_distances')
    plt.title('Elbow Method For Optimal k')
    plt.show()

project_names=['rails/rails', 'myronmarston/vcr', 'concerto/concerto', 'benhoskings/babushka', 'rubinius/rubinius', 'rubychan/coderay', 'codeforamerica/adopt-a-hydrant', 'radiant/radiant', 'saberma/shopqi', 'rspec/rspec-core', 'engineyard/engineyard', 'plataformatec/devise', 'rspec/rspec-rails', 'karmi/retire', 'sferik/rails_admin', 'tdiary/tdiary-core', 'dkubb/veritas', 'sstephenson/sprockets', 'thoughtbot/factory_girl', 'weppos/whois', 'errbit/errbit', 'padrino/padrino-framework', 'thoughtbot/paperclip', 'plataformatec/simple_form', 'huerlisi/bookyt', 'hotsh/rstat.us', 'mperham/dalli', 'innoq/iqvoc', 'cheezy/page-object', 'justinfrench/formtastic', 'nov/fb_graph', 'assaf/vanity', 'activerecord-hackery/ransack', 'jimweirich/rake', 'rspec/rspec-mocks', 'neo4jrb/neo4j', 'diaspora/diaspora', 'test-unit/test-unit', 'Shopify/liquid', 'activeadmin/activeadmin', 'ari/jobsworth', 'thoughtbot/shoulda-matchers', 'rubygems/rubygems', 'rdoc/rdoc', 'spree/spree', 'rubyzip/rubyzip', 'pry/pry', 'jruby/activerecord-jdbc-adapter', 'sass/sass', 'jruby/warbler', 'fatfreecrm/fat_free_crm', 'rspec/rspec-expectations', 'excon/excon', 'typus/typus', 'heroku/heroku', 'nahi/httpclient', 'podio/podio-rb', 'maxdemarzi/neography', 'locomotivecms/engine', 'gedankenstuecke/snpr', 'peter-murach/github', 'jnicklas/capybara', 'travis-ci/travis-core', 'presidentbeef/brakeman', 'mikel/mail', 'randym/axlsx', 'kmuto/review', 'danielweinmann/catarse', 'middleman/middleman', 'rubyworks/facets', 'railsbp/rails_best_practices', 'comfy/comfortable-mexican-sofa', 'mongoid/moped', 'wr0ngway/rubber', 'rslifka/elasticity', 'lsegal/yard', 'NoamB/sorcery', 'puppetlabs/puppet', 'mitchellh/vagrant', 'ai/r18n', 'celluloid/celluloid', 'jordansissel/fpm', 'neo4jrb/neo4j-core', 'orbeon/orbeon-forms', 'redis/redis-rb', 'pivotal/pivotal_workstation', 'jruby/jruby', 'louismullie/treat', 'puma/puma', 'pophealth/popHealth', 'twitter/twitter-cldr-rb', 'gistflow/gistflow', 'adamfisk/LittleProxy', 'awestruct/awestruct', 'jnunemaker/httparty', 'Graylog2/graylog2-server', 'neuland/jade4j', 'sensu/sensu', 'shawn42/gamebox', 'applicationsonline/librarian', 'haml/haml', 'sporkmonger/addressable', 'google/google-api-ruby-client', 'elm-city-craftworks/practicing-ruby-web', 'sunlightlabs/scout', 'floere/phony', 'data-axle/cassandra_object', 'typhoeus/typhoeus', 'shoes/shoes4', 'troessner/reek', 'recurly/recurly-client-ruby', 'CloudifySource/cloudify', 'puppetlabs/puppetlabs-firewall', 'typhoeus/ethon', 'sparklemotion/nokogiri', 'tinkerpop/blueprints', 'tinkerpop/rexster', 'thinkaurelius/titan', 'openSUSE/open-build-service', 'engineyard/ey-cloud-recipes', 'git/git-scm.com', 'honeybadger-io/honeybadger-ruby', 'azagniotov/stubby4j', 'sferik/twitter', 'calagator/calagator', 'openshift/rhc', 'codefirst/AsakusaSatellite', 'DatabaseCleaner/database_cleaner', 'burke/zeus', 'fog/fog', 'twilio/twilio-java', 'twitter/commons', 'Albacore/albacore', 'prawnpdf/prawn', 'enspiral/loomio', 'refinery/refinerycms', 'sevntu-checkstyle/sevntu.checkstyle', 'opal/opal', 'graphhopper/graphhopper', 'sparklemotion/mechanize', 'SomMeri/less4j', 'tent/tentd', 'searchbox-io/Jest', 'square/dagger', 'google/truth', 'square/okhttp', 'square/retrofit', 'maxcom/lorsource', 'jneen/rouge', 'jmkgreen/morphia', 'SpontaneousCMS/spontaneous', 'everzet/capifony', 'killbill/killbill', 'scobal/seyren', 'intuit/simple_deploy', 'projectblacklight/blacklight', 'rapid7/metasploit-framework', 'amahi/platform', 'vcr/vcr', 'Findwise/Hydra', 'structr/structr', 'sachin-handiekar/jInstagram', 'nutzam/nutz', 'slim-template/slim', 'puppetlabs/puppetlabs-stdlib', 'puppetlabs/facter', 'phoet/on_ruby', 'dreamhead/moco', 'travis-ci/travis.rb', 'cloudfoundry/cloud_controller_ng', 'square/assertj-android', 'jmxtrans/jmxtrans', 'twitter/secureheaders', 'nanoc/nanoc', 'expertiza/expertiza', 'asciidoctor/asciidoctor', 'rubber/rubber', 'openMF/mifosx', 'mybatis/mybatis-3', 'test-kitchen/test-kitchen', 'owlcs/owlapi', 'engineyard/engineyard-serverside', 'selendroid/selendroid', 'ruboto/ruboto', 'openfoodfoundation/openfoodnetwork', 'stephanenicolas/robospice', 'joscha/play-authenticate', 'undera/jmeter-plugins', 'cantino/huginn', 'resque/resque', 'albertlatacz/java-repl', 'l0rdn1kk0n/wicket-bootstrap', 'dynjs/dynjs', 'abarisain/dmix', 'dropwizard/dropwizard', 'dropwizard/metrics', 'jberkel/sms-backup-plus', 'rubymotion/sugarcube', 'naver/yobi', 'Shopify/active_shipping', 'projecthydra/sufia', 'rubymotion/BubbleWrap', 'pivotal-sprout/sprout-osx-apps', 'chef/omnibus', 'JodaOrg/joda-time', 'EmmanuelOga/ffaker', 'kostya/eye', 'laurentpetit/ccw', 'puniverse/quasar', 'simpligility/android-maven-plugin', 'jsonld-java/jsonld-java', 'travis-ci/travis-cookbooks', 'FenixEdu/fenixedu-academic', 'threerings/playn', 'restlet/restlet-framework-java', 'jedi4ever/veewee', 'sensu/sensu-community-plugins', 'OpenRefine/OpenRefine', 'chef/chef', 'fluent/fluentd', 'perwendel/spark', 'joelittlejohn/jsonschema2pojo', 'jOOQ/jOOQ', 'springside/springside4', 'github/hub', 'johncarl81/parceler', 'discourse/onebox', 'julianhyde/optiq', 'ruby-ldap/ruby-net-ldap', 'DSpace/DSpace', 'jeremyevans/sequel', 'bikeindex/bike_index', 'doanduyhai/Achilles', 'rackerlabs/blueflood', 'rodjek/librarian-puppet', 'p6spy/p6spy', 'square/wire', 'Nodeclipse/nodeclipse-1', 'rebelidealist/stripe-ruby-mock', 'checkstyle/checkstyle', 'elastic/logstash', 'airlift/airlift', 'lenskit/lenskit', 'MiniProfiler/rack-mini-profiler', 'geoserver/geoserver', 'ocpsoft/rewrite', 'Unidata/thredds', 'torakiki/pdfsam', 'loopj/android-async-http', 'feedbin/feedbin', 'recruit-tech/redpen', 'brettwooldridge/HikariCP', 'puppetlabs/marionette-collective', 'iipc/openwayback', 'caelum/vraptor4', 'dianping/cat', 'jphp-compiler/jphp', 'mockito/mockito', 'oblac/jodd', 'facebook/buck', 'facebook/presto', 'jpos/jPOS', 'hamstergem/hamster', 'mongodb/morphia', 'realestate-com-au/pact', 'inaturalist/inaturalist', 'jtwig/jtwig', 'go-lang-plugin-org/go-lang-idea-plugin', 'square/picasso', 'voltrb/volt', 'zxing/zxing', 'openaustralia/morph', 'GlowstoneMC/Glowstone', 'owncloud/android', 'JakeWharton/u2020', 'rpush/rpush', 'OneBusAway/onebusaway-android', 'rabbit-shocker/rabbit', 'azkaban/azkaban', 'relayrides/pushy', 'deeplearning4j/deeplearning4j', 'github/developer.github.com', 'xetorthio/jedis', 'FasterXML/jackson-core', 'FasterXML/jackson-databind', 'protostuff/protostuff', 'atmos/heaven', 'MrTJP/ProjectRed', 'lemire/RoaringBitmap', 'apache/drill', 'Kapeli/cheatsheets', 'gradle/gradle', 'OpenGrok/OpenGrok', 'spring-io/sagan', 'mendhak/gpslogger', 'thoughtbot/hound', 'teamed/qulice', 'jcabi/jcabi-aspects', 'jcabi/jcabi-github', 'jcabi/jcabi-http', 'yegor256/rultor', 'querydsl/querydsl', 'codevise/pageflow', 'grails/grails-core', 'weld/core', 'thatJavaNerd/JRAW', 'bndtools/bnd', 'igniterealtime/Openfire', 'zendesk/samson', 'bndtools/bndtools', 'xtreemfs/xtreemfs', 'puniverse/capsule', 'broadinstitute/picard', 'github/github-services', 'gavinlaking/vedeu', 'haiwen/seadroid', 'AChep/AcDisplay', 'GoClipse/goclipse', 'hsz/idea-gitignore', 'jsprit/jsprit', 'dblock/waffle', 'numenta/htm.java', 'rightscale/praxis', 'google/error-prone', 'datastax/ruby-driver', 'iluwatar/java-design-patterns', 'Netflix/Hystrix', 'oyachai/HearthSim', 'jayway/JsonPath', 'exteso/alf.io', 'spring-cloud/spring-cloud-config', 'validator/validator', 'HubSpot/jinjava', 'connectbot/connectbot', 'google/physical-web', 'myui/hivemall', 'MarkUsProject/Markus', 'jMonkeyEngine/jmonkeyengine', 'davidmoten/rxjava-jdbc', 'qos-ch/logback', 'Homebrew/homebrew-science', 'GoogleCloudPlatform/DataflowJavaSDK', 'SoftInstigate/restheart', 'naver/pinpoint', 'KronicDeth/intellij-elixir', 'embulk/embulk', 'loomio/loomio', 'openstreetmap/openstreetmap-website', 'activescaffold/active_scaffold', 'tananaev/traccar', 'SonarSource/sonarqube', 'grpc/grpc-java', 'psi-probe/psi-probe', 'orientation/orientation', 'square/keywhiz', 'aws/aws-sdk-java', 'Shopify/shipit-engine', 'perfectsense/brightspot-cms', 'jamesagnew/hapi-fhir']

num_build=0

#failures_length=[]
project_age=[]
project_age=[60.99788811728395, 42.868221450617284, 56.12528202160494, 47.38550077160494, 60.89705787037037, 58.04270524691358, 47.97162538580247, 39.43006172839506, 16.51641049382716, 60.90738695987654, 58.845846064814815, 60.44828703703703, 60.784233410493826, 25.959506172839507, 60.65283410493827, 60.88418711419753, 19.451444444444444, 43.04281944444445, 60.23046875, 60.91941666666666, 60.945159336419756, 60.88944637345679, 60.910814043209875, 60.75280015432099, 60.883915895061726, 38.06781288580247, 47.86834645061728, 58.839470679012344, 58.33825810185185, 57.8269537037037, 52.96799652777778, 58.61927199074074, 60.82560069444445, 39.30659297839506, 60.700752314814814, 60.78509452160494, 60.659984953703706, 59.82352662037037, 60.06336844135802, 59.15326350308642, 58.4342550154321, 58.18469560185185, 60.237319444444445, 59.89075925925926, 60.254800540123455, 55.31189969135802, 60.021097222222224, 54.19930902777778, 57.831628086419755, 57.95704899691358, 60.006391975308645, 58.52207060185185, 59.44461111111111, 43.26081057098765, 59.48896219135803, 59.39457137345679, 59.20439313271605, 57.95658294753086, 58.65800347222222, 46.04024421296296, 46.013713348765435, 58.68047762345679, 57.627726080246916, 58.29785918209877, 52.95464390432099, 51.74549112654321, 57.37794367283951, 14.453299382716049, 57.1007700617284, 53.271368055555556, 55.32124421296297, 52.05723649691358, 43.529069444444445, 36.7667650462963, 49.225259645061726, 55.526749614197534, 55.006963734567904, 53.90801890432099, 54.56425270061728, 51.86058526234568, 53.30700810185185, 54.26936226851852, 53.59927893518518, 54.370530864197534, 52.85917168209877, 25.43996412037037, 54.36261844135802, 37.16625810185185, 53.49630902777778, 28.66893325617284, 53.42397453703704, 28.72929513888889, 52.68950385802469, 48.20410995370371, 53.015060185185185, 53.27285686728395, 51.30186535493827, 52.570462191358025, 33.83810918209876, 25.024305169753088, 51.88496797839506, 45.57232445987654, 52.44772800925926, 46.33488310185185, 34.77926851851852, 52.22533410493827, 26.196630401234568, 51.46207677469136, 49.489141589506175, 51.868130401234566, 51.39140663580247, 26.961281635802468, 48.6703962191358, 48.860492669753086, 48.44385300925926, 44.0894174382716, 44.08912847222222, 24.933184027777777, 51.03551041666667, 51.033578703703704, 50.799975308641976, 50.75948804012346, 40.67418055555556, 50.10126813271605, 48.93948186728395, 48.76311805555556, 34.21816936728395, 47.743108410493825, 33.77389197530864, 47.093836805555554, 46.99011612654321, 48.36900848765432, 34.424694058641975, 48.469902777777776, 18.663188657407407, 48.09868634259259, 47.51554359567901, 48.06388464506173, 48.15943711419753, 47.83862075617284, 42.562489969135804, 12.432195601851852, 47.66237345679012, 43.77555864197531, 47.46832060185185, 47.41583101851852, 47.178567901234565, 47.32070023148148, 47.07954591049383, 33.15620563271605, 43.660050154320984, 30.775845679012345, 46.25623919753087, 46.43838541666667, 23.170719907407406, 46.561822916666664, 46.42623070987654, 36.76309992283951, 42.868221450617284, 23.105463348765433, 32.6021824845679, 44.09510763888889, 44.74747723765432, 44.01591859567901, 42.333927854938274, 44.45114429012346, 44.39661959876543, 35.67860802469136, 39.34556365740741, 31.170439043209875, 39.08877276234568, 42.89688348765432, 43.423280478395064, 43.72543711419753, 43.722099922839504, 43.585711805555555, 36.7667650462963, 35.63576427469136, 42.82634066358025, 43.09385918209877, 42.23184645061728, 42.6890212191358, 40.08030709876543, 41.1078587962963, 42.792724151234566, 19.804082947530866, 40.75303780864198, 40.62701311728395, 28.943190586419753, 41.348618055555555, 34.81962962962963, 41.52046682098766, 38.76906134259259, 35.7932137345679, 41.32337808641975, 39.86753973765432, 39.651275462962964, 40.2630212191358, 34.39949074074074, 40.44909452160494, 41.057862654320985, 30.885082175925927, 37.56645100308642, 27.87531674382716, 40.24755362654321, 26.12271836419753, 31.698124614197532, 38.72930902777778, 39.79056057098765, 38.83317399691358, 40.00625077160494, 39.83346759259259, 39.83037847222222, 29.33731597222222, 34.86043904320988, 35.62693325617284, 30.103962577160495, 36.58764814814815, 26.53098302469136, 39.00409992283951, 38.772607638888886, 38.56100655864198, 32.03689390432099, 18.31864776234568, 37.96038348765432, 36.49455594135802, 37.578162422839505, 15.330040895061728, 25.03303549382716, 37.65068287037037, 37.70125347222222, 37.0254949845679, 36.98812422839506, 36.89062692901235, 31.061488425925926, 36.816104552469135, 36.07600154320988, 29.338535879629628, 36.195125771604935, 23.27287885802469, 35.869599922839505, 35.73228125, 34.563684027777775, 34.43489351851852, 35.59679899691358, 35.359732638888886, 35.23294328703704, 35.47253549382716, 29.785729166666666, 35.19286805555556, 22.532131944444444, 21.96384760802469, 34.60375038580247, 30.271081404320988, 21.87336651234568, 33.983266975308645, 34.77709104938272, 34.573242669753085, 34.33634375, 34.37039660493827, 21.291534722222224, 34.232231481481485, 25.317443287037037, 33.15620563271605, 31.197810956790125, 33.11556481481482, 14.701507716049383, 21.412851080246913, 31.35664737654321, 24.247436728395062, 31.81514236111111, 31.82590547839506, 14.67307214506173, 30.773743055555556, 31.317722222222223, 27.214613811728395, 31.381449074074073, 31.054349922839506, 30.886480709876544, 30.759721064814816, 24.48322299382716, 17.964171296296296, 30.572416280864196, 30.83145138888889, 30.775027006172838, 28.04486574074074, 29.727409722222223, 29.964091435185185, 17.37188850308642, 30.301457175925925, 30.332603395061728, 23.545707175925926, 30.337702932098765, 28.976699459876542, 29.067121913580248, 14.26640162037037, 29.096081404320987, 29.091498456790124, 29.095640817901234, 29.08987538580247, 28.657476080246912, 28.433782021604937, 15.036159722222223, 28.06875115740741, 27.93230825617284, 27.793526234567903, 14.601501543209876, 27.11203665123457, 27.54011265432099, 14.457883101851852, 26.95807561728395, 26.388434799382715, 13.530038194444444, 22.542483410493826, 23.9220887345679, 25.63091975308642, 23.364632330246913, 24.769520833333335, 24.10303125, 12.298489969135803, 24.656851466049382, 24.644858796296297, 24.35935609567901, 24.664117669753086, 24.437304398148147, 24.397274305555555, 24.274322145061728, 12.258020061728395, 21.938689814814815, 23.532486111111112, 23.15061111111111, 23.05472839506173, 21.449680941358025, 22.035605709876542, 22.394292824074075, 20.82385300925926, 22.009229938271606, 21.608474922839505, 21.708291666666668, 17.40260648148148, 20.252540895061728, 19.554871913580246, 18.755581790123458, 19.30111612654321, 18.98716975308642, 18.132243441358025, 18.663188657407407, 18.262356095679014, 18.361248070987653, 18.251556712962962, 17.762991898148147, 17.667185570987655, 17.434983410493828, 16.742409336419755, 17.298449074074075, 15.90389737654321, 15.381609953703704, 13.467878858024692, 14.577877314814815]

failure_ratio=[]
test_density=[]
#'''
X=np.array(project_age)
X=X.reshape(-1,1)
#plot(X)
n_clusters=3
y_pred0 = KMeans(n_clusters=n_clusters).fit_predict(X)
cluster=[]
detail=[]
result=[]
names=[]
for index in range(n_clusters):
   cluster.append([])
   detail.append([])
   result.append([])
   names.append([])
#cluster1=[[],[],[]]
for index in range(len(y_pred0)):
        for item in range(n_clusters):
            if y_pred0[index] == item:
                cluster[item].append(index)
                detail[item].append(project_age[index])
                names[item].append(project_names[index])
for item in detail:
    #print(max(item))
    #print(min(item))
    print(get_median(item))
print(names)
newnames=[]
newnames.append(names[2])
newnames.append(names[1])
newnames.append(names[0])
print(newnames)
#'''
for nameindex in range(len(project_names)):
    file_name = project_names[nameindex] + ".csv"
    file_name = file_name.split("/")[1]
    print(file_name)

    string = "/Users/jinxianhao/Documents/src/python/CI/Data_Base/all_dataset/" + file_name
    csv_file = csv.reader(open(string, 'r'))
    pre = []
    final = []
    for item in csv_file:
        pre.append(item)

    for i in range(len(pre[0])):
        temp = []
        for index in range(1, len(pre)):
            # print(index)
            # print(pre[index][i])
            temp.append(pre[index][i])
        final.append(temp)
    num_build=num_build+len(final[42])

    indices = []
    for index in range(len(final[42])):
        if final[42][index] == 'passed':
            indices.append(index)
        else:
            if final[42][index - 1] == 'passed':
                indices.append(index)

    build_result = []
    for item in indices:
        if final[42][item] == 'passed':
            build_result.append(1)
        else:
            build_result.append(0)

    timestamp = []
    for item in final[41]:
        tm = time.strptime(item, '%Y-%m-%d %H:%M:%S')
        times = int(time.mktime(tm))
        timestamp.append(times)
    test=[]
    for item in final[35]:
        test.append(float(item))
    age=(timestamp[len(timestamp)-1]-timestamp[0])/2592000
    failure_ratio.append(1-sum(build_result)/len(build_result))
    project_age.append(age)
    #'''
#print(project_age)
#'''

for index in range(len(cluster)):
    for item in cluster[index]:
        try:
            #result[index].append(failures_length[item])
            result[index].append(failure_ratio[item])
        except:
            print(item)

for item in result:
    print(get_median(item))
    print(sum(item)/len(item))

book = xlwt.Workbook(encoding='utf-8', style_compression=0)
sheet1 = book.add_sheet('test_line', cell_overwrite_ok=True)
sheet2 = book.add_sheet('test_case', cell_overwrite_ok=True)
sheet3 = book.add_sheet('assert_case', cell_overwrite_ok=True)
col=0

for index in range(len(result)):
    string='cluster '+ str(index)
    for item in result[index]:
        sheet1.write(col,0,string)
        sheet1.write(col,1,item)
        col=col+1
#book.save(r'cluster_fail_ratio_age.xls')

print('\n')
print('result')
print(get_median(result[0]))
print(get_median(result[1]))
print(get_median(result[2]))
print(stats.kruskal(result[0], result[1],result[2]))
print(stats.mannwhitneyu(result[0],result[1]))
print(stats.mannwhitneyu(result[0],result[2]))
print(stats.mannwhitneyu(result[2],result[1]))

project_age=[60.99788811728395, 42.868221450617284, 56.12528202160494, 47.38550077160494, 60.89705787037037, 58.04270524691358, 47.97162538580247, 39.43006172839506, 16.51641049382716, 60.90738695987654, 58.845846064814815, 60.44828703703703, 60.784233410493826, 25.959506172839507, 60.65283410493827, 60.88418711419753, 19.451444444444444, 43.04281944444445, 60.23046875, 60.91941666666666, 60.945159336419756, 60.88944637345679, 60.910814043209875, 60.75280015432099, 60.883915895061726, 38.06781288580247, 47.86834645061728, 58.839470679012344, 58.33825810185185, 57.8269537037037, 52.96799652777778, 58.61927199074074, 60.82560069444445, 39.30659297839506, 60.700752314814814, 60.78509452160494, 60.659984953703706, 59.82352662037037, 60.06336844135802, 59.15326350308642, 58.4342550154321, 58.18469560185185, 60.237319444444445, 59.89075925925926, 60.254800540123455, 55.31189969135802, 60.021097222222224, 54.19930902777778, 57.831628086419755, 57.95704899691358, 60.006391975308645, 58.52207060185185, 59.44461111111111, 43.26081057098765, 59.48896219135803, 59.39457137345679, 59.20439313271605, 57.95658294753086, 58.65800347222222, 46.04024421296296, 46.013713348765435, 58.68047762345679, 57.627726080246916, 58.29785918209877, 52.95464390432099, 51.74549112654321, 57.37794367283951, 14.453299382716049, 57.1007700617284, 53.271368055555556, 55.32124421296297, 52.05723649691358, 43.529069444444445, 36.7667650462963, 49.225259645061726, 55.526749614197534, 55.006963734567904, 53.90801890432099, 54.56425270061728, 51.86058526234568, 53.30700810185185, 54.26936226851852, 53.59927893518518, 54.370530864197534, 52.85917168209877, 25.43996412037037, 54.36261844135802, 37.16625810185185, 53.49630902777778, 28.66893325617284, 53.42397453703704, 28.72929513888889, 52.68950385802469, 48.20410995370371, 53.015060185185185, 53.27285686728395, 51.30186535493827, 52.570462191358025, 33.83810918209876, 25.024305169753088, 51.88496797839506, 45.57232445987654, 52.44772800925926, 46.33488310185185, 34.77926851851852, 52.22533410493827, 26.196630401234568, 51.46207677469136, 49.489141589506175, 51.868130401234566, 51.39140663580247, 26.961281635802468, 48.6703962191358, 48.860492669753086, 48.44385300925926, 44.0894174382716, 44.08912847222222, 24.933184027777777, 51.03551041666667, 51.033578703703704, 50.799975308641976, 50.75948804012346, 40.67418055555556, 50.10126813271605, 48.93948186728395, 48.76311805555556, 34.21816936728395, 47.743108410493825, 33.77389197530864, 47.093836805555554, 46.99011612654321, 48.36900848765432, 34.424694058641975, 48.469902777777776, 18.663188657407407, 48.09868634259259, 47.51554359567901, 48.06388464506173, 48.15943711419753, 47.83862075617284, 42.562489969135804, 12.432195601851852, 47.66237345679012, 43.77555864197531, 47.46832060185185, 47.41583101851852, 47.178567901234565, 47.32070023148148, 47.07954591049383, 33.15620563271605, 43.660050154320984, 30.775845679012345, 46.25623919753087, 46.43838541666667, 23.170719907407406, 46.561822916666664, 46.42623070987654, 36.76309992283951, 42.868221450617284, 23.105463348765433, 32.6021824845679, 44.09510763888889, 44.74747723765432, 44.01591859567901, 42.333927854938274, 44.45114429012346, 44.39661959876543, 35.67860802469136, 39.34556365740741, 31.170439043209875, 39.08877276234568, 42.89688348765432, 43.423280478395064, 43.72543711419753, 43.722099922839504, 43.585711805555555, 36.7667650462963, 35.63576427469136, 42.82634066358025, 43.09385918209877, 42.23184645061728, 42.6890212191358, 40.08030709876543, 41.1078587962963, 42.792724151234566, 19.804082947530866, 40.75303780864198, 40.62701311728395, 28.943190586419753, 41.348618055555555, 34.81962962962963, 41.52046682098766, 38.76906134259259, 35.7932137345679, 41.32337808641975, 39.86753973765432, 39.651275462962964, 40.2630212191358, 34.39949074074074, 40.44909452160494, 41.057862654320985, 30.885082175925927, 37.56645100308642, 27.87531674382716, 40.24755362654321, 26.12271836419753, 31.698124614197532, 38.72930902777778, 39.79056057098765, 38.83317399691358, 40.00625077160494, 39.83346759259259, 39.83037847222222, 29.33731597222222, 34.86043904320988, 35.62693325617284, 30.103962577160495, 36.58764814814815, 26.53098302469136, 39.00409992283951, 38.772607638888886, 38.56100655864198, 32.03689390432099, 18.31864776234568, 37.96038348765432, 36.49455594135802, 37.578162422839505, 15.330040895061728, 25.03303549382716, 37.65068287037037, 37.70125347222222, 37.0254949845679, 36.98812422839506, 36.89062692901235, 31.061488425925926, 36.816104552469135, 36.07600154320988, 29.338535879629628, 36.195125771604935, 23.27287885802469, 35.869599922839505, 35.73228125, 34.563684027777775, 34.43489351851852, 35.59679899691358, 35.359732638888886, 35.23294328703704, 35.47253549382716, 29.785729166666666, 35.19286805555556, 22.532131944444444, 21.96384760802469, 34.60375038580247, 30.271081404320988, 21.87336651234568, 33.983266975308645, 34.77709104938272, 34.573242669753085, 34.33634375, 34.37039660493827, 21.291534722222224, 34.232231481481485, 25.317443287037037, 33.15620563271605, 31.197810956790125, 33.11556481481482, 14.701507716049383, 21.412851080246913, 31.35664737654321, 24.247436728395062, 31.81514236111111, 31.82590547839506, 14.67307214506173, 30.773743055555556, 31.317722222222223, 27.214613811728395, 31.381449074074073, 31.054349922839506, 30.886480709876544, 30.759721064814816, 24.48322299382716, 17.964171296296296, 30.572416280864196, 30.83145138888889, 30.775027006172838, 28.04486574074074, 29.727409722222223, 29.964091435185185, 17.37188850308642, 30.301457175925925, 30.332603395061728, 23.545707175925926, 30.337702932098765, 28.976699459876542, 29.067121913580248, 14.26640162037037, 29.096081404320987, 29.091498456790124, 29.095640817901234, 29.08987538580247, 28.657476080246912, 28.433782021604937, 15.036159722222223, 28.06875115740741, 27.93230825617284, 27.793526234567903, 14.601501543209876, 27.11203665123457, 27.54011265432099, 14.457883101851852, 26.95807561728395, 26.388434799382715, 13.530038194444444, 22.542483410493826, 23.9220887345679, 25.63091975308642, 23.364632330246913, 24.769520833333335, 24.10303125, 12.298489969135803, 24.656851466049382, 24.644858796296297, 24.35935609567901, 24.664117669753086, 24.437304398148147, 24.397274305555555, 24.274322145061728, 12.258020061728395, 21.938689814814815, 23.532486111111112, 23.15061111111111, 23.05472839506173, 21.449680941358025, 22.035605709876542, 22.394292824074075, 20.82385300925926, 22.009229938271606, 21.608474922839505, 21.708291666666668, 17.40260648148148, 20.252540895061728, 19.554871913580246, 18.755581790123458, 19.30111612654321, 18.98716975308642, 18.132243441358025, 18.663188657407407, 18.262356095679014, 18.361248070987653, 18.251556712962962, 17.762991898148147, 17.667185570987655, 17.434983410493828, 16.742409336419755, 17.298449074074075, 15.90389737654321, 15.381609953703704, 13.467878858024692, 14.577877314814815]
print(stats.pearsonr(project_age,failure_ratio))