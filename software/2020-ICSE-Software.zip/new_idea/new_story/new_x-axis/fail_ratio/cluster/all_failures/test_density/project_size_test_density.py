import numpy as np
from sklearn.cluster import DBSCAN
from sklearn.cluster import AffinityPropagation
from sklearn.cluster import KMeans
import csv
import matplotlib.pyplot as plt
import xlwt
import time

'''
X=np.array([1,2,3,4,5,11,12,13,14,15])
X=X.reshape(-1,1)
y_pred = DBSCAN().fit_predict(X)
y_pred = AffinityPropagation().fit_predict(X)
print(y_pred)
'''

def get_median(data):
    data = sorted(data)
    size = len(data)
    if size % 2 == 0:  # 判断列表长度为偶数
        median = (data[size // 2] + data[size // 2 - 1]) / 2
        data[0] = median
    if size % 2 == 1:  # 判断列表长度为奇数
        median = data[(size - 1) // 2]
        data[0] = median
    return data[0]

def plot(X):
    Sum_of_squared_distances = []
    K = range(1, 15)
    for k in K:
        km = KMeans(n_clusters=k)
        km = km.fit(X)
        Sum_of_squared_distances.append(km.inertia_)

    plt.plot(K, Sum_of_squared_distances, 'bx-')
    plt.xlabel('k')
    plt.ylabel('Sum_of_squared_distances')
    plt.title('Elbow Method For Optimal k')
    plt.show()

project_names=['rails/rails', 'myronmarston/vcr', 'concerto/concerto', 'benhoskings/babushka', 'rubinius/rubinius', 'rubychan/coderay', 'codeforamerica/adopt-a-hydrant', 'radiant/radiant', 'saberma/shopqi', 'rspec/rspec-core', 'engineyard/engineyard', 'plataformatec/devise', 'rspec/rspec-rails', 'karmi/retire', 'sferik/rails_admin', 'tdiary/tdiary-core', 'dkubb/veritas', 'sstephenson/sprockets', 'thoughtbot/factory_girl', 'weppos/whois', 'errbit/errbit', 'padrino/padrino-framework', 'thoughtbot/paperclip', 'plataformatec/simple_form', 'huerlisi/bookyt', 'hotsh/rstat.us', 'mperham/dalli', 'innoq/iqvoc', 'cheezy/page-object', 'justinfrench/formtastic', 'nov/fb_graph', 'assaf/vanity', 'activerecord-hackery/ransack', 'jimweirich/rake', 'rspec/rspec-mocks', 'neo4jrb/neo4j', 'diaspora/diaspora', 'test-unit/test-unit', 'Shopify/liquid', 'activeadmin/activeadmin', 'ari/jobsworth', 'thoughtbot/shoulda-matchers', 'rubygems/rubygems', 'rdoc/rdoc', 'spree/spree', 'rubyzip/rubyzip', 'pry/pry', 'jruby/activerecord-jdbc-adapter', 'sass/sass', 'jruby/warbler', 'fatfreecrm/fat_free_crm', 'rspec/rspec-expectations', 'excon/excon', 'typus/typus', 'heroku/heroku', 'nahi/httpclient', 'podio/podio-rb', 'maxdemarzi/neography', 'locomotivecms/engine', 'gedankenstuecke/snpr', 'peter-murach/github', 'jnicklas/capybara', 'travis-ci/travis-core', 'presidentbeef/brakeman', 'mikel/mail', 'randym/axlsx', 'kmuto/review', 'danielweinmann/catarse', 'middleman/middleman', 'rubyworks/facets', 'railsbp/rails_best_practices', 'comfy/comfortable-mexican-sofa', 'mongoid/moped', 'wr0ngway/rubber', 'rslifka/elasticity', 'lsegal/yard', 'NoamB/sorcery', 'puppetlabs/puppet', 'mitchellh/vagrant', 'ai/r18n', 'celluloid/celluloid', 'jordansissel/fpm', 'neo4jrb/neo4j-core', 'orbeon/orbeon-forms', 'redis/redis-rb', 'pivotal/pivotal_workstation', 'jruby/jruby', 'louismullie/treat', 'puma/puma', 'pophealth/popHealth', 'twitter/twitter-cldr-rb', 'gistflow/gistflow', 'adamfisk/LittleProxy', 'awestruct/awestruct', 'jnunemaker/httparty', 'Graylog2/graylog2-server', 'neuland/jade4j', 'sensu/sensu', 'shawn42/gamebox', 'applicationsonline/librarian', 'haml/haml', 'sporkmonger/addressable', 'google/google-api-ruby-client', 'elm-city-craftworks/practicing-ruby-web', 'sunlightlabs/scout', 'floere/phony', 'data-axle/cassandra_object', 'typhoeus/typhoeus', 'shoes/shoes4', 'troessner/reek', 'recurly/recurly-client-ruby', 'CloudifySource/cloudify', 'puppetlabs/puppetlabs-firewall', 'typhoeus/ethon', 'sparklemotion/nokogiri', 'tinkerpop/blueprints', 'tinkerpop/rexster', 'thinkaurelius/titan', 'openSUSE/open-build-service', 'engineyard/ey-cloud-recipes', 'git/git-scm.com', 'honeybadger-io/honeybadger-ruby', 'azagniotov/stubby4j', 'sferik/twitter', 'calagator/calagator', 'openshift/rhc', 'codefirst/AsakusaSatellite', 'DatabaseCleaner/database_cleaner', 'burke/zeus', 'fog/fog', 'twilio/twilio-java', 'twitter/commons', 'Albacore/albacore', 'prawnpdf/prawn', 'enspiral/loomio', 'refinery/refinerycms', 'sevntu-checkstyle/sevntu.checkstyle', 'opal/opal', 'graphhopper/graphhopper', 'sparklemotion/mechanize', 'SomMeri/less4j', 'tent/tentd', 'searchbox-io/Jest', 'square/dagger', 'google/truth', 'square/okhttp', 'square/retrofit', 'maxcom/lorsource', 'jneen/rouge', 'jmkgreen/morphia', 'SpontaneousCMS/spontaneous', 'everzet/capifony', 'killbill/killbill', 'scobal/seyren', 'intuit/simple_deploy', 'projectblacklight/blacklight', 'rapid7/metasploit-framework', 'amahi/platform', 'vcr/vcr', 'Findwise/Hydra', 'structr/structr', 'sachin-handiekar/jInstagram', 'nutzam/nutz', 'slim-template/slim', 'puppetlabs/puppetlabs-stdlib', 'puppetlabs/facter', 'phoet/on_ruby', 'dreamhead/moco', 'travis-ci/travis.rb', 'cloudfoundry/cloud_controller_ng', 'square/assertj-android', 'jmxtrans/jmxtrans', 'twitter/secureheaders', 'nanoc/nanoc', 'expertiza/expertiza', 'asciidoctor/asciidoctor', 'rubber/rubber', 'openMF/mifosx', 'mybatis/mybatis-3', 'test-kitchen/test-kitchen', 'owlcs/owlapi', 'engineyard/engineyard-serverside', 'selendroid/selendroid', 'ruboto/ruboto', 'openfoodfoundation/openfoodnetwork', 'stephanenicolas/robospice', 'joscha/play-authenticate', 'undera/jmeter-plugins', 'cantino/huginn', 'resque/resque', 'albertlatacz/java-repl', 'l0rdn1kk0n/wicket-bootstrap', 'dynjs/dynjs', 'abarisain/dmix', 'dropwizard/dropwizard', 'dropwizard/metrics', 'jberkel/sms-backup-plus', 'rubymotion/sugarcube', 'naver/yobi', 'Shopify/active_shipping', 'projecthydra/sufia', 'rubymotion/BubbleWrap', 'pivotal-sprout/sprout-osx-apps', 'chef/omnibus', 'JodaOrg/joda-time', 'EmmanuelOga/ffaker', 'kostya/eye', 'laurentpetit/ccw', 'puniverse/quasar', 'simpligility/android-maven-plugin', 'jsonld-java/jsonld-java', 'travis-ci/travis-cookbooks', 'FenixEdu/fenixedu-academic', 'threerings/playn', 'restlet/restlet-framework-java', 'jedi4ever/veewee', 'sensu/sensu-community-plugins', 'OpenRefine/OpenRefine', 'chef/chef', 'fluent/fluentd', 'perwendel/spark', 'joelittlejohn/jsonschema2pojo', 'jOOQ/jOOQ', 'springside/springside4', 'github/hub', 'johncarl81/parceler', 'discourse/onebox', 'julianhyde/optiq', 'ruby-ldap/ruby-net-ldap', 'DSpace/DSpace', 'jeremyevans/sequel', 'bikeindex/bike_index', 'doanduyhai/Achilles', 'rackerlabs/blueflood', 'rodjek/librarian-puppet', 'p6spy/p6spy', 'square/wire', 'Nodeclipse/nodeclipse-1', 'rebelidealist/stripe-ruby-mock', 'checkstyle/checkstyle', 'elastic/logstash', 'airlift/airlift', 'lenskit/lenskit', 'MiniProfiler/rack-mini-profiler', 'geoserver/geoserver', 'ocpsoft/rewrite', 'Unidata/thredds', 'torakiki/pdfsam', 'loopj/android-async-http', 'feedbin/feedbin', 'recruit-tech/redpen', 'brettwooldridge/HikariCP', 'puppetlabs/marionette-collective', 'iipc/openwayback', 'caelum/vraptor4', 'dianping/cat', 'jphp-compiler/jphp', 'mockito/mockito', 'oblac/jodd', 'facebook/buck', 'facebook/presto', 'jpos/jPOS', 'hamstergem/hamster', 'mongodb/morphia', 'realestate-com-au/pact', 'inaturalist/inaturalist', 'jtwig/jtwig', 'go-lang-plugin-org/go-lang-idea-plugin', 'square/picasso', 'voltrb/volt', 'zxing/zxing', 'openaustralia/morph', 'GlowstoneMC/Glowstone', 'owncloud/android', 'JakeWharton/u2020', 'rpush/rpush', 'OneBusAway/onebusaway-android', 'rabbit-shocker/rabbit', 'azkaban/azkaban', 'relayrides/pushy', 'deeplearning4j/deeplearning4j', 'github/developer.github.com', 'xetorthio/jedis', 'FasterXML/jackson-core', 'FasterXML/jackson-databind', 'protostuff/protostuff', 'atmos/heaven', 'MrTJP/ProjectRed', 'lemire/RoaringBitmap', 'apache/drill', 'Kapeli/cheatsheets', 'gradle/gradle', 'OpenGrok/OpenGrok', 'spring-io/sagan', 'mendhak/gpslogger', 'thoughtbot/hound', 'teamed/qulice', 'jcabi/jcabi-aspects', 'jcabi/jcabi-github', 'jcabi/jcabi-http', 'yegor256/rultor', 'querydsl/querydsl', 'codevise/pageflow', 'grails/grails-core', 'weld/core', 'thatJavaNerd/JRAW', 'bndtools/bnd', 'igniterealtime/Openfire', 'zendesk/samson', 'bndtools/bndtools', 'xtreemfs/xtreemfs', 'puniverse/capsule', 'broadinstitute/picard', 'github/github-services', 'gavinlaking/vedeu', 'haiwen/seadroid', 'AChep/AcDisplay', 'GoClipse/goclipse', 'hsz/idea-gitignore', 'jsprit/jsprit', 'dblock/waffle', 'numenta/htm.java', 'rightscale/praxis', 'google/error-prone', 'datastax/ruby-driver', 'iluwatar/java-design-patterns', 'Netflix/Hystrix', 'oyachai/HearthSim', 'jayway/JsonPath', 'exteso/alf.io', 'spring-cloud/spring-cloud-config', 'validator/validator', 'HubSpot/jinjava', 'connectbot/connectbot', 'google/physical-web', 'myui/hivemall', 'MarkUsProject/Markus', 'jMonkeyEngine/jmonkeyengine', 'davidmoten/rxjava-jdbc', 'qos-ch/logback', 'Homebrew/homebrew-science', 'GoogleCloudPlatform/DataflowJavaSDK', 'SoftInstigate/restheart', 'naver/pinpoint', 'KronicDeth/intellij-elixir', 'embulk/embulk', 'loomio/loomio', 'openstreetmap/openstreetmap-website', 'activescaffold/active_scaffold', 'tananaev/traccar', 'SonarSource/sonarqube', 'grpc/grpc-java', 'psi-probe/psi-probe', 'orientation/orientation', 'square/keywhiz', 'aws/aws-sdk-java', 'Shopify/shipit-engine', 'perfectsense/brightspot-cms', 'jamesagnew/hapi-fhir']



#failures_length=[]
project_size=[]
project_size=[53819.0, 3033.0, 5167.0, 5289.0, 415786.0, 9680.0, 13826.0, 10610.0, 9928.5, 5052.5, 4460.0, 3230.0, 1872.0, 2527.0, 4626.0, 18435.0, 3036.0, 2395.0, 1587.0, 11103.0, 3225.5, 7700.0, 3159.0, 1751.0, 4789.0, 2105.0, 1331.5, 4506.0, 5795.0, 2723.5, 4044.0, 2363.0, 2619.0, 3596.0, 3154.0, 3600.0, 16739.0, 6524.0, 2328.0, 6354.0, 15153.0, 3503.5, 17088.0, 16547.5, 12032.0, 2859.0, 6565.0, 7132.0, 11448.0, 7685.0, 8486.0, 3174.0, 1864.0, 3483.0, 6048.0, 4596.5, 4365.5, 2455.0, 9812.5, 4714.0, 4198.0, 6329.0, 10569.0, 11928.0, 16856.0, 5182.0, 9429.0, 5184.0, 7116.0, 21429.0, 3182.0, 5484.0, 2405.0, 8453.0, 3032.0, 14359.0, 2436.0, 84443.0, 26106.0, 2552.0, 2694.0, 2115.0, 2919.0, 56972.0, 2970.0, 2373.0, 148743.0, 5421.0, 3348.0, 1776.0, 4556.0, 2556.0, 3390.0, 3921.0, 1563.0, 60167.0, 5377.0, 2560.0, 7774.0, 3379.5, 2744.0, 2367.5, 3084.0, 2288.0, 5189.0, 11108.0, 1445.0, 1098.0, 11721.0, 3067.0, 2093.0, 46692.0, 1790.0, 1830.0, 12037.0, 16161.0, 11257.5, 18190.0, 29143.0, 2954.0, 1838.0, 2997.0, 3568.0, 2529.5, 4073.0, 8892.0, 2892.0, 1783.0, 696.0, 125772.0, 8892.0, 26549.0, 3011.0, 8476.0, 19970.5, 6976.0, 6748.0, 19234.0, 27416.0, 4483.0, 19930.0, 4450.0, 4468.0, 3695.0, 2536.0, 15686.0, 3246.0, 23560.5, 10439.0, 12399.0, 16177.0, 1554.0, 63403.0, 3732.0, 2286.0, 6279.0, 598803.5, 5133.0, 3033.0, 13181.0, 59020.0, 3329.0, 48791.0, 1552.0, 3095.0, 5761.0, 2262.0, 5998.0, 3426.0, 13728.0, 18617.0, 6268.0, 1558.0, 6776.5, 27297.0, 8895.0, 8453.0, 51859.0, 18886.0, 4840.0, 121745.0, 7162.5, 26310.0, 3323.0, 25745.0, 7095.0, 5856.0, 28265.0, 7629.0, 2024.0, 2993.0, 13655.0, 25041.0, 22162.0, 12060.5, 7605.0, 6632.0, 6956.0, 7798.0, 4984.0, 6618.0, 3213.0, 3314.0, 4682.5, 30169.0, 3672.0, 4242.0, 10577.0, 35792.5, 15339.0, 6482.0, 8597.0, 320895.0, 32317.0, 122503.0, 14989.0, 15015.0, 44909.0, 49633.5, 9737.0, 4193.5, 3826.0, 98041.0, 8611.0, 699.0, 4577.0, 2068.0, 95265.0, 2464.0, 210877.0, 31415.0, 9899.0, 17358.0, 16185.0, 1197.0, 4120.0, 6434.0, 92286.5, 2408.0, 28991.0, 11456.0, 24578.0, 27541.0, 1749.0, 303998.0, 29431.0, 429028.0, 9755.0, 4934.0, 7444.0, 4729.0, 2296.0, 12567.0, 34716.0, 11214.0, 65988.0, 59233.0, 33268.0, 82611.5, 197810.5, 149663.0, 43503.0, 15402.0, 12399.0, 5825.0, 50757.0, 7118.0, 38405.0, 4615.0, 6658.0, 34688.0, 4561.0, 21968.0, 27970.0, 5857.0, 3950.0, 23655.0, 27697.0, 26612.5, 1402.0, 41251.0, 2140.0, 12640.0, 18237.0, 50343.0, 46324.0, 2565.0, 9634.0, 6695.5, 187386.0, 28421.0, 167848.0, 31402.0, 11458.0, 7802.0, 2475.0, 3765.0, 2370.0, 15359.5, 3178.0, 5530.0, 48110.0, 5153.0, 62271.0, 55502.0, 6403.0, 71235.0, 197546.0, 9471.0, 40734.0, 157570.0, 4825.5, 25958.0, 8628.0, 18305.0, 21749.0, 21248.0, 37444.0, 4427.0, 17544.0, 5786.0, 14740.0, 4157.0, 20796.0, 11046.0, 8725.0, 13000.0, 25357.0, 4604.5, 7942.0, 3532.0, 33077.0, 8998.0, 15279.0, 2059.5, 21994.0, 20245.0, 207832.0, 3281.0, 29163.0, 21412.0, 56485.5, 11518.5, 101107.0, 32303.0, 10462.5, 19970.5, 12181.0, 9288.0, 18196.0, 155481.0, 35640.0, 13811.0, 1447.0, 8163.0, 1033909.0, 3724.0, 35716.0, 533998.0]


test_density=[]
#'''
X=np.array(project_size)
X=X.reshape(-1,1)
plot(X)
n_clusters=3
y_pred0 = KMeans(n_clusters=n_clusters).fit_predict(X)
cluster=[]
detail=[]
result=[]
for index in range(n_clusters):
   cluster.append([])
   detail.append([])
   result.append([])
#cluster1=[[],[],[]]
for index in range(len(y_pred0)):
        for item in range(n_clusters):
            if y_pred0[index] == item:
                cluster[item].append(index)
                detail[item].append(project_size[index])
for item in detail:
    print(get_median(item))
#'''
for nameindex in range(len(project_names)):
    file_name = project_names[nameindex] + ".csv"
    file_name = file_name.split("/")[1]
    print(file_name)

    string = "/Users/jinxianhao/Documents/src/python/CI/Data_Base/all_dataset/" + file_name
    csv_file = csv.reader(open(string, 'r'))
    pre = []
    final = []
    for item in csv_file:
        pre.append(item)

    for i in range(len(pre[0])):
        temp = []
        for index in range(1, len(pre)):
            # print(index)
            # print(pre[index][i])
            temp.append(pre[index][i])
        final.append(temp)

    build_result = []
    for item in final[42]:
        if item == 'passed':
            build_result.append(1)
        else:
            build_result.append(0)

    timestamp = []
    for item in final[41]:
        tm = time.strptime(item, '%Y-%m-%d %H:%M:%S')
        times = int(time.mktime(tm))
        timestamp.append(times)
    test=[]
    for item in final[35]:
        test.append(float(item))
    age=(timestamp[len(timestamp)-1]-timestamp[0])/2592000
    test_density.append(get_median(test))
    #failure_ratio.append(1-sum(build_result)/len(build_result))
    project_size.append(age)
    #'''
#print(project_age)
#'''

for index in range(len(cluster)):
    for item in cluster[index]:
        try:
            #result[index].append(failures_length[item])
            result[index].append(test_density[item])
        except:
            print(item)

for item in result:
    print(get_median(item))
    print(sum(item)/len(item))

book = xlwt.Workbook(encoding='utf-8', style_compression=0)
sheet1 = book.add_sheet('test_line', cell_overwrite_ok=True)
sheet2 = book.add_sheet('test_case', cell_overwrite_ok=True)
sheet3 = book.add_sheet('assert_case', cell_overwrite_ok=True)
col=0

for index in range(len(result)):
    string='cluster '+ str(index)
    for item in result[index]:
        sheet1.write(col,0,string)
        sheet1.write(col,1,item)
        col=col+1
book.save(r'cluster_test_density_project_size.xls')
#'''