import os
import json

tmpres = os.popen('curl -H "Accept: application/vnd.github.cloak-preview" \
https://api.github.com/search/commits?q=a0e030167e77fbff1ac8323df477a338282b8f9a').read()
#print(tmpres)
#print(tmpres[0])
tmpres=json.loads(tmpres)
print(tmpres['items'][0]['author']['id'])