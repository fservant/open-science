import math

print(math.pi)
print(math.sqrt(4)*math.exp(0))
a=[1,2,3]
print(a[0:1])