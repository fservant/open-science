import csv
from scipy import stats
import numpy as np
import xlwt
from decimal import *
import time


project_names=['rails/rails', 'myronmarston/vcr', 'concerto/concerto', 'benhoskings/babushka', 'rubinius/rubinius', 'rubychan/coderay', 'codeforamerica/adopt-a-hydrant', 'radiant/radiant', 'saberma/shopqi', 'rspec/rspec-core', 'engineyard/engineyard', 'plataformatec/devise', 'rspec/rspec-rails', 'karmi/retire', 'sferik/rails_admin', 'tdiary/tdiary-core', 'dkubb/veritas', 'sstephenson/sprockets', 'thoughtbot/factory_girl', 'weppos/whois', 'errbit/errbit', 'padrino/padrino-framework', 'thoughtbot/paperclip', 'plataformatec/simple_form', 'huerlisi/bookyt', 'hotsh/rstat.us', 'mperham/dalli', 'innoq/iqvoc', 'cheezy/page-object', 'justinfrench/formtastic', 'nov/fb_graph', 'assaf/vanity', 'activerecord-hackery/ransack', 'jimweirich/rake', 'rspec/rspec-mocks', 'neo4jrb/neo4j', 'diaspora/diaspora', 'test-unit/test-unit', 'Shopify/liquid', 'activeadmin/activeadmin', 'ari/jobsworth', 'thoughtbot/shoulda-matchers', 'rubygems/rubygems', 'rdoc/rdoc', 'spree/spree', 'rubyzip/rubyzip', 'pry/pry', 'jruby/activerecord-jdbc-adapter', 'sass/sass', 'jruby/warbler', 'fatfreecrm/fat_free_crm', 'rspec/rspec-expectations', 'excon/excon', 'typus/typus', 'heroku/heroku', 'nahi/httpclient', 'podio/podio-rb', 'maxdemarzi/neography', 'locomotivecms/engine', 'gedankenstuecke/snpr', 'peter-murach/github', 'jnicklas/capybara', 'travis-ci/travis-core', 'presidentbeef/brakeman', 'mikel/mail', 'randym/axlsx', 'kmuto/review', 'danielweinmann/catarse', 'middleman/middleman', 'rubyworks/facets', 'railsbp/rails_best_practices', 'comfy/comfortable-mexican-sofa', 'mongoid/moped', 'wr0ngway/rubber', 'rslifka/elasticity', 'lsegal/yard', 'NoamB/sorcery', 'puppetlabs/puppet', 'mitchellh/vagrant', 'ai/r18n', 'celluloid/celluloid', 'jordansissel/fpm', 'neo4jrb/neo4j-core', 'orbeon/orbeon-forms', 'redis/redis-rb', 'pivotal/pivotal_workstation', 'jruby/jruby', 'louismullie/treat', 'puma/puma', 'pophealth/popHealth', 'twitter/twitter-cldr-rb', 'gistflow/gistflow', 'adamfisk/LittleProxy', 'awestruct/awestruct', 'jnunemaker/httparty', 'Graylog2/graylog2-server', 'neuland/jade4j', 'sensu/sensu', 'shawn42/gamebox', 'applicationsonline/librarian', 'haml/haml', 'sporkmonger/addressable', 'google/google-api-ruby-client', 'elm-city-craftworks/practicing-ruby-web', 'sunlightlabs/scout', 'floere/phony', 'data-axle/cassandra_object', 'typhoeus/typhoeus', 'shoes/shoes4', 'troessner/reek', 'recurly/recurly-client-ruby', 'CloudifySource/cloudify', 'puppetlabs/puppetlabs-firewall', 'typhoeus/ethon', 'sparklemotion/nokogiri', 'tinkerpop/blueprints', 'tinkerpop/rexster', 'thinkaurelius/titan', 'openSUSE/open-build-service', 'engineyard/ey-cloud-recipes', 'git/git-scm.com', 'honeybadger-io/honeybadger-ruby', 'azagniotov/stubby4j', 'sferik/twitter', 'calagator/calagator', 'openshift/rhc', 'codefirst/AsakusaSatellite', 'DatabaseCleaner/database_cleaner', 'burke/zeus', 'fog/fog', 'twilio/twilio-java', 'twitter/commons', 'Albacore/albacore', 'prawnpdf/prawn', 'enspiral/loomio', 'refinery/refinerycms', 'sevntu-checkstyle/sevntu.checkstyle', 'opal/opal', 'graphhopper/graphhopper', 'sparklemotion/mechanize', 'SomMeri/less4j', 'tent/tentd', 'searchbox-io/Jest', 'square/dagger', 'google/truth', 'square/okhttp', 'square/retrofit', 'maxcom/lorsource', 'jneen/rouge', 'jmkgreen/morphia', 'SpontaneousCMS/spontaneous', 'everzet/capifony', 'killbill/killbill', 'scobal/seyren', 'intuit/simple_deploy', 'projectblacklight/blacklight', 'rapid7/metasploit-framework', 'amahi/platform', 'vcr/vcr', 'Findwise/Hydra', 'structr/structr', 'sachin-handiekar/jInstagram', 'nutzam/nutz', 'slim-template/slim', 'puppetlabs/puppetlabs-stdlib', 'puppetlabs/facter', 'phoet/on_ruby', 'dreamhead/moco', 'travis-ci/travis.rb', 'cloudfoundry/cloud_controller_ng', 'square/assertj-android', 'jmxtrans/jmxtrans', 'twitter/secureheaders', 'nanoc/nanoc', 'expertiza/expertiza', 'asciidoctor/asciidoctor', 'rubber/rubber', 'openMF/mifosx', 'mybatis/mybatis-3', 'test-kitchen/test-kitchen', 'owlcs/owlapi', 'engineyard/engineyard-serverside', 'selendroid/selendroid', 'ruboto/ruboto', 'openfoodfoundation/openfoodnetwork', 'stephanenicolas/robospice', 'joscha/play-authenticate', 'undera/jmeter-plugins', 'cantino/huginn', 'resque/resque', 'albertlatacz/java-repl', 'l0rdn1kk0n/wicket-bootstrap', 'dynjs/dynjs', 'abarisain/dmix', 'dropwizard/dropwizard', 'dropwizard/metrics', 'jberkel/sms-backup-plus', 'rubymotion/sugarcube', 'naver/yobi', 'Shopify/active_shipping', 'projecthydra/sufia', 'rubymotion/BubbleWrap', 'pivotal-sprout/sprout-osx-apps', 'chef/omnibus', 'JodaOrg/joda-time', 'EmmanuelOga/ffaker', 'kostya/eye', 'laurentpetit/ccw', 'puniverse/quasar', 'simpligility/android-maven-plugin', 'jsonld-java/jsonld-java', 'travis-ci/travis-cookbooks', 'FenixEdu/fenixedu-academic', 'threerings/playn', 'restlet/restlet-framework-java', 'jedi4ever/veewee', 'sensu/sensu-community-plugins', 'OpenRefine/OpenRefine', 'chef/chef', 'fluent/fluentd', 'perwendel/spark', 'joelittlejohn/jsonschema2pojo', 'jOOQ/jOOQ', 'springside/springside4', 'github/hub', 'johncarl81/parceler', 'discourse/onebox', 'julianhyde/optiq', 'ruby-ldap/ruby-net-ldap', 'DSpace/DSpace', 'jeremyevans/sequel', 'bikeindex/bike_index', 'doanduyhai/Achilles', 'rackerlabs/blueflood', 'rodjek/librarian-puppet', 'p6spy/p6spy', 'square/wire', 'Nodeclipse/nodeclipse-1', 'rebelidealist/stripe-ruby-mock', 'checkstyle/checkstyle', 'elastic/logstash', 'airlift/airlift', 'lenskit/lenskit', 'MiniProfiler/rack-mini-profiler', 'geoserver/geoserver', 'ocpsoft/rewrite', 'Unidata/thredds', 'torakiki/pdfsam', 'loopj/android-async-http', 'feedbin/feedbin', 'recruit-tech/redpen', 'brettwooldridge/HikariCP', 'puppetlabs/marionette-collective', 'iipc/openwayback', 'caelum/vraptor4', 'dianping/cat', 'jphp-compiler/jphp', 'mockito/mockito', 'oblac/jodd', 'facebook/buck', 'facebook/presto', 'jpos/jPOS', 'hamstergem/hamster', 'mongodb/morphia', 'realestate-com-au/pact', 'inaturalist/inaturalist', 'jtwig/jtwig', 'go-lang-plugin-org/go-lang-idea-plugin', 'square/picasso', 'voltrb/volt', 'zxing/zxing', 'openaustralia/morph', 'GlowstoneMC/Glowstone', 'owncloud/android', 'JakeWharton/u2020', 'rpush/rpush', 'OneBusAway/onebusaway-android', 'rabbit-shocker/rabbit', 'azkaban/azkaban', 'relayrides/pushy', 'deeplearning4j/deeplearning4j', 'github/developer.github.com', 'xetorthio/jedis', 'FasterXML/jackson-core', 'FasterXML/jackson-databind', 'protostuff/protostuff', 'atmos/heaven', 'MrTJP/ProjectRed', 'lemire/RoaringBitmap', 'apache/drill', 'Kapeli/cheatsheets', 'gradle/gradle', 'OpenGrok/OpenGrok', 'spring-io/sagan', 'mendhak/gpslogger', 'thoughtbot/hound', 'teamed/qulice', 'jcabi/jcabi-aspects', 'jcabi/jcabi-github', 'jcabi/jcabi-http', 'yegor256/rultor', 'querydsl/querydsl', 'codevise/pageflow', 'grails/grails-core', 'weld/core', 'thatJavaNerd/JRAW', 'bndtools/bnd', 'igniterealtime/Openfire', 'zendesk/samson', 'bndtools/bndtools', 'xtreemfs/xtreemfs', 'puniverse/capsule', 'broadinstitute/picard', 'github/github-services', 'gavinlaking/vedeu', 'haiwen/seadroid', 'AChep/AcDisplay', 'GoClipse/goclipse', 'hsz/idea-gitignore', 'jsprit/jsprit', 'dblock/waffle', 'numenta/htm.java', 'rightscale/praxis', 'google/error-prone', 'datastax/ruby-driver', 'iluwatar/java-design-patterns', 'Netflix/Hystrix', 'oyachai/HearthSim', 'jayway/JsonPath', 'exteso/alf.io', 'spring-cloud/spring-cloud-config', 'validator/validator', 'HubSpot/jinjava', 'connectbot/connectbot', 'google/physical-web', 'myui/hivemall', 'MarkUsProject/Markus', 'jMonkeyEngine/jmonkeyengine', 'davidmoten/rxjava-jdbc', 'qos-ch/logback', 'Homebrew/homebrew-science', 'GoogleCloudPlatform/DataflowJavaSDK', 'SoftInstigate/restheart', 'naver/pinpoint', 'KronicDeth/intellij-elixir', 'embulk/embulk', 'loomio/loomio', 'openstreetmap/openstreetmap-website', 'activescaffold/active_scaffold', 'tananaev/traccar', 'SonarSource/sonarqube', 'grpc/grpc-java', 'psi-probe/psi-probe', 'orientation/orientation', 'square/keywhiz', 'aws/aws-sdk-java', 'Shopify/shipit-engine', 'perfectsense/brightspot-cms', 'jamesagnew/hapi-fhir']
#print(len(project_names))
#project_names=['concerto/concerto']

p_values=[]
coefficients=[]

for nameindex in range(len(project_names)):

    build_result = []
    num_commit = []
    src_churn = []
    test_churn = []
    file_churn = []
    last_build_status = []
    project_performance_short = []
    project_performance_long = []
    fail_commit = []
    pass_commit = []
    frequency=[]

    file_name = project_names[nameindex] + ".csv"
    file_name = file_name.split("/")[1]
    print(file_name)

    string = "/Users/jinxianhao/Documents/src/python/CI/Data_Base/all_dataset/" + file_name
    csv_file = csv.reader(open(string, 'r'))
    pre = []
    final = []
    for item in csv_file:
        pre.append(item)

    for i in range(len(pre[0])):
        temp = []
        for index in range(1, len(pre)):
            # print(index)
            # print(pre[index][i])
            temp.append(pre[index][i])
        final.append(temp)
    print(len(final[42]))

    timestamp = []
    for item in final[41]:
        tm = time.strptime(item, '%Y-%m-%d %H:%M:%S')
        times = int(time.mktime(tm))
        timestamp.append(times)

    result=[]
    for item in final[42]:
        if item =='passed':
            result.append(1)
        else:
            result.append(0)

    indices = []
    for index in range(1, int(len(final[42]) / 2)):
        if final[42][index] == 'passed':
            if final[42][index - 1] == 'passed':
                indices.append(index)
        else:
            if final[42][index - 1] == 'passed':
                indices.append(index)

    for item in indices:
        long=sum(result[:item])/(len(result[:item]))
        long=Decimal(long).quantize(Decimal('0.00'))
        project_performance_long.append(float(long))
        if item>5:
            project_performance_short.append(sum(result[item - 5:item]) / (5))

        else:
            project_performance_short.append(sum(result[:item]) / (len(result[:item])))
        num_commit.append(float(final[16][item]))
        src_churn.append(float(final[23][item]))
        file_churn.append(float(final[30][item]))
        test_churn.append(float(final[35][item]))
        frequency.append(int(abs(timestamp[item]-timestamp[item-1])/3600))
        if final[42][item] == 'passed':
            build_result.append(1)
        else:
            build_result.append(0)
        if final[42][item-1] == 'passed':
            last_build_status.append(1)
        else:
            last_build_status.append(0)

    #src_churn_copy=src_churn
    feature=frequency
    print(feature)
    feature_list = sorted({}.fromkeys(feature).keys())
    print(feature_list)
    build_in_group = []
    for item in feature_list:
        build_in_group.append([])
    #print(src_churn)
    for index in range(len(build_result)):
        for index1 in range(len(feature_list)):
            #print(src_churn[index])
            if feature[index]==feature_list[index1]:
                build_in_group[index1].append(build_result[index])

    #print(build_in_group)
    fail_ratio=[]
    feature_list_select=[]
    for index in range(len(build_in_group)):
        item = build_in_group[index]
        if len(item)!=0:
            fail_ratio.append(1-sum(item)/len(item))
            feature_list_select.append(feature_list[index])
    print(fail_ratio)
    c,p = (stats.pointbiserialr(feature_list_select, fail_ratio))
    print((stats.pointbiserialr(feature_list_select, fail_ratio)))
    p_values.append(p)
    coefficients.append(c)
valid_correlation=[]
for index in range(len(p_values)):
    item = p_values[index]
    if item <0.05:
        valid_correlation.append(coefficients[index])
print(len(valid_correlation)/len(p_values))
ratio=len(valid_correlation)/len(p_values)
ratio=Decimal(ratio*100).quantize(Decimal('0.00'))
print(valid_correlation)

book = xlwt.Workbook(encoding='utf-8', style_compression=0)
sheet = book.add_sheet('src_churn', cell_overwrite_ok=True)
pos=0
for index in range(len(valid_correlation)):
    string = 'TF ' + str(ratio) + '%'
    sheet.write(index, 0, string)
    sheet.write(index,1,valid_correlation[index])
#book.save(r'time_frequency.xls')
