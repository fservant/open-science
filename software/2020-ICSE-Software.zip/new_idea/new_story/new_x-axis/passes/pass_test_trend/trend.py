import csv
import numpy as np
import xlwt

book = xlwt.Workbook(encoding='utf-8', style_compression=0)
sheet1 = book.add_sheet('test_line', cell_overwrite_ok=True)
sheet2 = book.add_sheet('test_case', cell_overwrite_ok=True)
sheet3 = book.add_sheet('assert_case', cell_overwrite_ok=True)
col=0

selected_projects=[]
project_names=['rails/rails', 'myronmarston/vcr', 'concerto/concerto', 'benhoskings/babushka', 'rubinius/rubinius', 'rubychan/coderay', 'codeforamerica/adopt-a-hydrant', 'radiant/radiant', 'saberma/shopqi', 'rspec/rspec-core', 'engineyard/engineyard', 'plataformatec/devise', 'rspec/rspec-rails', 'karmi/retire', 'sferik/rails_admin', 'tdiary/tdiary-core', 'dkubb/veritas', 'sstephenson/sprockets', 'thoughtbot/factory_girl', 'weppos/whois', 'errbit/errbit', 'padrino/padrino-framework', 'thoughtbot/paperclip', 'plataformatec/simple_form', 'huerlisi/bookyt', 'hotsh/rstat.us', 'mperham/dalli', 'innoq/iqvoc', 'cheezy/page-object', 'justinfrench/formtastic', 'nov/fb_graph', 'assaf/vanity', 'activerecord-hackery/ransack', 'jimweirich/rake', 'rspec/rspec-mocks', 'neo4jrb/neo4j', 'diaspora/diaspora', 'test-unit/test-unit', 'Shopify/liquid', 'activeadmin/activeadmin', 'ari/jobsworth', 'thoughtbot/shoulda-matchers', 'rubygems/rubygems', 'rdoc/rdoc', 'spree/spree', 'rubyzip/rubyzip', 'pry/pry', 'jruby/activerecord-jdbc-adapter', 'sass/sass', 'jruby/warbler', 'fatfreecrm/fat_free_crm', 'rspec/rspec-expectations', 'excon/excon', 'typus/typus', 'heroku/heroku', 'nahi/httpclient', 'podio/podio-rb', 'maxdemarzi/neography', 'locomotivecms/engine', 'gedankenstuecke/snpr', 'peter-murach/github', 'jnicklas/capybara', 'travis-ci/travis-core', 'presidentbeef/brakeman', 'mikel/mail', 'randym/axlsx', 'kmuto/review', 'danielweinmann/catarse', 'middleman/middleman', 'rubyworks/facets', 'railsbp/rails_best_practices', 'comfy/comfortable-mexican-sofa', 'mongoid/moped', 'wr0ngway/rubber', 'rslifka/elasticity', 'lsegal/yard', 'NoamB/sorcery', 'puppetlabs/puppet', 'mitchellh/vagrant', 'ai/r18n', 'celluloid/celluloid', 'jordansissel/fpm', 'neo4jrb/neo4j-core', 'orbeon/orbeon-forms', 'redis/redis-rb', 'pivotal/pivotal_workstation', 'jruby/jruby', 'louismullie/treat', 'puma/puma', 'pophealth/popHealth', 'twitter/twitter-cldr-rb', 'gistflow/gistflow', 'adamfisk/LittleProxy', 'awestruct/awestruct', 'jnunemaker/httparty', 'Graylog2/graylog2-server', 'neuland/jade4j', 'sensu/sensu', 'shawn42/gamebox', 'applicationsonline/librarian', 'haml/haml', 'sporkmonger/addressable', 'google/google-api-ruby-client', 'elm-city-craftworks/practicing-ruby-web', 'sunlightlabs/scout', 'floere/phony', 'data-axle/cassandra_object', 'typhoeus/typhoeus', 'shoes/shoes4', 'troessner/reek', 'recurly/recurly-client-ruby', 'CloudifySource/cloudify', 'puppetlabs/puppetlabs-firewall', 'typhoeus/ethon', 'sparklemotion/nokogiri', 'tinkerpop/blueprints', 'tinkerpop/rexster', 'thinkaurelius/titan', 'openSUSE/open-build-service', 'engineyard/ey-cloud-recipes', 'git/git-scm.com', 'honeybadger-io/honeybadger-ruby', 'azagniotov/stubby4j', 'sferik/twitter', 'calagator/calagator', 'openshift/rhc', 'codefirst/AsakusaSatellite', 'DatabaseCleaner/database_cleaner', 'burke/zeus', 'fog/fog', 'twilio/twilio-java', 'twitter/commons', 'Albacore/albacore', 'prawnpdf/prawn', 'enspiral/loomio', 'refinery/refinerycms', 'sevntu-checkstyle/sevntu.checkstyle', 'opal/opal', 'graphhopper/graphhopper', 'sparklemotion/mechanize', 'SomMeri/less4j', 'tent/tentd', 'searchbox-io/Jest', 'square/dagger', 'google/truth', 'square/okhttp', 'square/retrofit', 'maxcom/lorsource', 'jneen/rouge', 'jmkgreen/morphia', 'SpontaneousCMS/spontaneous', 'everzet/capifony', 'killbill/killbill', 'scobal/seyren', 'intuit/simple_deploy', 'projectblacklight/blacklight', 'rapid7/metasploit-framework', 'amahi/platform', 'vcr/vcr', 'Findwise/Hydra', 'structr/structr', 'sachin-handiekar/jInstagram', 'nutzam/nutz', 'slim-template/slim', 'puppetlabs/puppetlabs-stdlib', 'puppetlabs/facter', 'phoet/on_ruby', 'dreamhead/moco', 'travis-ci/travis.rb', 'cloudfoundry/cloud_controller_ng', 'square/assertj-android', 'jmxtrans/jmxtrans', 'twitter/secureheaders', 'nanoc/nanoc', 'expertiza/expertiza', 'asciidoctor/asciidoctor', 'rubber/rubber', 'openMF/mifosx', 'mybatis/mybatis-3', 'test-kitchen/test-kitchen', 'owlcs/owlapi', 'engineyard/engineyard-serverside', 'selendroid/selendroid', 'ruboto/ruboto', 'openfoodfoundation/openfoodnetwork', 'stephanenicolas/robospice', 'joscha/play-authenticate', 'undera/jmeter-plugins', 'cantino/huginn', 'resque/resque', 'albertlatacz/java-repl', 'l0rdn1kk0n/wicket-bootstrap', 'dynjs/dynjs', 'abarisain/dmix', 'dropwizard/dropwizard', 'dropwizard/metrics', 'jberkel/sms-backup-plus', 'rubymotion/sugarcube', 'naver/yobi', 'Shopify/active_shipping', 'projecthydra/sufia', 'rubymotion/BubbleWrap', 'pivotal-sprout/sprout-osx-apps', 'chef/omnibus', 'JodaOrg/joda-time', 'EmmanuelOga/ffaker', 'kostya/eye', 'laurentpetit/ccw', 'puniverse/quasar', 'simpligility/android-maven-plugin', 'jsonld-java/jsonld-java', 'travis-ci/travis-cookbooks', 'FenixEdu/fenixedu-academic', 'threerings/playn', 'restlet/restlet-framework-java', 'jedi4ever/veewee', 'sensu/sensu-community-plugins', 'OpenRefine/OpenRefine', 'chef/chef', 'fluent/fluentd', 'perwendel/spark', 'joelittlejohn/jsonschema2pojo', 'jOOQ/jOOQ', 'springside/springside4', 'github/hub', 'johncarl81/parceler', 'discourse/onebox', 'julianhyde/optiq', 'ruby-ldap/ruby-net-ldap', 'DSpace/DSpace', 'jeremyevans/sequel', 'bikeindex/bike_index', 'doanduyhai/Achilles', 'rackerlabs/blueflood', 'rodjek/librarian-puppet', 'p6spy/p6spy', 'square/wire', 'Nodeclipse/nodeclipse-1', 'rebelidealist/stripe-ruby-mock', 'checkstyle/checkstyle', 'elastic/logstash', 'airlift/airlift', 'lenskit/lenskit', 'MiniProfiler/rack-mini-profiler', 'geoserver/geoserver', 'ocpsoft/rewrite', 'Unidata/thredds', 'torakiki/pdfsam', 'loopj/android-async-http', 'feedbin/feedbin', 'recruit-tech/redpen', 'brettwooldridge/HikariCP', 'puppetlabs/marionette-collective', 'iipc/openwayback', 'caelum/vraptor4', 'dianping/cat', 'jphp-compiler/jphp', 'mockito/mockito', 'oblac/jodd', 'facebook/buck', 'facebook/presto', 'jpos/jPOS', 'hamstergem/hamster', 'mongodb/morphia', 'realestate-com-au/pact', 'inaturalist/inaturalist', 'jtwig/jtwig', 'go-lang-plugin-org/go-lang-idea-plugin', 'square/picasso', 'voltrb/volt', 'zxing/zxing', 'openaustralia/morph', 'GlowstoneMC/Glowstone', 'owncloud/android', 'JakeWharton/u2020', 'rpush/rpush', 'OneBusAway/onebusaway-android', 'rabbit-shocker/rabbit', 'azkaban/azkaban', 'relayrides/pushy', 'deeplearning4j/deeplearning4j', 'github/developer.github.com', 'xetorthio/jedis', 'FasterXML/jackson-core', 'FasterXML/jackson-databind', 'protostuff/protostuff', 'atmos/heaven', 'MrTJP/ProjectRed', 'lemire/RoaringBitmap', 'apache/drill', 'Kapeli/cheatsheets', 'gradle/gradle', 'OpenGrok/OpenGrok', 'spring-io/sagan', 'mendhak/gpslogger', 'thoughtbot/hound', 'teamed/qulice', 'jcabi/jcabi-aspects', 'jcabi/jcabi-github', 'jcabi/jcabi-http', 'yegor256/rultor', 'querydsl/querydsl', 'codevise/pageflow', 'grails/grails-core', 'weld/core', 'thatJavaNerd/JRAW', 'bndtools/bnd', 'igniterealtime/Openfire', 'zendesk/samson', 'bndtools/bndtools', 'xtreemfs/xtreemfs', 'puniverse/capsule', 'broadinstitute/picard', 'github/github-services', 'gavinlaking/vedeu', 'haiwen/seadroid', 'AChep/AcDisplay', 'GoClipse/goclipse', 'hsz/idea-gitignore', 'jsprit/jsprit', 'dblock/waffle', 'numenta/htm.java', 'rightscale/praxis', 'google/error-prone', 'datastax/ruby-driver', 'iluwatar/java-design-patterns', 'Netflix/Hystrix', 'oyachai/HearthSim', 'jayway/JsonPath', 'exteso/alf.io', 'spring-cloud/spring-cloud-config', 'validator/validator', 'HubSpot/jinjava', 'connectbot/connectbot', 'google/physical-web', 'myui/hivemall', 'MarkUsProject/Markus', 'jMonkeyEngine/jmonkeyengine', 'davidmoten/rxjava-jdbc', 'qos-ch/logback', 'Homebrew/homebrew-science', 'GoogleCloudPlatform/DataflowJavaSDK', 'SoftInstigate/restheart', 'naver/pinpoint', 'KronicDeth/intellij-elixir', 'embulk/embulk', 'loomio/loomio', 'openstreetmap/openstreetmap-website', 'activescaffold/active_scaffold', 'tananaev/traccar', 'SonarSource/sonarqube', 'grpc/grpc-java', 'psi-probe/psi-probe', 'orientation/orientation', 'square/keywhiz', 'aws/aws-sdk-java', 'Shopify/shipit-engine', 'perfectsense/brightspot-cms', 'jamesagnew/hapi-fhir']
def get_median(data):
    data = sorted(data)
    size = len(data)
    if size % 2 == 0:  # 判断列表长度为偶数
        median = (data[size // 2] + data[size // 2 - 1]) / 2
        data[0] = median
    if size % 2 == 1:  # 判断列表长度为奇数
        median = data[(size - 1) // 2]
        data[0] = median
    return data[0]

result=[]
test=[]

for nameindex in range(len(project_names)):
    file_name = project_names[nameindex] + ".csv"
    file_name = file_name.split("/")[1]
    print(file_name)

    string = "/Users/jinxianhao/Documents/src/python/CI/Data_Base/all_dataset/" + file_name
    csv_file = csv.reader(open(string, 'r'))
    pre = []
    final = []
    for item in csv_file:
        pre.append(item)

    for i in range(len(pre[0])):
        temp = []
        for index in range(1, len(pre)):
            # print(index)
            # print(pre[index][i])
            temp.append(pre[index][i])
        final.append(temp)

    indices = []
    for index in range(len(final[42])):
        if final[42][index] == 'failed':
            if final[42][index - 1] == 'passed':
                indices.append(index)
        elif index==len(final[42])-1 and final[42][index]=='passed':
            indices.append(index)
    #print(final[42])
    #print(indices)
    passes=[]
    for item in indices:
        tmp = 0
        temp = item - 1

        while (final[42][temp - 1] != 'failed'):
            temp = temp - 1
            if temp <= 0:
                break

        if temp >= 1:
            passes.append(item-temp)

    test_line=[]
    test_case=[]
    assert_case=[]

    for item in final[35]:
        try:
            test_line.append(float(item))
        except:
            item=str(item)
    for item in final[36]:
        try:
            test_case.append(float(item))
        except:
            item=str(item)
    for item in final[37]:
        try:
            assert_case.append(float(item))
        except:
            item=str(item)

    #print(passes)
    #for index in range(len(passes)):
    sheet1.write(col, 0, get_median(test_line))
    sheet1.write(col, 1, get_median(passes))

    sheet2.write(col, 0, get_median(test_case))
    sheet2.write(col, 1, get_median(passes))

    sheet2.write(col, 0, get_median(assert_case))
    sheet2.write(col, 1, get_median(passes))

    col=col+1
    result.append(get_median(passes))
    test.append(get_median(test_line))
#print(result)
#book.save(r'pass_trend1.xls')


result=[5.0, 3, 11.5, 16.0, 3, 11, 13, 5.5, 2, 4, 3, 8.0, 5, 2, 3.0, 6, 3.0, 7.0, 6.0, 18.5, 8, 5.0, 5, 7.5, 6.0, 6.0, 3, 3, 6, 8, 7, 32.5, 8.0, 9, 7.0, 5, 2, 12, 9, 10.5, 2, 10.0, 7.5, 4.0, 2.0, 7, 6, 3.5, 3.5, 6.0, 2.5, 6, 3, 5, 8.0, 1.0, 11.5, 7, 2, 10, 6.0, 3.0, 6, 12, 3.0, 5.5, 9.5, 3, 6.0, 273, 13.0, 5.0, 2, 3, 9, 8, 8, 11, 13, 6.5, 3.0, 6, 5.0, 5.5, 3.0, 18.5, 3.0, 3, 5.5, 40.5, 6, 10, 3, 7.0, 8, 27, 23, 8, 18.5, 8, 5, 3.5, 5, 5.0, 7.5, 14.0, 7.0, 5.0, 10.5, 18, 12.0, 8.5, 19.0, 2.5, 6, 5, 4, 2, 6.0, 112, 79.0, 15.0, 13, 5.5, 8, 24, 17.5, 4, 8, 3.0, 24, 2.5, 7, 6.5, 3.0, 4, 61, 10, 13, 11.0, 10.0, 4.0, 3.5, 32.0, 14.5, 3, 22.5, 28.0, 23, 8, 4.5, 44, 5, 47.5, 12, 10, 15.0, 3.0, 3, 11.5, 3, 114.5, 3, 5, 20, 48.5, 20, 3.0, 7, 5, 15, 13.0, 25, 8.5, 2, 22.5, 3, 39, 12.0, 7, 8.5, 8, 10.5, 2, 3.0, 1.0, 5, 4.0, 15.0, 4.5, 11.0, 2.0, 13.5, 32.5, 11, 16, 13, 8.5, 19, 4.0, 7.0, 2, 19, 31, 27.5, 2.0, 1, 2.0, 9.0, 3, 20, 51.0, 46, 44, 5, 54, 7, 20.5, 4.0, 8, 9, 33, 28.5, 4, 7, 19, 26.0, 9.0, 7, 16.0, 14, 7.0, 32.0, 7, 3.5, 4, 101.0, 1.0, 12, 25.5, 3.5, 2, 8.5, 7.5, 3.0, 4.0, 4, 3, 4.0, 6.0, 23.0, 11.0, 114.5, 4.5, 3, 10.5, 7, 3.0, 23.5, 2, 3.0, 22, 8.5, 8, 4, 5.0, 10.5, 12.0, 20, 14, 46, 34.5, 19, 8, 21.0, 3, 15.0, 48.5, 21.5, 10, 3, 6, 4, 13.5, 16, 97, 7.5, 6.0, 15.0, 162, 28.0, 14.0, 61, 10.5, 5.5, 4.0, 4.0, 7, 3, 4, 5, 5.0, 80, 4.0, 148, 3, 17.5, 21, 3, 257, 5, 18, 29.0, 19, 21, 5.5, 6.5, 9, 16.5, 13.0, 3, 83.5, 6, 105.0, 3, 107, 2.0, 18.5, 20, 28, 10, 8.0, 30, 8, 116.5, 8.5, 3.0, 22, 65.0, 4.0, 3, 67.5, 17, 8, 20, 25.5, 3.0, 7, 10, 45, 7.0, 10, 55.0, 8.5, 39, 2.0, 3, 7, 3.0]

print(get_median(test))
#print(sum(result)/len(result))
tmp = []
record = []

for item in result:
    if item != "N/A":
        tmp.append(float(item))
if len(tmp) != 0:
    mean = sum(tmp) / len(tmp)
    temp = np.array(tmp)
    st = np.std(temp)
    #print(get_median(tmp)+3 * st)
    #print(mean + 3 * st)

