from numpy import *
import numpy as np

X=mat([0.8,0.2])
#X=mat([0.6,0.2,0.2])
print(X)
P=mat([[0.92,0.08],[0.66,0.34]])
#P=mat([[0.2,0.3,0.5],[0.1,0.6,0.3],[0.4,0.5,0.1]])
print(P)
print(X*pow(P,2))
print(X*P*P)
print(X*P*P*P)
print('done')
for index in range(1,10):
    print(X * pow(P, index))