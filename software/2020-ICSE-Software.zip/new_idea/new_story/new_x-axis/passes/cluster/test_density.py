import numpy as np
from sklearn.cluster import DBSCAN
from sklearn.cluster import AffinityPropagation
from sklearn.cluster import KMeans
import csv
import matplotlib.pyplot as plt
import xlwt

'''
X=np.array([1,2,3,4,5,11,12,13,14,15])
X=X.reshape(-1,1)
y_pred = DBSCAN().fit_predict(X)
y_pred = AffinityPropagation().fit_predict(X)
print(y_pred)
'''

def get_median(data):
    data = sorted(data)
    size = len(data)
    if size % 2 == 0:  # 判断列表长度为偶数
        median = (data[size // 2] + data[size // 2 - 1]) / 2
        data[0] = median
    if size % 2 == 1:  # 判断列表长度为奇数
        median = data[(size - 1) // 2]
        data[0] = median
    return data[0]

def plot(X):
    Sum_of_squared_distances = []
    K = range(1, 15)
    for k in K:
        km = KMeans(n_clusters=k)
        km = km.fit(X)
        Sum_of_squared_distances.append(km.inertia_)

    plt.plot(K, Sum_of_squared_distances, 'bx-')
    plt.xlabel('k')
    plt.ylabel('Sum_of_squared_distances')
    plt.title('Elbow Method For Optimal k')
    plt.show()

project_names=['rails/rails', 'myronmarston/vcr', 'concerto/concerto', 'benhoskings/babushka', 'rubinius/rubinius', 'rubychan/coderay', 'codeforamerica/adopt-a-hydrant', 'radiant/radiant', 'saberma/shopqi', 'rspec/rspec-core', 'engineyard/engineyard', 'plataformatec/devise', 'rspec/rspec-rails', 'karmi/retire', 'sferik/rails_admin', 'tdiary/tdiary-core', 'dkubb/veritas', 'sstephenson/sprockets', 'thoughtbot/factory_girl', 'weppos/whois', 'errbit/errbit', 'padrino/padrino-framework', 'thoughtbot/paperclip', 'plataformatec/simple_form', 'huerlisi/bookyt', 'hotsh/rstat.us', 'mperham/dalli', 'innoq/iqvoc', 'cheezy/page-object', 'justinfrench/formtastic', 'nov/fb_graph', 'assaf/vanity', 'activerecord-hackery/ransack', 'jimweirich/rake', 'rspec/rspec-mocks', 'neo4jrb/neo4j', 'diaspora/diaspora', 'test-unit/test-unit', 'Shopify/liquid', 'activeadmin/activeadmin', 'ari/jobsworth', 'thoughtbot/shoulda-matchers', 'rubygems/rubygems', 'rdoc/rdoc', 'spree/spree', 'rubyzip/rubyzip', 'pry/pry', 'jruby/activerecord-jdbc-adapter', 'sass/sass', 'jruby/warbler', 'fatfreecrm/fat_free_crm', 'rspec/rspec-expectations', 'excon/excon', 'typus/typus', 'heroku/heroku', 'nahi/httpclient', 'podio/podio-rb', 'maxdemarzi/neography', 'locomotivecms/engine', 'gedankenstuecke/snpr', 'peter-murach/github', 'jnicklas/capybara', 'travis-ci/travis-core', 'presidentbeef/brakeman', 'mikel/mail', 'randym/axlsx', 'kmuto/review', 'danielweinmann/catarse', 'middleman/middleman', 'rubyworks/facets', 'railsbp/rails_best_practices', 'comfy/comfortable-mexican-sofa', 'mongoid/moped', 'wr0ngway/rubber', 'rslifka/elasticity', 'lsegal/yard', 'NoamB/sorcery', 'puppetlabs/puppet', 'mitchellh/vagrant', 'ai/r18n', 'celluloid/celluloid', 'jordansissel/fpm', 'neo4jrb/neo4j-core', 'orbeon/orbeon-forms', 'redis/redis-rb', 'pivotal/pivotal_workstation', 'jruby/jruby', 'louismullie/treat', 'puma/puma', 'pophealth/popHealth', 'twitter/twitter-cldr-rb', 'gistflow/gistflow', 'adamfisk/LittleProxy', 'awestruct/awestruct', 'jnunemaker/httparty', 'Graylog2/graylog2-server', 'neuland/jade4j', 'sensu/sensu', 'shawn42/gamebox', 'applicationsonline/librarian', 'haml/haml', 'sporkmonger/addressable', 'google/google-api-ruby-client', 'elm-city-craftworks/practicing-ruby-web', 'sunlightlabs/scout', 'floere/phony', 'data-axle/cassandra_object', 'typhoeus/typhoeus', 'shoes/shoes4', 'troessner/reek', 'recurly/recurly-client-ruby', 'CloudifySource/cloudify', 'puppetlabs/puppetlabs-firewall', 'typhoeus/ethon', 'sparklemotion/nokogiri', 'tinkerpop/blueprints', 'tinkerpop/rexster', 'thinkaurelius/titan', 'openSUSE/open-build-service', 'engineyard/ey-cloud-recipes', 'git/git-scm.com', 'honeybadger-io/honeybadger-ruby', 'azagniotov/stubby4j', 'sferik/twitter', 'calagator/calagator', 'openshift/rhc', 'codefirst/AsakusaSatellite', 'DatabaseCleaner/database_cleaner', 'burke/zeus', 'fog/fog', 'twilio/twilio-java', 'twitter/commons', 'Albacore/albacore', 'prawnpdf/prawn', 'enspiral/loomio', 'refinery/refinerycms', 'sevntu-checkstyle/sevntu.checkstyle', 'opal/opal', 'graphhopper/graphhopper', 'sparklemotion/mechanize', 'SomMeri/less4j', 'tent/tentd', 'searchbox-io/Jest', 'square/dagger', 'google/truth', 'square/okhttp', 'square/retrofit', 'maxcom/lorsource', 'jneen/rouge', 'jmkgreen/morphia', 'SpontaneousCMS/spontaneous', 'everzet/capifony', 'killbill/killbill', 'scobal/seyren', 'intuit/simple_deploy', 'projectblacklight/blacklight', 'rapid7/metasploit-framework', 'amahi/platform', 'vcr/vcr', 'Findwise/Hydra', 'structr/structr', 'sachin-handiekar/jInstagram', 'nutzam/nutz', 'slim-template/slim', 'puppetlabs/puppetlabs-stdlib', 'puppetlabs/facter', 'phoet/on_ruby', 'dreamhead/moco', 'travis-ci/travis.rb', 'cloudfoundry/cloud_controller_ng', 'square/assertj-android', 'jmxtrans/jmxtrans', 'twitter/secureheaders', 'nanoc/nanoc', 'expertiza/expertiza', 'asciidoctor/asciidoctor', 'rubber/rubber', 'openMF/mifosx', 'mybatis/mybatis-3', 'test-kitchen/test-kitchen', 'owlcs/owlapi', 'engineyard/engineyard-serverside', 'selendroid/selendroid', 'ruboto/ruboto', 'openfoodfoundation/openfoodnetwork', 'stephanenicolas/robospice', 'joscha/play-authenticate', 'undera/jmeter-plugins', 'cantino/huginn', 'resque/resque', 'albertlatacz/java-repl', 'l0rdn1kk0n/wicket-bootstrap', 'dynjs/dynjs', 'abarisain/dmix', 'dropwizard/dropwizard', 'dropwizard/metrics', 'jberkel/sms-backup-plus', 'rubymotion/sugarcube', 'naver/yobi', 'Shopify/active_shipping', 'projecthydra/sufia', 'rubymotion/BubbleWrap', 'pivotal-sprout/sprout-osx-apps', 'chef/omnibus', 'JodaOrg/joda-time', 'EmmanuelOga/ffaker', 'kostya/eye', 'laurentpetit/ccw', 'puniverse/quasar', 'simpligility/android-maven-plugin', 'jsonld-java/jsonld-java', 'travis-ci/travis-cookbooks', 'FenixEdu/fenixedu-academic', 'threerings/playn', 'restlet/restlet-framework-java', 'jedi4ever/veewee', 'sensu/sensu-community-plugins', 'OpenRefine/OpenRefine', 'chef/chef', 'fluent/fluentd', 'perwendel/spark', 'joelittlejohn/jsonschema2pojo', 'jOOQ/jOOQ', 'springside/springside4', 'github/hub', 'johncarl81/parceler', 'discourse/onebox', 'julianhyde/optiq', 'ruby-ldap/ruby-net-ldap', 'DSpace/DSpace', 'jeremyevans/sequel', 'bikeindex/bike_index', 'doanduyhai/Achilles', 'rackerlabs/blueflood', 'rodjek/librarian-puppet', 'p6spy/p6spy', 'square/wire', 'Nodeclipse/nodeclipse-1', 'rebelidealist/stripe-ruby-mock', 'checkstyle/checkstyle', 'elastic/logstash', 'airlift/airlift', 'lenskit/lenskit', 'MiniProfiler/rack-mini-profiler', 'geoserver/geoserver', 'ocpsoft/rewrite', 'Unidata/thredds', 'torakiki/pdfsam', 'loopj/android-async-http', 'feedbin/feedbin', 'recruit-tech/redpen', 'brettwooldridge/HikariCP', 'puppetlabs/marionette-collective', 'iipc/openwayback', 'caelum/vraptor4', 'dianping/cat', 'jphp-compiler/jphp', 'mockito/mockito', 'oblac/jodd', 'facebook/buck', 'facebook/presto', 'jpos/jPOS', 'hamstergem/hamster', 'mongodb/morphia', 'realestate-com-au/pact', 'inaturalist/inaturalist', 'jtwig/jtwig', 'go-lang-plugin-org/go-lang-idea-plugin', 'square/picasso', 'voltrb/volt', 'zxing/zxing', 'openaustralia/morph', 'GlowstoneMC/Glowstone', 'owncloud/android', 'JakeWharton/u2020', 'rpush/rpush', 'OneBusAway/onebusaway-android', 'rabbit-shocker/rabbit', 'azkaban/azkaban', 'relayrides/pushy', 'deeplearning4j/deeplearning4j', 'github/developer.github.com', 'xetorthio/jedis', 'FasterXML/jackson-core', 'FasterXML/jackson-databind', 'protostuff/protostuff', 'atmos/heaven', 'MrTJP/ProjectRed', 'lemire/RoaringBitmap', 'apache/drill', 'Kapeli/cheatsheets', 'gradle/gradle', 'OpenGrok/OpenGrok', 'spring-io/sagan', 'mendhak/gpslogger', 'thoughtbot/hound', 'teamed/qulice', 'jcabi/jcabi-aspects', 'jcabi/jcabi-github', 'jcabi/jcabi-http', 'yegor256/rultor', 'querydsl/querydsl', 'codevise/pageflow', 'grails/grails-core', 'weld/core', 'thatJavaNerd/JRAW', 'bndtools/bnd', 'igniterealtime/Openfire', 'zendesk/samson', 'bndtools/bndtools', 'xtreemfs/xtreemfs', 'puniverse/capsule', 'broadinstitute/picard', 'github/github-services', 'gavinlaking/vedeu', 'haiwen/seadroid', 'AChep/AcDisplay', 'GoClipse/goclipse', 'hsz/idea-gitignore', 'jsprit/jsprit', 'dblock/waffle', 'numenta/htm.java', 'rightscale/praxis', 'google/error-prone', 'datastax/ruby-driver', 'iluwatar/java-design-patterns', 'Netflix/Hystrix', 'oyachai/HearthSim', 'jayway/JsonPath', 'exteso/alf.io', 'spring-cloud/spring-cloud-config', 'validator/validator', 'HubSpot/jinjava', 'connectbot/connectbot', 'google/physical-web', 'myui/hivemall', 'MarkUsProject/Markus', 'jMonkeyEngine/jmonkeyengine', 'davidmoten/rxjava-jdbc', 'qos-ch/logback', 'Homebrew/homebrew-science', 'GoogleCloudPlatform/DataflowJavaSDK', 'SoftInstigate/restheart', 'naver/pinpoint', 'KronicDeth/intellij-elixir', 'embulk/embulk', 'loomio/loomio', 'openstreetmap/openstreetmap-website', 'activescaffold/active_scaffold', 'tananaev/traccar', 'SonarSource/sonarqube', 'grpc/grpc-java', 'psi-probe/psi-probe', 'orientation/orientation', 'square/keywhiz', 'aws/aws-sdk-java', 'Shopify/shipit-engine', 'perfectsense/brightspot-cms', 'jamesagnew/hapi-fhir']



passes_length=[]
test_density=[]
test_density=[2170.36307188935, 1718.822746923845, 416.76561386844, 1061.95672276678, 411.759334683766, 141.322314049587, 22.170867335885, 638.306364182655, 738.51554663992, 1702.791664804805, 562.331838565022, 1900.327858137905, 1205.86666666667, 2476.17107942974, 1608.75, 199.930337861372, 2632.94117647059, 1298.55810008482, 2231.93473193473, 3839.00002533704, 1199.9450700357, 1388.85338105586, 2178.42437551469, 2402.89855072464, 330.258957076978, 1525.59241706161, 1338.79093198992, 324.152145400037, 805.6844600690424, 3448.64269992663, 1588.10297425644, 1187.97629127858, 673.93891312971, 1455.45722713864, 2270.67868504772, 1834.43546411952, 698.2689979977665, 884.273451870018, 1393.69550637156, 1019.28950329529, 645.349231081905, 1163.75545851528, 1210.45545018148, 1241.816073116975, 790.454208226857, 987.994350282486, 1147.032428149015, 976.000641515428, 1285.84691692703, 242.121644404098, 1331.92798541477, 2293.08783579837, 708.873643487786, 555.384606216895, 819.771981883492, 680.291648254529, 86.7020048095621, 1917.32729331823, 272.412085190688, 228.7582377973805, 2178.38405036726, 211.492797213867, 999.48275862069, 811.999236932469, 562.488574736457, 850.197294250282, 515.13868304044, 410.721026802567, 1.20918984280532, 446.026706508544, 2053.9845981326953, 602.925625660909, 1314.364801364265, 192.207202090197, 13.1842126559439, 870.817843866171, 1236.16089207487, 1257.37439222042, 517.702019227057, 644.706336939722, 494.729444834856, 413.456599897278, 924.155513065647, 35.2320639093252, 1286.53780942692, 12.9525074726005, 2605.95545513234, 209.566701626812, 413.198959687906, 480.781348456207, 1173.39865293829, 472.922252010724, 604.149144939725, 465.1195499296765, 1526.31578947368, 213.242106763595, 484.29930019738, 704.761904761905, 297.401595060458, 603.518693056865, 1063.90532544379, 2570.21637675011, 457.793482528465, 564.509215602229, 560.614577477984, 40.1223461676862, 674.220963172805, 2180.97643097643, 563.166011105635, 2211.1801242236, 790.575916230366, 87.8052121502688, 2764.96922216004, 1053.3033033033, 0.0, 811.804346180056, 725.107264388223, 338.873079112123, 721.355955488391, 0.0, 271.761133603239, 1023.24324324324, 1272.14428857715, 2417.35537190083, 1214.6490335707, 801.148519310888, 634.480560866794, 1213.0912167584352, 225.836431226766, 267.310221519259, 233.018443544759, 506.113111311131, 721.674876847291, 1046.13025011798, 355.299269170709, 503.798194066218, 1584.236472266025, 488.418984593113, 424.348013506717, 1406.766262732975, 135.916482634009, 1569.01042439322, 1357.38095238095, 661.071143085532, 1233.130913073915, 1314.87702459508, 1183.781559959125, 196.1207422242155, 156.845847247657, 1436.84010634258, 1073.5211443563, 394.26523297491, 662.672626783394, 397.313104792039, 1160.9649122807, 668.4111670030966, 20.5561630574394, 67.9409931435695, 1718.822746923845, 543.5730558660035, 239.673247513515, 269.396551724138, 397.032395150382, 2013.84083044983, 1338.969251983435, 1246.85859710514, 739.168490153173, 615.549537350485, 436.674008810573, 2072.58984597832, 0.0, 396.139119336311, 141.91194804576747, 1533.5604111767848, 231.389314970138, 1713.92991531418, 192.207202090197, 22.0698126727403, 1402.44391025641, 2700.73664825046, 438.094551166462, 256.997455470738, 201.73568818514, 740.769630785231, 326.465986141122, 1190.28835690968, 43.3743169398907, 977.147577092511, 800.796812749004, 1325.033274179235, 184.91124260355, 220.318316005648, 242.513957029267, 0.0, 942.9503820435585, 771.896176959468, 330.063386658618, 908.568142610696, 278.91156462585, 957.708961125154, 1263.6277302944, 1301.03067295265, 11.8038740920097, 1120.7462347118549, 1807.05827722313, 598.544232922732, 1889.85568760611, 15.5893158574124, 248.16909686149802, 2165.6074037388, 382.799325463744, 19.6828868234008, 7.122862324312065, 148.423520700932, 241.303520530604, 18.5994082006482, 4.76308301373253, 121.790021807824, 1475.341388143695, 821.940406227446, 489.75468975469, 1208.59053497942, 56.68075732856495, 490.089254665585, 0.0, 798.576902025178, 35.405872193437, 373.5168913106405, 525.130679533575, 74.43640801995309, 1787.79468316335, 703.53982300885, 1740.3429043586, 526.951167984548, 162.881754111198, 522.532800912721, 2311.40286177902, 16.0512957520705, 1056.70952851962, 1184.17415342087, 611.897747790554, 753.098080701224, 543.548984886546, 593.998775260257, 471.854415327652, 588.0355805169295, 181.033801100501, 899.58932238193, 0.0, 68.190623789229, 973.4086356086285, 1650.48375950242, 910.659509202454, 168.343374362227, 1136.176941623605, 186.75653138395649, 84.4863594830962, 611.857071519725, 477.208486279833, 661.231992545986, 355.039980615459, 854.8461400444395, 4.32588320115357, 1436.84010634258, 147.296137339056, 352.710890777463, 474.6271970803065, 141.010715388819, 764.844981607987, 383.895650784665, 213.581406268341, 189.676463324278, 45.7020128864692, 90.8068506796054, 0.0, 921.234699308143, 136.240777266418, 37.7126311979732, 283.327249868192, 1054.8079642513699, 73.5664092999046, 0.0, 568.370890881189, 485.712507003673, 651.764646261114, 550.85916587514, 246.286161063331, 0.0, 728.498478312039, 267.73118451389, 0.0, 164.871291837584, 236.829494265359, 436.560486757337, 38.012089335892654, 1552.72919978802, 719.2419367994655, 615.189873417722, 901.347139741835, 577.071577071577, 568.023968405284, 1121.27102756409, 1506.76284941389, 120.956331596887, 1297.19320781742, 284.971179530437, 318.523197866217, 8.70464247598719, 1130.1897571106, 7.43213606900921, 171.8814037870785, 261.320923572579, 468.708012163213, 1047.6135799190101, 21.3379469434833, 1.098951474793485, 6.20522881781266, 94.41741124661056, 65.2621937256698, 770.082064292791, 1183.4528177730099, 723.992947239929, 998.247458815282, 1026.2865640683349, 842.952275249722, 149.663615308261, 1232.80898876404, 531.884686674291, 754.136029411765, 99.0284005979073, 713.322091062395, 12.7581098648608, 465.168299957392, 62.6890959699867, 5.20833333333333, 125.964178323964, 977.837142574453, 118.148605116732, 793.794618341571, 956.601905282207, 0.0, 839.492732105567, 363.49541017362753, 278.081632653061, 368.22400990099, 280.0405095473825, 355.299269170709, 1226.14898273486, 320.103537532355, 173.6640817683205, 1042.58923755653, 312.38591916558, 111.822480902146, 679.858657243816, 810.0442043222, 15.152749650778, 995.439574360274, 0.0, 151.40520167029]
X=np.array(test_density)
X=X.reshape(-1,1)
y_pred0 = KMeans(n_clusters=3).fit_predict(X)
cluster=[[],[],[]]
cluster1=[[],[],[]]
names=[[],[],[]]
for index in range(len(y_pred0)):
    if y_pred0[index]==0:
        cluster[0].append(index)
        cluster1[0].append(test_density[index])
        names[0].append(project_names[index])
    elif y_pred0[index]==1:
        cluster[1].append(index)
        cluster1[1].append(test_density[index])
        names[1].append(project_names[index])
    else:
        cluster[2].append(index)
        cluster1[2].append(test_density[index])
        names[2].append(project_names[index])

for item in cluster1:
    print(get_median(item))
print(names)
#'''
for nameindex in range(len(project_names)):
    file_name = project_names[nameindex] + ".csv"
    file_name = file_name.split("/")[1]
    print(file_name)

    string = "/Users/jinxianhao/Documents/src/python/CI/Data_Base/all_dataset/" + file_name
    csv_file = csv.reader(open(string, 'r'))
    pre = []
    final = []
    for item in csv_file:
        pre.append(item)

    for i in range(len(pre[0])):
        temp = []
        for index in range(1, len(pre)):
            # print(index)
            # print(pre[index][i])
            temp.append(pre[index][i])
        final.append(temp)

    indices = []
    for index in range(len(final[42])):
        if final[42][index] == 'failed':
            if final[42][index - 1] == 'passed':
                indices.append(index)
        elif index==len(final[42])-1 and final[42][index]=='passed':
            indices.append(index)
    #print(final[42])
    #print(indices)
    passes=[]
    for item in indices:
        tmp = 0
        temp = item - 1

        while (final[42][temp - 1] != 'failed'):
            temp = temp - 1
            if temp <= 0:
                break

        if temp >= 1:
            passes.append(item-temp)

    test_line=[]
    test_case=[]
    assert_case=[]

    for item in final[35]:
        try:
            test_line.append(float(item))
        except:
            item=str(item)
    for item in final[36]:
        try:
            test_case.append(float(item))
        except:
            item=str(item)
    for item in final[37]:
        try:
            assert_case.append(float(item))
        except:
            item=str(item)
    passes_length.append(get_median(passes))
    #test_density.append(sum(test_line)/len(test_line))
    test_density.append(get_median(test_line))
    #'''
#'''
result=[[],[],[]]
for index in range(len(cluster)):
    for item in cluster[index]:
        result[index].append(passes_length[item])

for item in result:
    print(get_median(item))
    print(sum(item)/len(item))

book = xlwt.Workbook(encoding='utf-8', style_compression=0)
sheet1 = book.add_sheet('test_line', cell_overwrite_ok=True)
sheet2 = book.add_sheet('test_case', cell_overwrite_ok=True)
sheet3 = book.add_sheet('assert_case', cell_overwrite_ok=True)
col=0

for index in range(len(result)):
    string='cluster '+ str(index)
    for item in result[index]:
        sheet1.write(col,0,string)
        sheet1.write(col,1,item)
        col=col+1
book.save(r'cluster_box_pass_length.xls')
#'''