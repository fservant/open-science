import numpy as np
from sklearn.cluster import DBSCAN
from sklearn.cluster import AffinityPropagation
from sklearn.cluster import KMeans
import csv
import matplotlib.pyplot as plt
import xlwt
import time

def get_median(data):
    data = sorted(data)
    size = len(data)
    if size % 2 == 0:  # 判断列表长度为偶数
        median = (data[size // 2] + data[size // 2 - 1]) / 2
        data[0] = median
    if size % 2 == 1:  # 判断列表长度为奇数
        median = data[(size - 1) // 2]
        data[0] = median
    return data[0]

def last_build_status(project_names,bookname):
    book = xlwt.Workbook(encoding='utf-8', style_compression=0)
    sheet0 = book.add_sheet('ratio', cell_overwrite_ok=True)
    sheet1 = book.add_sheet('failure', cell_overwrite_ok=True)
    sheet2 = book.add_sheet('build', cell_overwrite_ok=True)

    final_result = []
    failure_remain = []
    build_remain = []
    for index in range(6):
        final_result.append([])
        failure_remain.append([])
        build_remain.append([])

    for nameindex in range(len(project_names)):
        file_name = project_names[nameindex] + ".csv"
        file_name = file_name.split("/")[1]
        #print(file_name)

        string = "/Users/jinxianhao/Documents/src/python/CI/Data_Base/all_dataset/" + file_name
        csv_file = csv.reader(open(string, 'r'))
        pre = []
        final = []
        for item in csv_file:
            pre.append(item)

        for i in range(len(pre[0])):
            temp = []
            for index in range(1, len(pre)):
                # print(index)
                # print(pre[index][i])
                temp.append(pre[index][i])
            final.append(temp)

        build_result = []
        for item in final[42]:
            if item == 'passed':
                build_result.append(1)
            else:
                build_result.append(0)

        result = []
        build = []
        failure = []
        result.append(1 - sum(build_result) / len(build_result))
        build.append(1)
        failure.append(1)

        for num in range(1, 6):
            temp_result = []
            flag = 0
            for index in range(len(build_result)):
                if index == flag:
                    temp_result.append(build_result[index])
                    if build_result[index] == 1:
                        flag = flag + num + 1
                    else:
                        flag = flag + 1
            result.append(1 - sum(temp_result) / len(temp_result))
            build.append(len(temp_result) / len(build_result))
            failure.append((len(temp_result) - sum(temp_result)) / (len(build_result) - sum(build_result)))

        for index in range(len(result)):
            final_result[index].append(result[index])
            if failure[index] != 0:
                failure_remain[index].append(failure[index])
            else:
                failure_remain[index].append(0)
            build_remain[index].append(build[index])

    col0 = 0
    col1 = 0
    col2 = 0
    for index in range(len(final_result)):
        string = 'after ' + str(index)
        for item in final_result[index]:
            sheet0.write(col0, 0, string)
            sheet0.write(col0, 1, item)
            col0 = col0 + 1
        for item in failure_remain[index]:
            sheet1.write(col1, 0, string)
            sheet1.write(col1, 1, item)
            col1 = col1 + 1
        for item in build_remain[index]:
            sheet2.write(col2, 0, string)
            sheet2.write(col2, 1, item)
            col2 = col2 + 1

    book.save(bookname)

selected_names=[['saberma/shopqi', 'karmi/retire', 'dkubb/veritas', 'danielweinmann/catarse', 'pivotal/pivotal_workstation', 'pophealth/popHealth', 'gistflow/gistflow', 'applicationsonline/librarian', 'data-axle/cassandra_object', 'CloudifySource/cloudify', 'thinkaurelius/titan', 'enspiral/loomio', 'tent/tentd', 'intuit/simple_deploy', 'Findwise/Hydra', 'stephanenicolas/robospice', 'cantino/huginn', 'chef/omnibus', 'EmmanuelOga/ffaker', 'threerings/playn', 'chef/chef', 'springside/springside4', 'julianhyde/optiq', 'ruby-ldap/ruby-net-ldap', 'Nodeclipse/nodeclipse-1', 'checkstyle/checkstyle', 'recruit-tech/redpen', 'brettwooldridge/HikariCP', 'caelum/vraptor4', 'facebook/presto', 'hamstergem/hamster', 'jtwig/jtwig', 'go-lang-plugin-org/go-lang-idea-plugin', 'voltrb/volt', 'GlowstoneMC/Glowstone', 'rpush/rpush', 'deeplearning4j/deeplearning4j', 'github/developer.github.com', 'protostuff/protostuff', 'lemire/RoaringBitmap', 'gradle/gradle', 'spring-io/sagan', 'mendhak/gpslogger', 'thoughtbot/hound', 'teamed/qulice', 'jcabi/jcabi-aspects', 'jcabi/jcabi-github', 'jcabi/jcabi-http', 'yegor256/rultor', 'querydsl/querydsl', 'codevise/pageflow', 'grails/grails-core', 'weld/core', 'thatJavaNerd/JRAW', 'bndtools/bnd', 'igniterealtime/Openfire', 'zendesk/samson', 'bndtools/bndtools', 'xtreemfs/xtreemfs', 'puniverse/capsule', 'broadinstitute/picard', 'github/github-services', 'gavinlaking/vedeu', 'haiwen/seadroid', 'AChep/AcDisplay', 'GoClipse/goclipse', 'hsz/idea-gitignore', 'jsprit/jsprit', 'dblock/waffle', 'numenta/htm.java', 'rightscale/praxis', 'google/error-prone', 'datastax/ruby-driver', 'iluwatar/java-design-patterns', 'Netflix/Hystrix', 'oyachai/HearthSim', 'jayway/JsonPath', 'exteso/alf.io', 'spring-cloud/spring-cloud-config', 'validator/validator', 'HubSpot/jinjava', 'connectbot/connectbot', 'google/physical-web', 'myui/hivemall', 'MarkUsProject/Markus', 'jMonkeyEngine/jmonkeyengine', 'davidmoten/rxjava-jdbc', 'qos-ch/logback', 'Homebrew/homebrew-science', 'GoogleCloudPlatform/DataflowJavaSDK', 'SoftInstigate/restheart', 'naver/pinpoint', 'KronicDeth/intellij-elixir', 'embulk/embulk', 'loomio/loomio', 'openstreetmap/openstreetmap-website', 'activescaffold/active_scaffold', 'tananaev/traccar', 'SonarSource/sonarqube', 'grpc/grpc-java', 'psi-probe/psi-probe', 'orientation/orientation', 'square/keywhiz', 'aws/aws-sdk-java', 'Shopify/shipit-engine', 'perfectsense/brightspot-cms', 'jamesagnew/hapi-fhir'], ['myronmarston/vcr', 'radiant/radiant', 'sstephenson/sprockets', 'hotsh/rstat.us', 'jimweirich/rake', 'typus/typus', 'mongoid/moped', 'wr0ngway/rubber', 'louismullie/treat', 'shawn42/gamebox', 'sporkmonger/addressable', 'sunlightlabs/scout', 'tinkerpop/blueprints', 'tinkerpop/rexster', 'azagniotov/stubby4j', 'codefirst/AsakusaSatellite', 'burke/zeus', 'Albacore/albacore', 'SomMeri/less4j', 'square/dagger', 'jmkgreen/morphia', 'SpontaneousCMS/spontaneous', 'everzet/capifony', 'amahi/platform', 'vcr/vcr', 'structr/structr', 'sachin-handiekar/jInstagram', 'nutzam/nutz', 'slim-template/slim', 'puppetlabs/puppetlabs-stdlib', 'puppetlabs/facter', 'phoet/on_ruby', 'dreamhead/moco', 'travis-ci/travis.rb', 'cloudfoundry/cloud_controller_ng', 'square/assertj-android', 'jmxtrans/jmxtrans', 'twitter/secureheaders', 'nanoc/nanoc', 'expertiza/expertiza', 'asciidoctor/asciidoctor', 'rubber/rubber', 'openMF/mifosx', 'mybatis/mybatis-3', 'test-kitchen/test-kitchen', 'owlcs/owlapi', 'engineyard/engineyard-serverside', 'selendroid/selendroid', 'ruboto/ruboto', 'openfoodfoundation/openfoodnetwork', 'joscha/play-authenticate', 'undera/jmeter-plugins', 'resque/resque', 'albertlatacz/java-repl', 'l0rdn1kk0n/wicket-bootstrap', 'dynjs/dynjs', 'abarisain/dmix', 'dropwizard/dropwizard', 'dropwizard/metrics', 'jberkel/sms-backup-plus', 'rubymotion/sugarcube', 'naver/yobi', 'Shopify/active_shipping', 'projecthydra/sufia', 'rubymotion/BubbleWrap', 'pivotal-sprout/sprout-osx-apps', 'JodaOrg/joda-time', 'kostya/eye', 'laurentpetit/ccw', 'puniverse/quasar', 'simpligility/android-maven-plugin', 'jsonld-java/jsonld-java', 'travis-ci/travis-cookbooks', 'FenixEdu/fenixedu-academic', 'restlet/restlet-framework-java', 'jedi4ever/veewee', 'sensu/sensu-community-plugins', 'OpenRefine/OpenRefine', 'fluent/fluentd', 'perwendel/spark', 'joelittlejohn/jsonschema2pojo', 'jOOQ/jOOQ', 'github/hub', 'johncarl81/parceler', 'discourse/onebox', 'DSpace/DSpace', 'jeremyevans/sequel', 'bikeindex/bike_index', 'doanduyhai/Achilles', 'rackerlabs/blueflood', 'rodjek/librarian-puppet', 'p6spy/p6spy', 'square/wire', 'rebelidealist/stripe-ruby-mock', 'elastic/logstash', 'airlift/airlift', 'lenskit/lenskit', 'MiniProfiler/rack-mini-profiler', 'geoserver/geoserver', 'ocpsoft/rewrite', 'Unidata/thredds', 'torakiki/pdfsam', 'loopj/android-async-http', 'feedbin/feedbin', 'puppetlabs/marionette-collective', 'iipc/openwayback', 'dianping/cat', 'jphp-compiler/jphp', 'mockito/mockito', 'oblac/jodd', 'facebook/buck', 'jpos/jPOS', 'mongodb/morphia', 'realestate-com-au/pact', 'inaturalist/inaturalist', 'square/picasso', 'zxing/zxing', 'openaustralia/morph', 'owncloud/android', 'JakeWharton/u2020', 'OneBusAway/onebusaway-android', 'rabbit-shocker/rabbit', 'azkaban/azkaban', 'relayrides/pushy', 'xetorthio/jedis', 'FasterXML/jackson-core', 'FasterXML/jackson-databind', 'atmos/heaven', 'MrTJP/ProjectRed', 'apache/drill', 'Kapeli/cheatsheets', 'OpenGrok/OpenGrok'], ['rails/rails', 'concerto/concerto', 'benhoskings/babushka', 'rubinius/rubinius', 'rubychan/coderay', 'codeforamerica/adopt-a-hydrant', 'rspec/rspec-core', 'engineyard/engineyard', 'plataformatec/devise', 'rspec/rspec-rails', 'sferik/rails_admin', 'tdiary/tdiary-core', 'thoughtbot/factory_girl', 'weppos/whois', 'errbit/errbit', 'padrino/padrino-framework', 'thoughtbot/paperclip', 'plataformatec/simple_form', 'huerlisi/bookyt', 'mperham/dalli', 'innoq/iqvoc', 'cheezy/page-object', 'justinfrench/formtastic', 'nov/fb_graph', 'assaf/vanity', 'activerecord-hackery/ransack', 'rspec/rspec-mocks', 'neo4jrb/neo4j', 'diaspora/diaspora', 'test-unit/test-unit', 'Shopify/liquid', 'activeadmin/activeadmin', 'ari/jobsworth', 'thoughtbot/shoulda-matchers', 'rubygems/rubygems', 'rdoc/rdoc', 'spree/spree', 'rubyzip/rubyzip', 'pry/pry', 'jruby/activerecord-jdbc-adapter', 'sass/sass', 'jruby/warbler', 'fatfreecrm/fat_free_crm', 'rspec/rspec-expectations', 'excon/excon', 'heroku/heroku', 'nahi/httpclient', 'podio/podio-rb', 'maxdemarzi/neography', 'locomotivecms/engine', 'gedankenstuecke/snpr', 'peter-murach/github', 'jnicklas/capybara', 'travis-ci/travis-core', 'presidentbeef/brakeman', 'mikel/mail', 'randym/axlsx', 'kmuto/review', 'middleman/middleman', 'rubyworks/facets', 'railsbp/rails_best_practices', 'comfy/comfortable-mexican-sofa', 'rslifka/elasticity', 'lsegal/yard', 'NoamB/sorcery', 'puppetlabs/puppet', 'mitchellh/vagrant', 'ai/r18n', 'celluloid/celluloid', 'jordansissel/fpm', 'neo4jrb/neo4j-core', 'orbeon/orbeon-forms', 'redis/redis-rb', 'jruby/jruby', 'puma/puma', 'twitter/twitter-cldr-rb', 'adamfisk/LittleProxy', 'awestruct/awestruct', 'jnunemaker/httparty', 'Graylog2/graylog2-server', 'neuland/jade4j', 'sensu/sensu', 'haml/haml', 'google/google-api-ruby-client', 'elm-city-craftworks/practicing-ruby-web', 'floere/phony', 'typhoeus/typhoeus', 'shoes/shoes4', 'troessner/reek', 'recurly/recurly-client-ruby', 'puppetlabs/puppetlabs-firewall', 'typhoeus/ethon', 'sparklemotion/nokogiri', 'openSUSE/open-build-service', 'engineyard/ey-cloud-recipes', 'git/git-scm.com', 'honeybadger-io/honeybadger-ruby', 'sferik/twitter', 'calagator/calagator', 'openshift/rhc', 'DatabaseCleaner/database_cleaner', 'fog/fog', 'twilio/twilio-java', 'twitter/commons', 'prawnpdf/prawn', 'refinery/refinerycms', 'sevntu-checkstyle/sevntu.checkstyle', 'opal/opal', 'graphhopper/graphhopper', 'sparklemotion/mechanize', 'searchbox-io/Jest', 'google/truth', 'square/okhttp', 'square/retrofit', 'maxcom/lorsource', 'jneen/rouge', 'killbill/killbill', 'scobal/seyren', 'projectblacklight/blacklight', 'rapid7/metasploit-framework']]

for index in range(len(selected_names)):
    print(index)
    bookname='last_build_simulation_age'+str(index)+'.xls'
    last_build_status(selected_names[index],bookname)
    print('done')