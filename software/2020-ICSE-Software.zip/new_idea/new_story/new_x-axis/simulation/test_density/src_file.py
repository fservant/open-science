import numpy as np
from sklearn.cluster import DBSCAN
from sklearn.cluster import AffinityPropagation
from sklearn.cluster import KMeans
import csv
import matplotlib.pyplot as plt
import xlwt
import time

def get_median(data):
    data = sorted(data)
    size = len(data)
    if size % 2 == 0:  # 判断列表长度为偶数
        median = (data[size // 2] + data[size // 2 - 1]) / 2
        data[0] = median
    if size % 2 == 1:  # 判断列表长度为奇数
        median = data[(size - 1) // 2]
        data[0] = median
    return data[0]

def src_file(project_names,bookname):
    book = xlwt.Workbook(encoding='utf-8', style_compression=0)
    sheet0 = book.add_sheet('ratio', cell_overwrite_ok=True)
    sheet1 = book.add_sheet('failure', cell_overwrite_ok=True)
    sheet2 = book.add_sheet('build', cell_overwrite_ok=True)

    final_result = []
    failure_remain = []
    build_remain = []
    for index in range(9):
        final_result.append([])
        failure_remain.append([])
        build_remain.append([])

    for nameindex in range(len(project_names)):
        file_name = project_names[nameindex] + ".csv"
        file_name = file_name.split("/")[1]
        #print(file_name)

        string = "/Users/jinxianhao/Documents/src/python/CI/Data_Base/all_dataset/" + file_name
        csv_file = csv.reader(open(string, 'r'))
        pre = []
        final = []
        for item in csv_file:
            pre.append(item)

        for i in range(len(pre[0])):
            temp = []
            for index in range(1, len(pre)):
                # print(index)
                # print(pre[index][i])
                temp.append(pre[index][i])
            final.append(temp)

        build_result = []
        src_file = []
        for item in final[42]:
            if item == 'passed':
                build_result.append(1)
            else:
                build_result.append(0)
        for item in final[30]:
            src_file.append(float(item))

        result = []
        build = []
        failure = []
        result.append(1 - sum(build_result) / len(build_result))
        build.append(1)
        failure.append(1)

        flag = 0
        churn = 0
        for num in range(0, 8):
            temp_result = []
            for index in range(0, len(build_result)):
                if len(temp_result) > 0 and temp_result[len(temp_result) - 1] == 0:
                    temp_result.append(build_result[index])
                else:
                    if churn + src_file[index] > num:
                        temp_result.append(build_result[index])
                        churn = 0
                    else:
                        churn = churn + src_file[index]

            result.append(1 - sum(temp_result) / len(temp_result))
            build.append(len(temp_result) / len(build_result))
            failure.append((len(temp_result) - sum(temp_result)) / (len(build_result) - sum(build_result)))

        for index in range(len(result)):
            # print(index)
            final_result[index].append(result[index])
            if failure[index] != 0:
                failure_remain[index].append(failure[index])
            else:
                failure_remain[index].append(0)
            build_remain[index].append(build[index])

    f1 = []
    for index in range(len(final_result)):
        f = []
        for index1 in range(len(final_result[index])):
            x = (build_remain[index][index1])
            b = (failure_remain[index][index1])
            f.append(2 * (1 - x) * b / (1 - x + b))
        f1.append(get_median(f))
    #print(f1)
    #print(max(f1))

    col0 = 0
    col1 = 0
    col2 = 0
    for index in range(len(final_result)):
        # print(final_result[index])
        string = 'file ' + str(index - 1)
        print(string)
        print(get_median(final_result[index]))
        print(get_median(failure_remain[index]))
        print(get_median(build_remain[index]))
        for item in final_result[index]:
            sheet0.write(col0, 0, string)
            sheet0.write(col0, 1, item)
            col0 = col0 + 1
        for item in failure_remain[index]:
            sheet1.write(col1, 0, string)
            sheet1.write(col1, 1, item)
            col1 = col1 + 1
        for item in build_remain[index]:
            sheet2.write(col2, 0, string)
            sheet2.write(col2, 1, item)
            col2 = col2 + 1
    #book.save(bookname)

selected_names=[['concerto/concerto', 'rubinius/rubinius', 'rubychan/coderay', 'codeforamerica/adopt-a-hydrant', 'radiant/radiant', 'engineyard/engineyard', 'tdiary/tdiary-core', 'huerlisi/bookyt', 'innoq/iqvoc', 'activerecord-hackery/ransack', 'ari/jobsworth', 'jruby/warbler', 'typus/typus', 'nahi/httpclient', 'podio/podio-rb', 'locomotivecms/engine', 'gedankenstuecke/snpr', 'jnicklas/capybara', 'mikel/mail', 'kmuto/review', 'danielweinmann/catarse', 'middleman/middleman', 'rubyworks/facets', 'comfy/comfortable-mexican-sofa', 'wr0ngway/rubber', 'rslifka/elasticity', 'mitchellh/vagrant', 'ai/r18n', 'celluloid/celluloid', 'jordansissel/fpm', 'orbeon/orbeon-forms', 'pivotal/pivotal_workstation', 'louismullie/treat', 'puma/puma', 'pophealth/popHealth', 'gistflow/gistflow', 'adamfisk/LittleProxy', 'awestruct/awestruct', 'Graylog2/graylog2-server', 'neuland/jade4j', 'shawn42/gamebox', 'applicationsonline/librarian', 'google/google-api-ruby-client', 'elm-city-craftworks/practicing-ruby-web', 'sunlightlabs/scout', 'floere/phony', 'data-axle/cassandra_object', 'shoes/shoes4', 'CloudifySource/cloudify', 'sparklemotion/nokogiri', 'thinkaurelius/titan', 'engineyard/ey-cloud-recipes', 'git/git-scm.com', 'codefirst/AsakusaSatellite', 'burke/zeus', 'fog/fog', 'twilio/twilio-java', 'twitter/commons', 'enspiral/loomio', 'refinery/refinerycms', 'opal/opal', 'graphhopper/graphhopper', 'SomMeri/less4j', 'square/dagger', 'maxcom/lorsource', 'jneen/rouge', 'everzet/capifony', 'killbill/killbill', 'scobal/seyren', 'projectblacklight/blacklight', 'rapid7/metasploit-framework', 'amahi/platform', 'Findwise/Hydra', 'structr/structr', 'sachin-handiekar/jInstagram', 'nutzam/nutz', 'dreamhead/moco', 'travis-ci/travis.rb', 'square/assertj-android', 'jmxtrans/jmxtrans', 'twitter/secureheaders', 'expertiza/expertiza', 'rubber/rubber', 'openMF/mifosx', 'owlcs/owlapi', 'engineyard/engineyard-serverside', 'selendroid/selendroid', 'openfoodfoundation/openfoodnetwork', 'joscha/play-authenticate', 'albertlatacz/java-repl', 'l0rdn1kk0n/wicket-bootstrap', 'dynjs/dynjs', 'abarisain/dmix', 'jberkel/sms-backup-plus', 'naver/yobi', 'pivotal-sprout/sprout-osx-apps', 'EmmanuelOga/ffaker', 'laurentpetit/ccw', 'puniverse/quasar', 'jsonld-java/jsonld-java', 'travis-ci/travis-cookbooks', 'FenixEdu/fenixedu-academic', 'threerings/playn', 'restlet/restlet-framework-java', 'jedi4ever/veewee', 'sensu/sensu-community-plugins', 'OpenRefine/OpenRefine', 'perwendel/spark', 'jOOQ/jOOQ', 'springside/springside4', 'github/hub', 'discourse/onebox', 'julianhyde/optiq', 'ruby-ldap/ruby-net-ldap', 'DSpace/DSpace', 'rackerlabs/blueflood', 'rodjek/librarian-puppet', 'p6spy/p6spy', 'Nodeclipse/nodeclipse-1', 'elastic/logstash', 'lenskit/lenskit', 'MiniProfiler/rack-mini-profiler', 'geoserver/geoserver', 'ocpsoft/rewrite', 'Unidata/thredds', 'loopj/android-async-http', 'feedbin/feedbin', 'iipc/openwayback', 'dianping/cat', 'jphp-compiler/jphp', 'mockito/mockito', 'oblac/jodd', 'facebook/buck', 'facebook/presto', 'hamstergem/hamster', 'realestate-com-au/pact', 'inaturalist/inaturalist', 'jtwig/jtwig', 'go-lang-plugin-org/go-lang-idea-plugin', 'voltrb/volt', 'zxing/zxing', 'openaustralia/morph', 'GlowstoneMC/Glowstone', 'owncloud/android', 'JakeWharton/u2020', 'OneBusAway/onebusaway-android', 'rabbit-shocker/rabbit', 'azkaban/azkaban', 'deeplearning4j/deeplearning4j', 'github/developer.github.com', 'xetorthio/jedis', 'FasterXML/jackson-core', 'FasterXML/jackson-databind', 'protostuff/protostuff', 'atmos/heaven', 'MrTJP/ProjectRed', 'apache/drill', 'Kapeli/cheatsheets', 'gradle/gradle', 'OpenGrok/OpenGrok', 'spring-io/sagan', 'mendhak/gpslogger', 'jcabi/jcabi-aspects', 'jcabi/jcabi-http', 'yegor256/rultor', 'grails/grails-core', 'thatJavaNerd/JRAW', 'bndtools/bnd', 'igniterealtime/Openfire', 'bndtools/bndtools', 'xtreemfs/xtreemfs', 'puniverse/capsule', 'broadinstitute/picard', 'gavinlaking/vedeu', 'haiwen/seadroid', 'AChep/AcDisplay', 'GoClipse/goclipse', 'hsz/idea-gitignore', 'iluwatar/java-design-patterns', 'oyachai/HearthSim', 'exteso/alf.io', 'validator/validator', 'HubSpot/jinjava', 'connectbot/connectbot', 'google/physical-web', 'myui/hivemall', 'jMonkeyEngine/jmonkeyengine', 'Homebrew/homebrew-science', 'SoftInstigate/restheart', 'naver/pinpoint', 'KronicDeth/intellij-elixir', 'embulk/embulk', 'loomio/loomio', 'activescaffold/active_scaffold', 'tananaev/traccar', 'grpc/grpc-java', 'psi-probe/psi-probe', 'orientation/orientation', 'aws/aws-sdk-java', 'perfectsense/brightspot-cms', 'jamesagnew/hapi-fhir'], ['benhoskings/babushka', 'saberma/shopqi', 'rspec/rspec-rails', 'sferik/rails_admin', 'sstephenson/sprockets', 'errbit/errbit', 'padrino/padrino-framework', 'hotsh/rstat.us', 'mperham/dalli', 'cheezy/page-object', 'nov/fb_graph', 'assaf/vanity', 'jimweirich/rake', 'diaspora/diaspora', 'test-unit/test-unit', 'Shopify/liquid', 'activeadmin/activeadmin', 'thoughtbot/shoulda-matchers', 'rubygems/rubygems', 'rdoc/rdoc', 'spree/spree', 'rubyzip/rubyzip', 'pry/pry', 'jruby/activerecord-jdbc-adapter', 'sass/sass', 'fatfreecrm/fat_free_crm', 'excon/excon', 'heroku/heroku', 'travis-ci/travis-core', 'presidentbeef/brakeman', 'randym/axlsx', 'mongoid/moped', 'lsegal/yard', 'NoamB/sorcery', 'puppetlabs/puppet', 'neo4jrb/neo4j-core', 'redis/redis-rb', 'twitter/twitter-cldr-rb', 'jnunemaker/httparty', 'sensu/sensu', 'haml/haml', 'recurly/recurly-client-ruby', 'typhoeus/ethon', 'tinkerpop/blueprints', 'tinkerpop/rexster', 'openSUSE/open-build-service', 'honeybadger-io/honeybadger-ruby', 'azagniotov/stubby4j', 'calagator/calagator', 'openshift/rhc', 'DatabaseCleaner/database_cleaner', 'Albacore/albacore', 'prawnpdf/prawn', 'sevntu-checkstyle/sevntu.checkstyle', 'sparklemotion/mechanize', 'tent/tentd', 'searchbox-io/Jest', 'google/truth', 'square/okhttp', 'square/retrofit', 'jmkgreen/morphia', 'SpontaneousCMS/spontaneous', 'intuit/simple_deploy', 'puppetlabs/puppetlabs-stdlib', 'puppetlabs/facter', 'phoet/on_ruby', 'nanoc/nanoc', 'mybatis/mybatis-3', 'ruboto/ruboto', 'stephanenicolas/robospice', 'undera/jmeter-plugins', 'cantino/huginn', 'resque/resque', 'dropwizard/dropwizard', 'dropwizard/metrics', 'rubymotion/sugarcube', 'Shopify/active_shipping', 'projecthydra/sufia', 'rubymotion/BubbleWrap', 'chef/omnibus', 'chef/chef', 'fluent/fluentd', 'joelittlejohn/jsonschema2pojo', 'johncarl81/parceler', 'bikeindex/bike_index', 'rebelidealist/stripe-ruby-mock', 'checkstyle/checkstyle', 'airlift/airlift', 'torakiki/pdfsam', 'recruit-tech/redpen', 'brettwooldridge/HikariCP', 'puppetlabs/marionette-collective', 'caelum/vraptor4', 'jpos/jPOS', 'mongodb/morphia', 'square/picasso', 'rpush/rpush', 'relayrides/pushy', 'lemire/RoaringBitmap', 'thoughtbot/hound', 'teamed/qulice', 'jcabi/jcabi-github', 'querydsl/querydsl', 'codevise/pageflow', 'weld/core', 'zendesk/samson', 'github/github-services', 'jsprit/jsprit', 'dblock/waffle', 'numenta/htm.java', 'rightscale/praxis', 'google/error-prone', 'datastax/ruby-driver', 'Netflix/Hystrix', 'jayway/JsonPath', 'spring-cloud/spring-cloud-config', 'MarkUsProject/Markus', 'davidmoten/rxjava-jdbc', 'qos-ch/logback', 'GoogleCloudPlatform/DataflowJavaSDK', 'openstreetmap/openstreetmap-website', 'SonarSource/sonarqube', 'square/keywhiz', 'Shopify/shipit-engine'], ['rails/rails', 'myronmarston/vcr', 'rspec/rspec-core', 'plataformatec/devise', 'karmi/retire', 'dkubb/veritas', 'thoughtbot/factory_girl', 'weppos/whois', 'thoughtbot/paperclip', 'plataformatec/simple_form', 'justinfrench/formtastic', 'rspec/rspec-mocks', 'neo4jrb/neo4j', 'rspec/rspec-expectations', 'maxdemarzi/neography', 'peter-murach/github', 'railsbp/rails_best_practices', 'jruby/jruby', 'sporkmonger/addressable', 'typhoeus/typhoeus', 'troessner/reek', 'puppetlabs/puppetlabs-firewall', 'sferik/twitter', 'vcr/vcr', 'slim-template/slim', 'cloudfoundry/cloud_controller_ng', 'asciidoctor/asciidoctor', 'test-kitchen/test-kitchen', 'JodaOrg/joda-time', 'kostya/eye', 'simpligility/android-maven-plugin', 'jeremyevans/sequel', 'doanduyhai/Achilles', 'square/wire']]

for index in range(len(selected_names)):
    print(index)
    bookname='src_file_simulation_test'+str(index)+'.xls'
    src_file(selected_names[index],bookname)
    print('done')