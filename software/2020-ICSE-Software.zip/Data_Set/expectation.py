import csv
import numpy as np
import xlwt

csv_file=csv.reader(open('csvFile.csv','r'))
pre=[]
final=[]
for item in csv_file:
    pre.append(item)
#print(len(pre))
for i in range(30):
    temp=[]
    for index in range(1,len(pre)):
        try:
            temp.append(pre[index][i])
        except:
            print(index)
            print(i)
    final.append(temp)
print('done')
#print(final[26])

record=[]
for index in range(1,len(final[10])):
    if final[10][index]=='passed' and final[10][index-1]=='failed' and final[3][index]==final[3][index-1] and float(final[13][index])>=0:
    #if final[10][index - 1] == 'failed' and final[3][index] == final[3][index - 1]:
        record.append(index)
#print(record)
#print(len(record))
time =[]
loc=[]
for item in record:
    if abs(float(final[19][item]))<=100:
        time.append(final[13][item])
        loc.append(final[19][item])
print(time)
print(loc)
if(len(time)==len(loc)):
    print("yes")
graph=[]
for index in range(len(loc)):
    tmp=[]
    tmp.append(float(time[index]))
    tmp.append(abs(float(loc[index])))
    graph.append(tmp)
#print(graph)
graph=(sorted(graph))
print(len(graph))
print(graph)
time=[]
loc=[]

# sorted time and loc
for item in graph:
    time.append(item[0])
    loc.append(item[1])
print(time)
print(loc)

book = xlwt.Workbook(encoding='utf-8', style_compression=0)
sheet = book.add_sheet('test', cell_overwrite_ok=True)


for index in range(len(time)):
    if time[index]<=600:
        sheet.write(index,0,'10 min')
        sheet.write(index,1,loc[index])
    elif time[index]<=1800:
        sheet.write(index, 0, '30 min')
        sheet.write(index, 1, loc[index])
    elif time[index]<=3600:
        sheet.write(index, 0, '1 hour')
        sheet.write(index, 1, loc[index])
    elif time[index]<=10800:
        sheet.write(index, 0, '3 hour')
        sheet.write(index, 1, loc[index])
    elif time[index]<=21600:
        sheet.write(index, 0, '6 hour')
        sheet.write(index, 1, loc[index])
    elif time[index]<=43200:
        sheet.write(index, 0, '12 hour')
        sheet.write(index, 1, loc[index])
    elif time[index]<=86400:
        sheet.write(index, 0, '24 hour')
        sheet.write(index, 1, loc[index])
    elif time[index]<=259200:
        sheet.write(index, 0, '3 days')
        sheet.write(index, 1, loc[index])
    elif time[index]<=604800:
        sheet.write(index, 0, '7 days')
        sheet.write(index, 1, loc[index])
    elif time[index]<=2592000:
        sheet.write(index, 0, '1 month')
        sheet.write(index, 1, loc[index])
    else:
        sheet.write(index, 0, 'more than 1 month')
        sheet.write(index, 1, loc[index])
book.save(r'fix_size.xls')
'''

final=[]
# grouping
for i in range(0,len(loc),200):
    b=loc[i:i+200]
    final.append(b)
print(final)
data=[]
for item in final:
    data.append(abs(sum(item)/len(item)))
print(data)

book = xlwt.Workbook(encoding='utf-8', style_compression=0)
sheet = book.add_sheet('test', cell_overwrite_ok=True)


for index in range(len(data)):
    sheet.write(index,0,data[index])
    #sheet.write(index,1,loc[index])
book.save(r'test2.xls')
    #sheet.write(index,2,ranking1[index])
'''