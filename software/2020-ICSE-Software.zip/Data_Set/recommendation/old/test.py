import csv
import numpy as np
import xlwt

csv_file=csv.reader(open('csvFile.csv','r'))
pre=[]
final=[]
for item in csv_file:
    pre.append(item)
#print(len(pre))
for i in range(30):
    temp=[]
    for index in range(1,len(pre)):
        try:
            temp.append(pre[index][i])
        except:
            print(index)
            print(i)
    final.append(temp)
print('done')

def function(feature):
    result = []
    for index in range(len(final[10]) - 1):
        temp = []
        temp.append(float(feature[index]))
        if (final[10][index] == 'passed'):
            temp.append(1)
        else:
            temp.append(0)
        result.append(temp)

    newresult = sorted(result)
    #print(newresult)
    a = []
    b = []
    for item in newresult:
        a.append(item[0])
        b.append(item[1])
    #print(len(a))
    #print(len(b))

    finalresult = []
    # 400 * 112
    for i in range(400):
        tmp1 = []
        tmp2 = []
        unexpected=[]
        for index in range(112):
            try:
                tmp1.append(a[index + i * 112])
                tmp2.append(b[index + i * 112])
            except:
                unexpected.append(i)
        string = str(tmp1[0]) + '~' + str(tmp1[len(tmp1) - 1])
        value = 1 - sum(tmp2) / len(tmp2)
        temp = []
        temp.append(string)
        temp.append(value)
        # print(temp)
        finalresult.append(temp)

    names=[]
    for item in finalresult:
        names.append(item[0])
    newnames=[]
    for id in names:
        if id not in newnames:
            newnames.append(id)

    l1=[]
    for item in newnames:
        tmp3=[]
        for index in range(len(finalresult)):
            if finalresult[index][0]==item:
                tmp3.append(finalresult[index][1])
        l1.append(tmp3)
    finalvalue=[]
    for item in l1:
        finalvalue.append(sum(item)/len(item))
    finalresult=[]
    for index in range(len(finalvalue)):
        temp=[]
        temp.append(newnames[index])
        temp.append(finalvalue[index])
        finalresult.append(temp)

    return finalresult

book = xlwt.Workbook(encoding='utf-8', style_compression=0)
for index in range(len(final)):
    if index != 9 and index != 11 and index>3 and index !=10:
        finalresult=function(final[index])
        print(finalresult)
        sheet = book.add_sheet(str(index), cell_overwrite_ok=True)
        for index1 in range(len(finalresult)):
            sheet.write(index1, 0, finalresult[index1][0])
            sheet.write(index1, 1, finalresult[index1][1])

book.save(r'test.xls')


