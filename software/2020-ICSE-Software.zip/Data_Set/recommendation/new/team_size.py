import csv
import numpy as np
import xlwt

csv_file=csv.reader(open('csvFile.csv','r'))
pre=[]
final=[]
for item in csv_file:
    pre.append(item)
#print(len(pre))
for i in range(30):
    temp=[]
    for index in range(1,len(pre)):
        try:
            temp.append(pre[index][i])
        except:
            print(index)
            print(i)
    final.append(temp)
print('done')

team_size=final[4]
team=[]
team_size=list(set(team_size))
for item in team_size:
    if item != '':
        team.append(int(item))
team=sorted(team)
result=[]
for index in range(len(team)):
    result.append([])
for index in range(len(final[10])):
    for index1 in range(len(team)):
        if final[4][index] == str(team[index1]):
            if final[10][index]=='passed':
                result[index1].append(1)
            else:
                result[index1].append(0)
print(result)
final_result=[]
for item in result:
    final_result.append(1-sum(item)/len(item))

book = xlwt.Workbook(encoding='utf-8', style_compression=0)
sheet = book.add_sheet(str(index), cell_overwrite_ok=True)
for index1 in range(len(team)):
    sheet.write(index1, 0, team[index1])
    sheet.write(index1, 1, final_result[index1])
book.save(r'team_size.xls')