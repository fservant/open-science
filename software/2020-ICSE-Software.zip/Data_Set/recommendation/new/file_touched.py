import csv
import numpy as np
import xlwt

csv_file=csv.reader(open('csvFile.csv','r'))
pre=[]
final=[]
for item in csv_file:
    pre.append(item)
#print(len(pre))
for i in range(30):
    temp=[]
    for index in range(1,len(pre)):
        try:
            temp.append(pre[index][i])
        except:
            print(index)
            print(i)
    final.append(temp)
print('done')


result=[]
for index in range(len(final[10])-1):
    if final[10][index]=='passed':
        result.append(1)
    else:
        result.append(0)

lines=[]
for index in range(len(final[8])-1):
    lines.append(float(final[8][index]))
print(max(lines))
print(len(result))

ratio=[]
for index in range(int(max(lines))+1):
    ratio.append([])
print(len(ratio))

for index in range(len(ratio)):
    for index2 in range(len(lines)):
        if lines[index2]==index:
            ratio[index].append(result[index2])
print(ratio)

for item in ratio:
    print(len(item))

final_result=[]
for item in ratio:
    if len(item) != 0:
        final_result.append(1-sum(item)/len(item))
    else:
        final_result.append(0)

print(ratio[51])

book = xlwt.Workbook(encoding='utf-8', style_compression=0)
sheet = book.add_sheet(str(index), cell_overwrite_ok=True)
for index1 in range(len(final_result)):
    sheet.write(index1, 0, index1)
    sheet.write(index1, 1, final_result[index1])
book.save(r'file_touched.xls')