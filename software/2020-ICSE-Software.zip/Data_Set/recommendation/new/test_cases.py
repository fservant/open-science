import csv
import numpy as np
import xlwt

csv_file=csv.reader(open('csvFile.csv','r'))
pre=[]
final=[]
for item in csv_file:
    pre.append(item)
#print(len(pre))
for i in range(30):
    temp=[]
    for index in range(1,len(pre)):
        try:
            temp.append(pre[index][i])
        except:
            print(index)
            print(i)
    final.append(temp)
print('done')


result=[]
for index in range(len(final[10])-1):
    if final[10][index]=='passed':
        result.append(1)
    else:
        result.append(0)
lines=[]
book = xlwt.Workbook(encoding='utf-8', style_compression=0)
for index in range(len(final)):

    #print(len(lines))
    if index == 24 or index==25 or index==26:
        lines=[[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[]]
        for index1 in range(len(final[index])-1):
            if float(final[index][index1])<=-10:
                lines[0].append(result[index1])
            elif float(final[index][index1])<=-2:
                lines[1].append(result[index1])
            elif float(final[index][index1])<=-1:
                lines[2].append(result[index1])
            elif float(final[index][index1])<=-0.5:
                lines[3].append(result[index1])
            elif float(final[index][index1])<=-0.1:
                lines[4].append(result[index1])
            elif float(final[index][index1])<=-0.05:
                lines[5].append(result[index1])
            elif float(final[index][index1])<=-0.01:
                lines[6].append(result[index1])
            elif float(final[index][index1])<=-0.001:
                lines[7].append(result[index1])
            elif float(final[index][index1])<=-0.0001:
                lines[8].append(result[index1])
            elif float(final[index][index1])<=0:
                lines[9].append(result[index1])
            elif float(final[index][index1])<=0.0001:
                lines[10].append(result[index1])
            elif float(final[index][index1])<=0.01:
                lines[11].append(result[index1])
            elif float(final[index][index1])<=0.05:
                lines[12].append(result[index1])
            elif float(final[index][index1])<=0.1:
                lines[13].append(result[index1])
            elif float(final[index][index1])<=0.5:
                lines[14].append(result[index1])
            elif float(final[index][index1])<=1:
                lines[15].append(result[index1])
            elif float(final[index][index1])<=2:
                lines[16].append(result[index1])
            elif float(final[index][index1])<=10:
                lines[17].append(result[index1])
            elif float(final[index][index1])<=50:
                lines[18].append(result[index1])
            elif float(final[index][index1])<=100:
                lines[19].append(result[index1])
            else:
                lines[20].append(result[index1])
        newresult=[]
        for item in lines:
            print(len(item))
            if len(item) > 0:
                newresult.append(1-sum(item)/len(item))
            else:
                newresult.append(0)
        sheet = book.add_sheet(str(index), cell_overwrite_ok=True)
        for index1 in range(len(newresult)):
            sheet.write(index1, 1, newresult[index1])
book.save(r'test_cases.xls')