import numpy as np
from scipy.stats import pearsonr
import csv
import xlwt
from math import sqrt
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestRegressor
from sklearn.cross_validation import cross_val_score, ShuffleSplit
from sklearn.linear_model import Lasso
from sklearn.linear_model import RandomizedLasso


csv_file=csv.reader(open('rails-dataset1.csv','r'))


pre=[]
final=[]
names=[]
for item in csv_file:
    pre.append(item)
for index in range(11,30):
    names.append(pre[0][index])
#print(names)
for i in range(30):
    temp=[]
    for index in range(1,len(pre)):
        temp.append(pre[index][i])
    final.append(temp)
print(len(final[10]))
# 1850 pieces of data, divided into 50 groups, each group contains 37 pieces
result=[]
for index in range(30):
    if index==2:
        temp=[]
        for index1 in range(len(final[10])):
            smalltemp = []
            smalltemp.append(float(final[index][index1]))
            smalltemp.append(final[10][index1])
            temp.append(smalltemp)
        temp=sorted(temp)
        groupnumber=0
        window = 37
        #print(len(temp))
        number=int(len(temp)) / int(window)
        print(number)
        for loop in range(int(number)):
            tmp = []
            for index2 in range(window):
                tmp.append(temp[index2 + window * loop])
            print(tmp)
            sum1=0
            sum2=0
            a=[]
            for index3 in range(len(tmp)):
                sum1=sum1+tmp[index3][0]
                if tmp[index3][1]=='failed':
                    sum2=sum2+1
            a.append(sum1/len(tmp))
            a.append(sum2/len(tmp))
            result.append(a)
print(result)
book = xlwt.Workbook(encoding='utf-8', style_compression=0)
sheet = book.add_sheet('test', cell_overwrite_ok=True)


for index in range(len(result)):
    sheet.write(index,0,result[index][0])
    sheet.write(index,1,result[index][1])
book.save(r'test1.xls')
#print(sorted(temp))
