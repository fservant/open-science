import csv
import pymysql.cursors
import datetime
import string
import time
import math
import traceback
import xlwt


connect = pymysql.Connect(
    host = 'localhost',
    port=3306,
    user='root',
    password='52135213',
    #db='AspectJFuzzy2'
)
cursor=connect.cursor()

sql = "SELECT * FROM db2.travistorrent_8_2_2017 where (tr_status ='passed' or tr_status ='failed') and git_branch='master' limit 10000;"
cursor.execute(sql)
final=cursor.fetchall()
#print(final[0])

duration=[]
team_size=[]
for item in final:
    duration.append(float(item[43]))
    team_size.append(float(item[14]))
print(duration)
print(sum(duration)/len(duration))
print(sorted(team_size))

result=[]
for index in range(252):
    temp=[]
    tmp=[]
    for index2 in range(len(duration)):
        if team_size[index2] != 0.0:
            if team_size[index2] == index+1:
                tmp.append(duration[index2])

    if len(tmp) != 0:
        temp.append(sum(tmp) / len(tmp))
        temp.append(index+1)

    result.append(temp)
print(result)

size=[]
build_duraion=[]
for item in result:
    if len(item)!=0:
        size.append(item[1])
        build_duraion.append(item[0])

book = xlwt.Workbook(encoding='utf-8', style_compression=0)
sheet = book.add_sheet('test', cell_overwrite_ok=True)


for index in range(len(size)):
    sheet.write(index,0,size[index])
    sheet.write(index,1,build_duraion[index])
book.save(r'test1.xls')