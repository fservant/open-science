import csv
import numpy as np

csv_file=csv.reader(open('csvFile5.csv','r'))
#print(csv_file)
pre=[]
final=[]
for item in csv_file:
    pre.append(item)
for i in range(30):
    temp=[]
    for index in range(1,len(pre)):
        temp.append(pre[index][i])
    #print(i)
    #print(temp)
    final.append(temp)
#print(final[26])
for i in range(4,30):
    if i != 10 and i != 11:
        tmp=[]
        for index in range(len(final[i])-1):
            try:
                tmp.append(float(final[i][index]))
            except:
                print(final[i][index])
        a=max(tmp)
        b=min(tmp)
        #print(a)
        #print(b)
        #print(tmp)
        x1 = b + (a - b)/5
        x2 = b + (a - b) / 5 * 2
        x3 = b + (a - b) / 5 * 3
        x4 = b + (a - b) / 5 * 4

        for index in range(len(tmp)):
            #print(tmp[index])
            if tmp[index] >= b and tmp[index] < x1:
                final[i][index]='very_low'
                #print(1)
            elif tmp[index] >= x1 and tmp[index] < x2:
                final[i][index]='low'
                #print('low')
            elif tmp[index] >= x2 and tmp[index] < x3:
                final[i][index]='medium'
                #print('medium')
            elif tmp[index] >= x3 and tmp[index] < x4:
                final[i][index]='high'
                #print(11)
            elif tmp[index] >= x4 and tmp[index] <= a:
                final[i][index]='very_high'
                #print(22)
            else:
                print('error')

print(len(final[26]))
print(final[29])
rows=[]
for index in range(len(final[1])):
    row=[]
    for index2 in range(len(final)):
        row.append(final[index2][index])
    rows.append(row)

csvFile2 = open('new3.csv','w', newline='') # 设置newline，否则两行之间会空一行
writer = csv.writer(csvFile2)
for item in rows:
    writer.writerow(item)
csvFile2.close()