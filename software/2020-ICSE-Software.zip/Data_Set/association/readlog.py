import fileinput

keywords=['high', 'very_high', 'medium', 'failed']
keywords=['high', 'very_high', 'failed']
count=0
path=1
for line in fileinput.input("C:/Users/15847/OneDrive/Documents/research/Intergration/log.txt"):
    words=line.split()
    #count=0
    record=[]
    arrow=0
    if path==0:
        for index in range(len(words)):
            if words[index] == '==>':
                arrow = index
        for index in range(len(words)):
            for keyword in keywords:
                if index > arrow and keyword in words[index]:
                    record.append(words[index])
    if path==1:
        for index in range(len(words)):
            if words[index] == '==>':
                arrow = index
        for index in range(len(words)):
            for keyword in keywords:
                if keyword in words[index]:
                    record.append(words[index])
    record=list(set(record))
    if len(record)>=1 and int(words[arrow-1])>=100:
        #print(li)
        #print(words[arrow-1])
        print(words)
        print(record)
        print('\n')
        count=count+1
print(count)