import csv
import numpy as np

csv_file=csv.reader(open('C:/Users/15847/OneDrive/Documents/research/src/python/CI/data_set/weka/new1.csv','r'))
#print(csv_file)
pre=[]
final=[]
for item in csv_file:
    pre.append(item)
print(len(pre))
for i in range(30):
    temp=[]
    for index in range(1,len(pre)):
        try:
            temp.append(pre[index][i])
        except:
            print(index)
            print(i)
    #print(i)
    #print(temp)
    final.append(temp)
print('done')
print(final[6][0])
record=[]
for i in range(4,30):
    if i != 10 and i != 11:
        tmp=[]
        for index in range(len(final[i])-1):
            try:
                tmp.append(float(final[i][index]))
            except:
                print(i)
                print(index)
                print(final[i][index])
        #print(final[4])
        mean=sum(tmp)/len(tmp)
        temp=np.array(tmp)
        st=np.std(temp)
        #print(mean)
        for index in range(len(tmp)):
            #print(index)
            #print(tmp[index])
            if tmp[index]< (mean-3*st) or tmp[index]> (mean+3*st):
                record.append(index)
print(record)
print(len(record))
new=list(set(record))
newfinal=sorted(new,reverse=True)
#for i in range(30):
    #for item in record:
        #del final[i][item]

'''
    tmp=[]
    for index in range(len(final[i]) - 1):
        for item in record:
            if index != item:
                tmp.append(final[i][index])
    newfinal.append(tmp)
    '''
print(newfinal)
print(len(newfinal))
with open('C:/Users/15847/OneDrive/Documents/research/src/python/CI/data_set/weka/new1.csv','r') as csvfile:
    reader = csv.reader(csvfile)
    rows= [row for row in reader]
print(len(rows))

for item in newfinal:
    #print(item)
    del rows[item+1]
print(len(rows))

csvFile2 = open('csvFile.csv','w', newline='') # 设置newline，否则两行之间会空一行
writer = csv.writer(csvFile2)
for item in rows:
    writer.writerow(item)
csvFile2.close()