import csv
import numpy as np
import xlwt

csv_file=csv.reader(open('csvFile.csv','r'))
pre=[]
final=[]
for item in csv_file:
    pre.append(item)
#print(len(pre))
for i in range(30):
    temp=[]
    for index in range(1,len(pre)):
        try:
            temp.append(pre[index][i])
        except:
            print(index)
            print(i)
    final.append(temp)
print('done')
temp=[]
for index in range(len(final[26])):
    tmp=[]
    tmp.append(final[14][index])
    tmp.append(final[26][index])
    temp.append(tmp)
print(temp)
temp=sorted(temp)
time=[]
tc_change=[]
for item in temp:
    try:
        if abs(float(item[1]))<=1:
            time.append(float(item[0]))
            tc_change.append(abs(float(item[1])*1000))
    except:
        print(item)
print(len(time))
print(tc_change)

book = xlwt.Workbook(encoding='utf-8', style_compression=0)
sheet = book.add_sheet('test', cell_overwrite_ok=True)


for index in range(len(time)):
    if time[index]<=600:
        sheet.write(index,0,'10 min')
        sheet.write(index,1,tc_change[index])
    elif time[index]<=1800:
        sheet.write(index, 0, '30 min')
        sheet.write(index, 1, tc_change[index])
    elif time[index]<=3600:
        sheet.write(index, 0, '1 hour')
        sheet.write(index, 1, tc_change[index])
    elif time[index]<=10800:
        sheet.write(index, 0, '3 hour')
        sheet.write(index, 1, tc_change[index])
    elif time[index]<=21600:
        sheet.write(index, 0, '6 hour')
        sheet.write(index, 1, tc_change[index])
    elif time[index]<=43200:
        sheet.write(index, 0, '12 hour')
        sheet.write(index, 1, tc_change[index])
    elif time[index]<=86400:
        sheet.write(index, 0, '24 hour')
        sheet.write(index, 1, tc_change[index])
    elif time[index]<=259200:
        sheet.write(index, 0, '3 days')
        sheet.write(index, 1, tc_change[index])
    elif time[index]<=604800:
        sheet.write(index, 0, '7 days')
        sheet.write(index, 1, tc_change[index])
    elif time[index]<=2592000:
        sheet.write(index, 0, '1 month')
        sheet.write(index, 1, tc_change[index])
    else:
        sheet.write(index, 0, 'more than 1 month')
        sheet.write(index, 1, tc_change[index])
book.save(r'test_case.xls')