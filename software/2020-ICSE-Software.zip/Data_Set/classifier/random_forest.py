from openpyxl import load_workbook
import os
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
import numpy as np
import csv
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve
from sklearn.metrics import roc_auc_score
from sklearn.metrics import roc_curve, auc

# test data with train data: accuracy 77.9%, precision：78.7%, recall: 90.8%, fmeasure: 83.6%
# test data without tain data: 78.2%, precision：80.2%, recall: 90.8%, fmeasure: 85%
# test( M AC AA U P)
# ranking( 30, 22, 2, 7, 6)
#[[0.613429179551022, 0.8254079757916352, 0.7048915551453623, 0.7604042214257268, 19], [0.625843434645011, 0.8366282627783839, 0.7129770299993198, 0.7698692522403409, 3], [0.6276106685689375, 0.8059287531806616, 0.7393496580218959, 0.771204908752237, 4], [0.6475775289804815, 0.7419515960586659, 0.835827003248165, 0.7860965782668832, 15], [0.6558697208303508, 0.8357826990320782, 0.7528931090365434, 0.7921755106451962, 29], [0.6567408442271231, 0.7223039269486577, 0.8785710471511721, 0.7928105913674092, 11], [0.6595917044718081, 0.7941477688368691, 0.7956222211364635, 0.7948843112369423, 23], [0.6626381843535902, 0.8025259447816722, 0.7917320648105667, 0.7970924649625011, 20], [0.6648562933597622, 0.8208001957665484, 0.7777494377072368, 0.7986951138203638, 16], [0.672502676765674, 0.7864993970874687, 0.8226890144808015, 0.8041872651183745, 5], [0.6799195171026157, 0.7471312653386102, 0.88315082455636, 0.8094667752599052, 10], [0.6819253243537684, 0.7817211625794732, 0.8423125856331963, 0.8108865649142641, 26], [0.6819689186553092, 0.8627838104639685, 0.7649332652614689, 0.8109173850852437, 9], [0.6829050097592713, 0.8060281730700007, 0.817206394005012, 0.8115787947615135, 18], [0.6853413815158299, 0.7246961851421325, 0.9265794735988758, 0.8132968062522977, 1], [0.6865811200636626, 0.7554120608514829, 0.8828374817732982, 0.8141691044635274, 25], [0.6936370310112895, 0.7864309173527692, 0.8546214584300975, 0.8191094293646982, 27], [0.6943540172954404, 0.758790021606757, 0.891027448166278, 0.8196091374148377, 24], [0.6973885717695261, 0.7176422431436759, 0.9611051722720171, 0.8217194145975651, 12], [0.6977342117949542, 0.702631632178328, 0.9901091696833224, 0.8219592995740653, 13], [0.6989180321059955, 0.7147407989466307, 0.9692981192937992, 0.8227801681987091, 6], [0.7019333293097552, 0.7204865054618291, 0.9646125349036521, 0.8248658360717748, 14], [0.7040729193557996, 0.7366660433418522, 0.9408751957115941, 0.8263413042464923, 0], [0.705618835251813, 0.7204093771150809, 0.9717265609870805, 0.8274050692546876, 17], [0.7059698532328441, 0.7593924007424316, 0.9093812273261458, 0.8276463407545196, 21], [0.7068197844263121, 0.7784286316536866, 0.8848394663169311, 0.8282301281899951, 22], [0.7090743454667882, 0.751742672377593, 0.9258856995086631, 0.8297758928364505, 31], [0.7094964314036479, 0.7377241805813234, 0.9488294403054326, 0.8300648288819047, 7], [0.7155426963397475, 0.7657900318133616, 0.9160028413415191, 0.8341881526661122, 28], [0.7186991539212496, 0.740584721785602, 0.9605055721663496, 0.8363292112892728, 2], [0.7198300450459311, 0.7589911643920852, 0.9331157406226891, 0.8370943944367558, 8], [0.7394065209427281, 0.7626424837836135, 0.9604250931874059, 0.8501825329963494, 30]]
def draw_ROC_curve(y_test, y_predict, savepath):
    '''''
    画ROC曲线
    '''
    false_positive_rate, true_positive_rate, thresholds = roc_curve(y_test, y_predict)
    roc_auc = auc(false_positive_rate, true_positive_rate)
    plt.title('ROC')
    plt.plot(false_positive_rate, true_positive_rate, 'b', label='AUC = %0.2f' % roc_auc)
    plt.legend(loc='lower right')
    plt.plot([0, 1], [0, 1], 'r--')
    plt.ylabel('TPR')
    plt.xlabel('FPR')
    plt.savefig(savepath)
    plt.close(0)

def comparison(array_test, reallife):
    TP=0
    FP=0
    FN=0
    test_result = []
    for index in range(len(array_test)):
        test = np.array(array_test[index])
        test = test.reshape(1, 5)
        x = rf.predict(test)[0]
        # print(x)
        if (x >= 0.5 and reallife[index] == 1) or (x<0.5 and reallife[index] == 0):
            test_result.append(1)
            TP=TP+1
        else:
            test_result.append(0)
        if (x>=0.5 and reallife[index] == 0):
            FP=FP+1
        if (x<0.5 and reallife[index] == 1):
            FN=FN+1

    #result=(sum(test_result) / len(test_result))
    return test_result,TP,FP,FN

def readfile(filepath):
    wb = load_workbook(filepath)
    sheet = wb.active
    final = []
    for row in sheet.rows:
        tmp = []
        for cell in row:
            # tmp.append(cell.value)
            final.append(cell.value)
    #print(len(final))
    x=int(len(final)/5)
    final = np.array(final)
    final = final.reshape((x, 5))
    return final

def readstatus(filepath):
    csv_file = csv.reader(open(filepath, 'r'))
    pre = []
    target = []
    status = []
    for item in csv_file:
        pre.append(item)
    for i in range(30):
        temp = []
        for index in range(1, len(pre)):
            temp.append(pre[index][i])
        target.append(temp)
    # print(target[10])
    for item in target[10]:
        if item == 'passed':
            status.append(1)
        else:
            status.append(0)
    #print(len(status))
    return status

def getdata(filepath):
    csv_file = csv.reader(open(filepath, 'r'))
    pre = []
    target = []
    final = []
    for item in csv_file:
        pre.append(item)
    for i in range(30):
        temp = []
        for index in range(1, len(pre)):
            temp.append(pre[index][i])
        target.append(temp)
    M = target[12]
    AC = target[28]
    AA = target[26]
    U = target[20]
    P = target[15]
    for index in range(len(M)):
        final.append(float(M[index]))
        final.append(float(AC[index]))
        final.append(float(AA[index]))
        final.append(float(U[index]))
        final.append(float(P[index]))
    x = int(len(final) / 5)
    final = np.array(final)
    final = final.reshape((x, 5))
    return final

def ranking():
    path = 'C:/Users/15847/OneDrive/Documents/research/src/python/CI/data_set/origin'
    filename = []
    for item in os.listdir(path):
        if os.path.splitext(item)[1] == '.csv':
            filename.append(item)
    record = []
    for index1 in range(len(filename)):
        TP = 0
        FP = 0
        FN = 0
        print(filename[index1])
        temp = []
        filepath = path + '/' + filename[index1]
        final = getdata(filepath)
        status = readstatus(filepath)
        #print(final)
        #print(status)
          # 这里使用了默认的参数设置
        rf.fit(final, status)
        tmp = []
        for index2 in range(len(filename)):
            if index2 != index1:
                newfilepath = path + '/' + filename[index2]
                newfinal = getdata(newfilepath)
                newstatus = readstatus(newfilepath)
                newresult,x,y,z = comparison(newfinal, newstatus)
                # print(newresult)
                #tmp.append(newresult)
                TP=TP+ x
                FP=FP+y
                FN=FN+z
                for item in newresult:
                    tmp.append(item)
        temp.append(sum(tmp) / len(tmp))
        temp.append(TP/(TP+FP))
        temp.append(TP/(TP+FN))
        temp.append(2*TP/(2*TP+FP+FN))
        temp.append(index1)
        record.append(temp)
        print(temp)
    record = sorted(record)
    print(record)
#rf = RandomForestRegressor()
#ranking()


path = 'C:/Users/15847/OneDrive/Documents/research/src/python/CI/data_set/origin'
filename = []
y_list=[]
y_predict=[]
y_predict1=[]
for item in os.listdir(path):
    if os.path.splitext(item)[1] == '.csv':
        filename.append(item)
chairs = []
for index1 in [30,31,2,7,22,28,8]:
    filepath = path + '/' + filename[index1]
    final = getdata(filepath)
    status = readstatus(filepath)
    rf = RandomForestRegressor()  # 这里使用了默认的参数设置
    predictor = rf.fit(final, status)
    chairs.append(predictor)
#print(chairs)
record=[]
precision=[]
recall=[]
fmeasure=[]
path = 'C:/Users/15847/OneDrive/Documents/research/src/python/CI/data_set/origin'
filename = []
for item in os.listdir(path):
    if os.path.splitext(item)[1] == '.csv':
        filename.append(item)
test_result = []
TP=0
TPFP=0
TPFN=0
for index1 in range(len(filename)):
    if index1 !=30 and index1 != 22 and index1 !=2 and index1 !=7 and index1 !=3 and index1!=19 and index1 != 29:
        print(filename[index1])
        TP2 = 0
        TPFP2= 0
        TPFN2 = 0
        temp = []
        passed = 0
        filepath = path + '/' + filename[index1]
        array_test = getdata(filepath)
        reallife = readstatus(filepath)
        for item in reallife:
            y_list.append(item)
        #record.append(len(array_test))
        for index in range(len(array_test)):
            x0=[]
            vote=0
            test = np.array(array_test[index])
            test = test.reshape(1, 5)
            x1 = chairs[0].predict(test)[0]
            x2 = chairs[1].predict(test)[0]
            x3 = chairs[2].predict(test)[0]
            x4 = chairs[3].predict(test)[0]
            x5 = chairs[4].predict(test)[0]
            x6 = chairs[5].predict(test)[0]
            x7 = chairs[6].predict(test)[0]
            x=x1+x2+x3+x4+x5+x6+x7
            y_predict.append(x/7)
            if x>=3.5:
                y_predict1.append(1)
            else:
                y_predict1.append(0)
            #print(x)
            if (x >= 3.5 and reallife[index] == 1) or (x < 3.5 and reallife[index] == 0):
                test_result.append(1)
                temp.append(1)
            else:
                test_result.append(0)
                temp.append(0)
            if (x >= 3.5 and reallife[index] == 1):
                TP=TP+1
                TP2 = TP2 + 1
            if x>=3.5:
                TPFP=TPFP+1
                TPFP2 = TPFP2 + 1
            if reallife[index] == 1:
                TPFN=TPFN+1
                TPFN2 = TPFN2 + 1

        print('precision')
        print(TP2 / TPFP2)
        print('recall')
        print(TP2 / TPFN2)
        print('accuracy')
        print(sum(temp) / len(temp))
print('done')
print('precision')
print(TP/TPFP)
print('recall')
print(TP/TPFN)
print('accuracy')
print(sum(test_result)/len(test_result))
print('f-measure')
print(2*TP/(TPFN+TPFP))
#print(TPFN/sum(record))
print('')
print('')
print('tp')
print(TP)
print('FP')
print(TPFP-TP)
print('fn')
print(TPFN-TP)
print('tn')
print(len(test_result)-TPFN-TPFP+TP)

print(y_list)
print(y_predict)
draw_ROC_curve(y_list, y_predict, savepath='RFR.pdf')
draw_ROC_curve(y_list, y_predict1, savepath='RFR1.pdf')

'''

final=readfile('selected.xlsx')
status=readstatus('rails-dataset1.csv')

#随机森林
rf=RandomForestRegressor()#这里使用了默认的参数设置
rf.fit(final,status)
comparison(final, status)

# test( M AC AA U P)

status=readstatus('flink-dataset1.csv')
final_test=readfile('test_flink.xlsx')
comparison(final_test, status)

'''


