import numpy as np
from scipy.stats import pearsonr
import csv
import xlwt
from math import sqrt
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestRegressor
from sklearn.cross_validation import cross_val_score, ShuffleSplit
from sklearn.linear_model import Lasso
from sklearn.linear_model import RandomizedLasso



def multipl(a, b):
    sumofab = 0.0
    for i in range(len(a)):
        temp = a[i] * b[i]
        sumofab += temp
    return sumofab


def corrcoef(x, y):
    n = len(x)
    # 求和
    sum1 = sum(x)
    sum2 = sum(y)
    # 求乘积之和
    sumofxy = multipl(x, y)
    # 求平方和
    sumofx2 = sum([pow(i, 2) for i in x])
    sumofy2 = sum([pow(j, 2) for j in y])
    num = sumofxy - (float(sum1) * float(sum2) / n)
    # 计算皮尔逊相关系数
    den = sqrt((sumofx2 - float(sum1 ** 2) / n) * (sumofy2 - float(sum2 ** 2) / n))
    return num / den

csv_file=csv.reader(open('C:/Users/15847/OneDrive/Documents/research/src/python/CI/data_set/origin/fog-dataset1.csv','r'))
print(csv_file)
pre=[]
final=[]
names=[]
for item in csv_file:
    pre.append(item)
for index in range(11,30):
    names.append(pre[0][index])
#print(names)
for i in range(30):
    temp=[]
    for index in range(1,len(pre)):
        temp.append(pre[index][i])
    #print(i)
    #print(temp)
    final.append(temp)
print(final[11])
target=[]
for item in final[10]:
    if item=='failed':
        target.append(0)
    else:
        target.append(1)
print(target)
result=[]
result2=[]
final2=[]
for index in range(11,30):
    temp=[]
    #print(final[index])
    for item in final[index]:
        temp.append(float(item))
    #print(index)
    #print(pearsonr(x,temp))
    final2.append(temp)
    #plt.scatter(temp, x)
    #plt.show()

    result.append(pearsonr(target,temp))
    result2.append(corrcoef(target,temp))
print((result))
#print(result2)
#plt.show()

book = xlwt.Workbook(encoding='utf-8', style_compression=0)
sheet = book.add_sheet('test', cell_overwrite_ok=True)
for index in range(11,30):
    sheet.write(index-11,0,index)
    sheet.write(index-11,1,result[index-11][0])
    sheet.write(index - 11, 2, result[index - 11][1])
book.save(r'test1.xls')

result3=[]
for index in range(4,9):
    temp=[]
    #print(final[index])
    for item in final[index]:
        temp.append(float(item))
    #print(index)
    #print(pearsonr(x,temp))
    result3.append(pearsonr(target,temp))
    #result2.append(corrcoef(x,temp))
#print((final2))


# 4, 11, 12, 13

X = np.array(final2)
X=X.T
#print(X)
#print(final2)
Y = np.array(target)
rf = RandomForestRegressor(n_estimators=20, max_depth=4)
scores = []
print(X.shape)
print(Y.shape)
for i in range(X.shape[1]):
    score = cross_val_score(rf, X[:, i:i + 1], Y, scoring="r2",
                            cv=ShuffleSplit(len(X), 3, .3))
    scores.append((round(np.mean(score), 3), names[i]))
print(sorted(scores, reverse=True))
#time_since_passed, nsrcf_change_since_passed, ac_pkloc_change_since_passed, tc_pkloc_change_since_failure, time_since_failed, tl_pkloc_change_since_failure

X = np.array(final2)
X=X.T
#print(X)
#print(final2)
Y = np.array(target)
def pretty_print_linear(coefs, names = None, sort = False):
    # if names  == None:
    names = ["X%s" % x for x in range(len(coefs))]
    lst = zip(coefs, names)
    if sort:
        lst = sorted(lst,  key = lambda x:-np.abs(x[0]))
    return " + ".join("%s * %s" % (round(coef, 3), name)
                                   for coef, name in lst)
lasso = Lasso(alpha=.3)
lasso.fit(X, Y)
print("Lasso model: ", pretty_print_linear(lasso.coef_, names, sort = True))


X = np.array(final2)
X=X.T
#print(X)
#print(final2)
Y = np.array(target)
rlasso = RandomizedLasso(alpha=0.025)
rlasso.fit(X, Y)

print("Features sorted by their score:")
print(sorted(zip(map(lambda x: round(x, 4), rlasso.scores_),
                 names), reverse=True))
