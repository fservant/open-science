from openpyxl import load_workbook
import os
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import RandomForestClassifier
import numpy as np
import csv


# test data with train data: accuracy 77.9%, precision：78.7%, recall: 90.8%, fmeasure: 83.6%
# test data without tain data: 78.2%, precision：80.2%, recall: 90.8%, fmeasure: 85%
# test( M AC AA U P)
# ranking( 30, 22, 2, 7, 6)
# [[0.6194658797338737, 3], [0.627981445470358, 19], [0.6362745794440685, 4], [0.644821085186572, 16], [0.6466768043975831, 26], [0.6587006910638125, 11], [0.6611615377402368, 5], [0.6620544222912996, 29], [0.6635214234357718, 23], [0.6767883025473326, 15], [0.6775637180835505, 9], [0.687017748419463, 20], [0.6899165729994018, 1], [0.6920353464477235, 10], [0.6940379283421416, 25], [0.6972293881068847, 18], [0.7023009703834998, 27], [0.7059845800745274, 28], [0.7064256136518603, 12], [0.7065507055441305, 13], [0.7120205303909285, 21], [0.7123964112214757, 24], [0.7126794509142139, 17], [0.712880080139855, 0], [0.7137389421048008, 31], [0.7150165303078403, 14], [0.7152097716747091, 8], [0.7175264068750253, 6], [0.7178630120177559, 7], [0.722355634615967, 2], [0.723048798537687, 22], [0.7355279414938569, 30]]
def comparison(array_test, reallife):
    test_result = []
    for index in range(len(array_test)):
        test = np.array(array_test[index])
        test = test.reshape(1, 5)
        x = rf.predict(test)[0]
        # print(x)
        if (x >= 0.5 and reallife[index] == 1) or (x<0.5 and reallife[index] == 0):
            test_result.append(1)
        else:
            test_result.append(0)
    result=(sum(test_result) / len(test_result))
    return result

def readfile(filepath):
    wb = load_workbook(filepath)
    sheet = wb.active
    final = []
    for row in sheet.rows:
        tmp = []
        for cell in row:
            # tmp.append(cell.value)
            final.append(cell.value)
    #print(len(final))
    x=int(len(final)/5)
    final = np.array(final)
    final = final.reshape((x, 5))
    return final

def readstatus(filepath):
    csv_file = csv.reader(open(filepath, 'r'))
    pre = []
    target = []
    status = []
    for item in csv_file:
        pre.append(item)
    for i in range(30):
        temp = []
        for index in range(1, len(pre)):
            temp.append(pre[index][i])
        target.append(temp)
    # print(target[10])
    for item in target[10]:
        if item == 'passed':
            status.append(1)
        else:
            status.append(0)
    #print(len(status))
    return status

def getdata(filepath):
    csv_file = csv.reader(open(filepath, 'r'))
    pre = []
    target = []
    final = []
    for item in csv_file:
        pre.append(item)
    for i in range(30):
        temp = []
        for index in range(1, len(pre)):
            temp.append(pre[index][i])
        target.append(temp)
    M = target[12]
    AC = target[28]
    AA = target[26]
    U = target[20]
    P = target[15]
    for index in range(len(M)):
        final.append(float(M[index]))
        final.append(float(AC[index]))
        final.append(float(AA[index]))
        final.append(float(U[index]))
        final.append(float(P[index]))
    x = int(len(final) / 5)
    final = np.array(final)
    final = final.reshape((x, 5))
    return final

def ranking():
    path = 'origin'
    filename = []
    for item in os.listdir(path):
        if os.path.splitext(item)[1] == '.csv':
            filename.append(item)
    record = []
    for index1 in range(len(filename)):
        temp = []
        filepath = path + '/' + filename[index1]
        final = getdata(filepath)
        status = readstatus(filepath)
        rf = RandomForestRegressor()  # 这里使用了默认的参数设置
        rf.fit(final, status)
        tmp = []
        for index2 in range(len(filename)):
            if index2 != index1:
                newfilepath = path + '/' + filename[index2]
                newfinal = getdata(newfilepath)
                newstatus = readstatus(newfilepath)
                newresult = comparison(newfinal, newstatus)
                # print(newresult)
                tmp.append(newresult)
        temp.append(sum(tmp) / len(tmp))
        temp.append(index1)
        record.append(temp)
    record = sorted(record)
    print(record)

path = 'origin'
filename = []
for item in os.listdir(path):
    if os.path.splitext(item)[1] == '.csv':
        filename.append(item)
chairs = []
for index1 in [30,22,2,7,3,19,29]:
    filepath = path + '/' + filename[index1]
    final = getdata(filepath)
    status = readstatus(filepath)
    rf = RandomForestClassifier(class_weight={0: 1, 1: 1})  # 这里使用了默认的参数设置
    predictor = rf.fit(final, status)
    chairs.append(predictor)
#print(chairs)
record=[]
precision=[]
recall=[]
fmeasure=[]
path = 'origin'
filename = []
for item in os.listdir(path):
    if os.path.splitext(item)[1] == '.csv':
        filename.append(item)
test_result = []
TP=0
TPFP=0
TPFN=0
for index1 in range(len(filename)):
    if index1 !=30 and index1 != 22 and index1 !=2 and index1 !=7 and index1 !=3 and index1!=19 and index1 != 29:
        print(filename[index1])
        TP2 = 0
        TPFP2= 0
        TPFN2 = 0
        temp = []
        passed = 0
        filepath = path + '/' + filename[index1]
        array_test = getdata(filepath)
        reallife = readstatus(filepath)
        #record.append(len(array_test))
        for index in range(len(array_test)):
            x0=[]
            vote=0
            test = np.array(array_test[index])
            test = test.reshape(1, 5)
            x1 = chairs[0].predict(test)[0]
            x2 = chairs[1].predict(test)[0]
            x3 = chairs[2].predict(test)[0]
            x4 = chairs[3].predict(test)[0]
            x5 = chairs[4].predict(test)[0]
            x6 = chairs[5].predict(test)[0]
            x7 = chairs[6].predict(test)[0]
            x=x1+x2+x3+x4+x5+x6+x7
            #print(x)
            if (x >= 5 and reallife[index] == 1) or (x < 5 and reallife[index] == 0):
                test_result.append(1)
                temp.append(1)
            else:
                test_result.append(0)
                temp.append(0)
            if (x < 5 and reallife[index] == 0):
                TP=TP+1
                TP2 = TP2 + 1
            if x<5:
                TPFP=TPFP+1
                TPFP2 = TPFP2 + 1
            if reallife[index] == 0:
                TPFN=TPFN+1
                TPFN2 = TPFN2 + 1

        '''
            if (vote >= 3 and reallife[index] == 1) or (vote < 3 and reallife[index] == 0):
                test_result.append(1)
            else:
                test_result.append(0)
            '''
        print('precision')
        print(TP2 / TPFP2)
        print('recall')
        print(TP2 / TPFN2)
        print('accuracy')
        print(sum(temp) / len(temp))
print('precision')
print(TP/TPFP)
print('recall')
print(TP/TPFN)
print('accuracy')
print(sum(test_result)/len(test_result))
#print(TPFN/sum(record))





'''

final=readfile('selected.xlsx')
status=readstatus('rails-dataset1.csv')

#随机森林
rf=RandomForestRegressor()#这里使用了默认的参数设置
rf.fit(final,status)
comparison(final, status)

# test( M AC AA U P)

status=readstatus('flink-dataset1.csv')
final_test=readfile('test_flink.xlsx')
comparison(final_test, status)

'''


