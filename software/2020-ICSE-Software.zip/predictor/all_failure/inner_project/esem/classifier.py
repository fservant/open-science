import csv
import numpy as np
import xlwt
from sklearn.model_selection import KFold
from sklearn.ensemble import RandomForestClassifier

def get_median(data):
    data = sorted(data)
    size = len(data)
    if size % 2 == 0:  # 判断列表长度为偶数
        median = (data[size // 2] + data[size // 2 - 1]) / 2
        data[0] = median
    if size % 2 == 1:  # 判断列表长度为奇数
        median = data[(size - 1) // 2]
        data[0] = median
    return data[0]

precision=[]
recall=[]
f_score=[]
build_save=[]
project_names=['jackson-core.csv', 'go-lang-idea-plugin.csv', 'jphp.csv', 'rultor.csv', 'AsciidocFX.csv', 'vraptor4.csv', 'geoserver.csv', 'core.csv', 'jodd.csv', 'airlift.csv', 'redpen.csv', 'querydsl.csv', 'pdfsam.csv', 'jOOQ.csv', 'gradle.csv', 'checkstyle.csv', 'deeplearning4j.csv', 'lenskit.csv', 'zxing.csv', 'jcabi-github.csv', 'tajo.csv', 'JRAW.csv', 'flink.csv', 'mockito.csv', 'p6spy.csv', 'jackson-databind.csv', 'javaslang.csv', 'jedis.csv', 'intellij-haskforce.csv', 'blueflood.csv', 'morphia.csv', 'closure-compiler.csv', 'graylog2-server.csv', 'Achilles.csv', 'RoaringBitmap.csv', 'quickml.csv', 'HikariCP.csv']
for nameindex in range(len(project_names)):
    file_name = project_names[nameindex]
    #file_name = file_name.split("/")[1]
    print(file_name)

    string="/Users/jinxianhao/Documents/src/python/CI/Data_Base/esem_dataset/" + file_name
    csv_file = csv.reader(open(string, 'r'))
    pre = []
    final = []
    for item in csv_file:
        pre.append(item)

    for i in range(len(pre[0])):
        temp = []
        for index in range(1, len(pre)):
            # print(index)
            # print(pre[index][i])
            temp.append(pre[index][i])
        final.append(temp)
    #print(len(final[42]))

    indices = []
    for index in range(1,len(final[42])):
        if final[42][index] == 'passed':
            indices.append(index)
        else:
            indices.append(index)
    src_churn=[]
    file_churn=[]
    test_churn=[]
    last_status=[]
    last_type=[]
    team_size=[]
    build_result=[]
    argument=[]
    for index in indices:
        src_churn.append(float(final[14][index]))
        file_churn.append(float(final[21][index]))
        test_churn.append(float(final[15][index]))
        team_size.append(float(final[8][index]))

        argument.append([])
        if final[58][index-1]=='':
            last_type.append(-1)
        else:
            project_type=(final[58][index-1][0:3])
            if project_type=='mvn':
                last_type.append(float(final[58][index-1][5:]))
            elif project_type=='ant':
                last_type.append(float(final[58][index-1][5:])+1000)
            else:
                last_type.append(float(final[58][index - 1][8:]) + 2000)
    #print(last_type)



    for item in indices:
        if final[33][item] == 'passed':
            build_result.append(1)
        else:
            build_result.append(0)

    if final[33][indices[0]-1]=='passed':
        last_status.append(1)
    else:
        last_status.append(0)


    for index in range(1,len(build_result)):
        last_status.append(build_result[index-1])
    #print(last_status)

    for index in range(len(src_churn)):
        argument[index].append(src_churn[index])
        #argument[index].append(file_churn[index])
        #argument[index].append(test_churn[index])
        argument[index].append(team_size[index])
        argument[index].append(last_status[index])
        argument[index].append(last_type[index])

    X = np.array(argument)
    Y = np.array(build_result)
    KF = KFold(n_splits=8)  # 建立4折交叉验证方法  查一下KFold函数的参数
    more=0
    less=0
    yes=0
    num_test=0
    for train_index, test_index in KF.split(X):
        #print("TRAIN:", train_index, "TEST:", test_index)
        X_train, X_test = X[train_index], X[test_index]
        Y_train, Y_test = Y[train_index], Y[test_index]
        #print(X_train, X_test)
        #print(Y_train, Y_test)
        X_train = X_train.reshape((int(len(X_train)), 4))
        rf = RandomForestClassifier()  # 这里使用了默认的参数设置
        predictor = rf.fit(X_train, Y_train)




        X_test = X_test.reshape((int(len(X_test)), 4))

        Y_result=(predictor.predict(X_test))

        for index in range(len(Y_result)):
            if Y_result[index]==0 and Y_test[index]==0:
                yes=yes+1
            if Y_result[index] == 0:
                more=more+1
            if Y_test[index] == 0:
                less=less+1
    #print(less)
    if less != 0:
        recall0 = yes/less
        if more == 0:
            precision0=1

        else:
            precision0 = yes / more

        precision.append(precision0)
        recall.append(recall0)
    else:
        print(project_names[nameindex])

print(get_median(precision))
print(get_median(recall))
print(len(precision))
print(len(recall))

book = xlwt.Workbook(encoding='utf-8', style_compression=0)
sheet1 = book.add_sheet('precision', cell_overwrite_ok=True)
sheet2 = book.add_sheet('recall', cell_overwrite_ok=True)
sheet3 = book.add_sheet('f-score', cell_overwrite_ok=True)


for index in range(len(precision)):
    sheet1.write(index,0,precision[index])
    sheet1.write(index,1,recall[index])
    if precision[index]==0 and recall[index]==0:
        sheet1.write(index,2,0)
    else:
        sheet1.write(index,2,2*precision[index]*recall[index]/(precision[index]+recall[index]))


#book.save(r'performance1.xls')
f_score=[]
print(precision)
print(recall)
for index in range(len(precision)):
    if precision[index] == 0 and recall[index] == 0:
        f_score.append(0)
    else:
        f_score.append(2*precision[index]*recall[index]/(precision[index]+recall[index]))

print(f_score)
print(len(precision))
print(len(recall))
print(len(f_score))

