import csv
import numpy as np
import xlwt
import sys
sys.path.insert(0, '/Users/jinxianhao/Desktop/folder/')
import functions
from sklearn.model_selection import KFold
from sklearn.ensemble import RandomForestClassifier

all_project_age=[17.93727662037037, 19.121140046296297, 20.609096450617283, 15.588740354938272, 12.814837962962963, 21.87333603395062, 22.594797453703702, 14.85992476851852, 21.29057137345679, 22.565575231481482, 22.468806712962962, 15.53714313271605, 22.33132638888889, 16.904368827160493, 17.330614197530863, 22.799449459876545, 17.303841049382715, 22.834096450617285, 18.50705825617284, 16.146770447530866, 15.330529706790124, 13.623905478395061, 13.689577160493828, 20.818514274691356, 21.233930169753087, 17.66437847222222, 15.69138348765432, 17.97262885802469, 14.543631172839506, 23.393461419753088, 19.223894675925926, 13.203061728395062, 39.94107214506173, 23.42955015432099, 17.37164313271605, 23.447115740740742, 21.766220679012346]
all_project_size=[16066.5, 35096.0, 54018.5, 4840.0, 3878.0, 11213.5, 292590.0, 52340.0, 77649.0, 23805.0, 4763.0, 46486.0, 8645.0, 94244.0, 167751.0, 28987.5, 33606.5, 26557.0, 34565.0, 15028.0, 140237.5, 4870.0, 127280.0, 33382.0, 4120.0, 47874.0, 4111.0, 12379.0, 24544.0, 15093.0, 11325.0, 126109.0, 50613.5, 17352.0, 6497.0, 5017.0, 2294.0]
all_team_size=[3.0, 8.0, 5.0, 6.0, 4.0, 23.0, 42.0, 9.0, 3.0, 9.0, 7.0, 7.0, 2.0, 4.0, 30.0, 11.0, 5.0, 4.0, 3.0, 5.0, 5.0, 1.0, 25.0, 9.0, 5.0, 3.0, 1.0, 13.0, 3.0, 16.0, 3.0, 23.0, 7.0, 3.0, 4.0, 8.0, 7.0]
all_test_density=[476.773623785693, 138.416457722865, 86.2553343089207, 497.832817337461, 0.0, 1136.19719567741, 464.211633651122, 1298.748215053885, 417.507842489405, 761.8877858563875, 980.533046913834, 1119.47683923706, 700.878409616274, 1267.69709939191, 164.907565423701, 1184.37878002419, 57.8281239074191, 534.7080591944805, 211.60994308282, 898.785425101215, 273.79298014236804, 289.736992567181, 888.553194926892, 590.953991678391, 511.46611698016, 643.761067680214, 966.4377689791055, 573.108584868679, 23.3590188405212, 476.708667430317, 1228.2724911632, 819.165169843112, 129.444709772792, 1756.0760053027, 725.993505489408, 268.7440224445, 1650.48375950242]

project_names=['jackson-core.csv', 'go-lang-idea-plugin.csv', 'jphp.csv', 'rultor.csv', 'AsciidocFX.csv', 'vraptor4.csv', 'geoserver.csv', 'core.csv', 'jodd.csv', 'airlift.csv', 'redpen.csv', 'querydsl.csv', 'pdfsam.csv', 'jOOQ.csv', 'gradle.csv', 'checkstyle.csv', 'deeplearning4j.csv', 'lenskit.csv', 'zxing.csv', 'jcabi-github.csv', 'tajo.csv', 'JRAW.csv', 'flink.csv', 'mockito.csv', 'p6spy.csv', 'jackson-databind.csv', 'javaslang.csv', 'jedis.csv', 'intellij-haskforce.csv', 'blueflood.csv', 'morphia.csv', 'closure-compiler.csv', 'graylog2-server.csv', 'Achilles.csv', 'RoaringBitmap.csv', 'quickml.csv', 'HikariCP.csv']
print(len(project_names))

def function(selected_projects):
    all_last_type = []
    all_last_status = []
    all_build_result = []
    new_team_size = []

    for nameindex in range(len(selected_projects)):
        file_name = selected_projects[nameindex]
        # file_name = file_name.split("/")[1]
        # print(file_name)

        string = "/Users/jinxianhao/Documents/src/python/CI/Data_Base/esem_dataset/" + file_name
        csv_file = csv.reader(open(string, 'r'))
        pre = []
        final = []
        for item in csv_file:
            pre.append(item)

        for i in range(len(pre[0])):
            temp = []
            for index in range(1, len(pre)):
                # print(index)
                # print(pre[index][i])
                temp.append(pre[index][i])
            final.append(temp)
        indices = []
        for index in range(len(final[42])):
            if final[33][index] == 'passed':
                indices.append(index)
            else:
                # if final[42][index - 1] == 'passed':
                indices.append(index)

        for index in indices:

            new_team_size.append(float(final[8][index]))
            if final[58][index - 1] == '':
                all_last_type.append(-1)
            else:
                project_type = (final[58][index - 1][0:3])
                if project_type == 'mvn':
                    all_last_type.append(float(final[58][index - 1][5:]))
                elif project_type == 'ant':
                    all_last_type.append(float(final[58][index - 1][5:]) + 1000)
                else:
                    all_last_type.append(float(final[58][index - 1][8:]) + 2000)

            if final[33][index] == 'passed':
                all_build_result.append(1)
            else:
                all_build_result.append(0)
            if final[33][index-1] == 'passed':
                all_last_status.append(1)
            else:
                all_last_status.append(0)
    return all_build_result, new_team_size, all_last_status, all_last_type

project_index=[]
for index in range(len(project_names)):
    project_index.append(index)

X_index=np.array(project_index)
KF = KFold(n_splits=8)


precision=[]
recall=[]
build_save=[]
for train_index, test_index in KF.split(X_index):
    # print("TRAIN:", train_index, "TEST:", test_index)
    X_index_train, X_index_test = X_index[train_index], X_index[test_index]
    #print(len(X_index_train)/len(X_index_test))
    #print(X_index_test)
    project_test=[]
    project_train=[]
    for item in  X_index_train:
        project_train.append(project_names[item])
    for item in X_index_test:
        project_test.append(project_names[item])

    build_result_train, team_size_train, last_status_train, last_type_train=function(project_train)
    argument_train = []
    result_train = []
    for index in range(len(last_status_train)):
        argument_train.append([])
    for index in range(len(last_status_train)):
        argument_train[index].append(team_size_train[index])
        argument_train[index].append(last_status_train[index])
        argument_train[index].append(last_type_train[index])
    X_train = np.array(argument_train)
    Y_train = np.array(build_result_train)

    num_feature = 3
    middle_failures = 0
    last_failures = 0

    X_train = X_train.reshape((int(len(X_train)), num_feature))
    rf = RandomForestClassifier()  # 这里使用了默认的参数设置
    predictor = rf.fit(X_train, Y_train)

    for item in project_test:
        more = 0
        less = 0
        yes = 0
        num_test=0
        num_build=0
        new_project_test = []
        new_project_test.append(item)
        build_result_test, team_size_test, last_status_test, last_type_test = function(new_project_test)

        argument_test = []

        result_test = []
        for index in range(len(last_status_test)):
            argument_test.append([])
        for index in range(len(last_status_test)):
            argument_test[index].append(team_size_test[index])
            argument_test[index].append(last_status_test[index])
            argument_test[index].append(last_type_test[index])
        X_test = np.array(argument_test)
        Y_test = np.array(build_result_test)
        num_test=len(Y_test)
        # print(Y_test)
        X_test = X_test.reshape((int(len(X_test)), num_feature))
        Y_result = (predictor.predict(X_test))
        num = 0
        for index in range(len(Y_result)):
            if Y_result[index] == 0 and Y_test[index] == 0:
                yes = yes + 1
            if Y_result[index] == 0:
                more = more + 1
            if Y_test[index] == 0:
                less = less + 1

        if less != 0:
            recall0 = yes / less
            if more == 0:
                precision0 = 1
                # recall.append(yes / less)
            else:
                precision0 = yes / more
                # recall.append(yes / less)
            # print(recall0)
            # print(precision0)
            precision.append(precision0)
            recall.append(recall0)
            build_save.append(1-more/num_test)

print(functions.get_median(precision))
print(functions.get_median(recall))
print(build_save)
print(functions.get_median(build_save))


book = xlwt.Workbook(encoding='utf-8', style_compression=0)
sheet1 = book.add_sheet('test_line', cell_overwrite_ok=True)
sheet2 = book.add_sheet('test_case', cell_overwrite_ok=True)
sheet3 = book.add_sheet('assert_case', cell_overwrite_ok=True)


for index in range(len(precision)):
    sheet1.write(index,0,precision[index])
    sheet1.write(index,1,recall[index])
    if precision[index]==0 and recall[index]==0:
        sheet1.write(index,2,0)
    else:
        sheet1.write(index,2,2*precision[index]*recall[index]/(precision[index]+recall[index]))

#book.save(r'cross_project_performance1.xls')
f_score=[]
print(precision)
print(recall)
for index in range(len(precision)):
    if precision[index] == 0 and recall[index] == 0:
        f_score.append(0)
    else:
        f_score.append(2*precision[index]*recall[index]/(precision[index]+recall[index]))

print(f_score)
print(len(precision))
print(len(recall))
print(len(f_score))