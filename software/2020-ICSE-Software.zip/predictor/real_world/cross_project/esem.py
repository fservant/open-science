import csv
import numpy as np
import xlwt
import math
from sklearn.model_selection import KFold
from sklearn.ensemble import RandomForestClassifier

project_names=['jackson-core.csv', 'go-lang-idea-plugin.csv', 'jphp.csv', 'rultor.csv', 'AsciidocFX.csv', 'vraptor4.csv', 'geoserver.csv', 'core.csv', 'jodd.csv', 'airlift.csv', 'redpen.csv', 'querydsl.csv', 'pdfsam.csv', 'jOOQ.csv', 'gradle.csv', 'checkstyle.csv', 'deeplearning4j.csv', 'lenskit.csv', 'zxing.csv', 'jcabi-github.csv', 'tajo.csv', 'JRAW.csv', 'flink.csv', 'mockito.csv', 'p6spy.csv', 'jackson-databind.csv', 'javaslang.csv', 'jedis.csv', 'intellij-haskforce.csv', 'blueflood.csv', 'morphia.csv', 'closure-compiler.csv', 'graylog2-server.csv', 'Achilles.csv', 'RoaringBitmap.csv', 'quickml.csv', 'HikariCP.csv']


all_src_churn = []
all_file_churn = []
all_test_churn = []
all_build_result = []
new_team_size = []
all_last_type=[]
all_last_status=[]


print(len(project_names))


for nameindex in range(len(project_names)):
    file_name = project_names[nameindex]
    #file_name = file_name.split("/")[1]
    #print(file_name)

    string="/Users/jinxianhao/Documents/src/python/CI/Data_Base/esem_dataset/" + file_name
    csv_file = csv.reader(open(string, 'r'))
    pre = []
    final = []
    for item in csv_file:
        pre.append(item)

    for i in range(len(pre[0])):
        temp = []
        for index in range(1, len(pre)):
            # print(index)
            # print(pre[index][i])
            temp.append(pre[index][i])
        final.append(temp)
    #print(len(final[42]))

    indices = []
    for index in range(1,len(final[33])):
        if final[33][index] == 'passed':
            indices.append(index)
        else:
            #if final[42][index - 1] == 'passed':
            indices.append(index)
    src_churn=[]
    file_churn=[]
    test_churn=[]
    build_result=[]
    team_size=[]
    last_type = []

    last_status = []

    for index in indices:
        src_churn.append(float(final[14][index]))
        file_churn.append(float(final[21][index]))
        test_churn.append(float(final[15][index]))
        team_size.append(float(final[8][index]))
        if final[58][index-1]=='':
            last_type.append(-1)
        else:
            project_type=(final[58][index-1][0:3])
            if project_type=='mvn':
                last_type.append(float(final[58][index-1][5:]))
            elif project_type=='ant':
                last_type.append(float(final[58][index-1][5:])+1000)
            else:
                last_type.append(float(final[58][index - 1][8:]) + 1000)

        if final[33][index] == 'passed':
            build_result.append(1)
        else:
            build_result.append(0)
    if final[33][indices[0]-1]=='passed':
        last_status.append(1)
    else:
        last_status.append(0)

    for index in range(1,len(build_result)):
        last_status.append(build_result[index-1])

    all_src_churn.append(src_churn)
    all_file_churn.append(file_churn)
    all_test_churn.append(test_churn)
    all_build_result.append(build_result)
    new_team_size.append(team_size)
    all_last_status.append(last_status)
    all_last_type.append(last_type)

print('done')

argument_test=[]
argument_train=[]
result_test=[]
result_train=[]

def all(list):
    newlist=[]
    for item in list:
        for item1 in item:
            newlist.append(item1)
    return newlist

breakpoint=30

src_churn_train=all(all_src_churn[:breakpoint])
src_churn_test=all(all_src_churn[(breakpoint+1):])

file_churn_train=all(all_file_churn[:breakpoint])
file_churn_test=all(all_file_churn[(breakpoint+1):])

test_churn_train=all(all_test_churn[:breakpoint])
test_churn_test=all(all_test_churn[(breakpoint+1):])

last_status_train=all(all_last_status[:breakpoint])
last_status_test=all(all_last_status[(breakpoint+1):])

team_size_train=all(new_team_size[:breakpoint])
team_size_test=all(new_team_size[(breakpoint+1):])

build_result_train=all(all_build_result[:breakpoint])
build_result_test=all(all_build_result[(breakpoint+1):])

git_num_all_built_commits_train=all(all_last_type[:breakpoint])
git_num_all_built_commits_test=all(all_last_type[(breakpoint+1):])

for index in range(len(src_churn_train)):
    argument_train.append([])
for index in range(len(src_churn_train)):
    argument_train[index].append(src_churn_train[index])
    argument_train[index].append(file_churn_train[index])
    argument_train[index].append(test_churn_train[index])
    argument_train[index].append(team_size_train[index])
    argument_train[index].append(last_status_train[index])

for index in range(len(src_churn_test)):
    argument_test.append([])
for index in range(len(src_churn_test)):
    argument_test[index].append(src_churn_test[index])
    argument_test[index].append(file_churn_test[index])
    argument_test[index].append(test_churn_test[index])
    argument_test[index].append(team_size_test[index])
    argument_test[index].append(last_status_test[index])

X_train = np.array(argument_train)
Y_train = np.array(build_result_train)
num_feature=5
X_train = X_train.reshape((int(len(X_train)), num_feature))
rf = RandomForestClassifier()  # 这里使用了默认的参数设置
predictor = rf.fit(X_train, Y_train)

X_test = np.array(argument_test)
Y_test = np.array(build_result_test)
X_test = X_test.reshape((int(len(X_test)), num_feature))
Y_result=(predictor.predict(X_test))


yes=0
more=0
less=0
for index in range(len(Y_result)):
    if Y_result[index] == 0 and Y_test[index] == 0:
        yes = yes + 1
    if Y_result[index] == 0:
        more = more + 1
    if Y_test[index] == 0:
        less = less + 1
print(yes/(more))
print(yes/(less))
print(2*yes/more*yes/less/(yes/more+yes/less))