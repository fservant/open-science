import csv
import numpy as np
import xlwt
import sys
sys.path.insert(0, '/Users/jinxianhao/Desktop/folder/')
import functions
from sklearn.model_selection import KFold
from sklearn.ensemble import RandomForestClassifier
import random


project_names=['jackson-core.csv', 'go-lang-idea-plugin.csv', 'jphp.csv', 'rultor.csv', 'AsciidocFX.csv', 'vraptor4.csv', 'geoserver.csv', 'core.csv', 'jodd.csv', 'airlift.csv', 'redpen.csv', 'querydsl.csv', 'pdfsam.csv', 'jOOQ.csv', 'gradle.csv', 'checkstyle.csv', 'deeplearning4j.csv', 'lenskit.csv', 'zxing.csv', 'jcabi-github.csv', 'tajo.csv', 'JRAW.csv', 'flink.csv', 'mockito.csv', 'p6spy.csv', 'jackson-databind.csv', 'javaslang.csv', 'jedis.csv', 'intellij-haskforce.csv', 'blueflood.csv', 'morphia.csv', 'closure-compiler.csv', 'graylog2-server.csv', 'Achilles.csv', 'RoaringBitmap.csv', 'quickml.csv', 'HikariCP.csv']

def function(selected_projects):
    build_result = []
    team_size = []
    last_type=[]
    last_status=[]

    for nameindex in range(len(selected_projects)):
        file_name = selected_projects[nameindex]
        # file_name = file_name.split("/")[1]
        # print(file_name)

        string = "/Users/jinxianhao/Documents/src/python/CI/Data_Base/esem_dataset/" + file_name
        csv_file = csv.reader(open(string, 'r'))
        pre = []
        final = []
        for item in csv_file:
            pre.append(item)

        for i in range(len(pre[0])):
            temp = []
            for index in range(1, len(pre)):
                # print(index)
                # print(pre[index][i])
                temp.append(pre[index][i])
            final.append(temp)
        indices = []
        for index in range(len(final[42])):
            if final[42][index] == 'passed':
                indices.append(index)
            else:
                # if final[42][index - 1] == 'passed':
                indices.append(index)

        for index in indices:
            team_size.append(float(final[8][index]))
            if final[58][index - 1] == '':
                last_type.append(-1)
            else:
                project_type = (final[58][index - 1][0:3])
                if project_type == 'mvn':
                    last_type.append(float(final[58][index - 1][5:]))
                elif project_type == 'ant':
                    last_type.append(float(final[58][index - 1][5:]) + 1000)
                else:
                    last_type.append(float(final[58][index - 1][8:]) + 2000)

        for item in indices:
            if final[33][item] == 'passed':
                build_result.append(1)
            else:
                build_result.append(0)

        for item in indices:
            if final[33][item - 1] == 'passed':
                last_status.append(1)
            else:
                last_status.append(0)

    return build_result, team_size, last_type, last_status

project_index=[]
for index in range(len(project_names)):
    project_index.append(index)

random.shuffle(project_index)
X_index=np.array(project_index)
KF = KFold(n_splits=8)


precision=[]
recall=[]
build_save=[]
for train_index, test_index in KF.split(X_index):
    print(0)
    X_index_train, X_index_test = X_index[train_index], X_index[test_index]
    #print(len(X_index_train)/len(X_index_test))
    #print(X_index_test)
    project_test=[]
    project_train=[]
    for item in  X_index_train:
        project_train.append(project_names[item])
    for item in X_index_test:
        project_test.append(project_names[item])

    build_result_train, team_size_train, last_type_train, last_status_train=function(project_train)

    argument_train = []
    result_train = []

    for index in range(len(last_type_train)):
        argument_train.append([])
    for index in range(len(last_type_train)):
        argument_train[index].append(team_size_train[index])
        argument_train[index].append(last_type_train[index])
        argument_train[index].append(last_status_train[index])
    X_train = np.array(argument_train)
    Y_train = np.array(build_result_train)

    num_feature = 3

    X_train = X_train.reshape((int(len(X_train)), num_feature))
    rf = RandomForestClassifier()  # 这里使用了默认的参数设置
    predictor = rf.fit(X_train, Y_train)
    print(1)


    for item in project_test:
        more = 0
        less = 0
        yes = 0
        num_test=0
        num_build=0

        new_project_test=[]
        new_project_test.append(item)
        build_result_test, team_size_test, last_type_test, last_status_test = function(new_project_test)

        argument_test = []
        result_test = []
        for index in range(len(last_type_test)):
            argument_test.append([])
        for index in range(len(last_type_test)):
            argument_test[index].append(team_size_test[index])
            argument_test[index].append(last_type_test[index])
            argument_test[index].append(last_status_test[index])

        X_test = np.array(argument_test)
        Y_test = np.array(build_result_test)
        num_test=len(Y_test)
        # print(build_result_test)
        X_test = X_test.reshape((int(len(X_test)), num_feature))
        Y_result = (predictor.predict(X_test))

        new_build = X_test[0]
        flag = 0
        line = 0
        file = 0
        test = 0
        commit = 0
        results = []
        fail = 0
        # print(X_test)

        for index in range(len(X_test)):

            if index == 0:

                new_build = new_build.reshape((1, num_feature))
                new_result = predictor.predict(new_build)
                # print(New_build[0][0])
                if new_result[0] == 1:
                    flag = 0
                    #line = line + new_build[0][0]
                    #file = file + new_build[0][1]
                    #test = test + new_build[0][2]
                    #commit = commit + new_build[0][3]
                    status = 1
                    cluster = -1
                else:
                    flag = 1
                    num_build=num_build+1
                    X_train = X_train.tolist()
                    X_train.append(new_build[0])
                    Y_train = Y_train.tolist()
                    Y_train.append(Y_test[index])
                    X_train = np.array(X_train)
                    Y_train = np.array(Y_train)
                    X_train = X_train.reshape((int(len(X_train)), num_feature))
                    rf = RandomForestClassifier()  # 这里使用了默认的参数设置
                    predictor = rf.fit(X_train, Y_train)
                    status = 0
                    cluster = X_test[index][1]
            if index != 0 and flag == 0:
                #new_line = line + X_test[index][0]
                #new_file = file + X_test[index][1]
                #new_test = test + X_test[index][2]
                new_team = X_test[index][0]
                new_build = []
                #new_build.append(new_line)
                #new_build.append(new_file)
                #new_build.append(new_test)
                new_build.append(new_team)
                new_build.append(status)
                new_build.append(cluster)
                new_build = np.array(new_build)

                #new_build = X_test[index]

                new_build = new_build.reshape((1, num_feature))
                new_result = predictor.predict(new_build)
                if new_result[0] == 1:
                    flag = 0
                    #line = new_build[0][0]
                    #file = new_build[0][1]
                    #test = new_build[0][2]
                    team = new_build[0][0]
                    cluster=-1
                    status=1
                else:
                    flag = 1
                    num_build = num_build + 1
                    X_train = X_train.tolist()
                    X_train.append(new_build[0])
                    Y_train = Y_train.tolist()
                    Y_train.append(Y_test[index])
                    X_train = np.array(X_train)
                    Y_train = np.array(Y_train)
                    X_train = X_train.reshape((int(len(X_train)), num_feature))
                    rf = RandomForestClassifier()  # 这里使用了默认的参数设置
                    predictor = rf.fit(X_train, Y_train)
                    status = 0
                    cluster = X_test[index][1]
            elif index != 0 and flag == 1:
                new_build = X_test[index]
                new_build = new_build.reshape((1, num_feature))
                new_result = predictor.predict(new_build)
                if new_result[0] == 1:
                    flag = 0
                    #line = new_build[0][0]
                    #file = new_build[0][1]
                    #test = new_build[0][2]
                    team = new_build[0][0]
                    cluster = -1
                    status = 1
                else:
                    flag = 1
                    num_build = num_build + 1
                    #new_build[0][]
                    X_train = X_train.tolist()
                    X_train.append(new_build[0])
                    Y_train = Y_train.tolist()
                    Y_train.append(Y_test[index])
                    X_train = np.array(X_train)
                    Y_train = np.array(Y_train)
                    X_train = X_train.reshape((int(len(X_train)), num_feature))
                    rf = RandomForestClassifier()  # 这里使用了默认的参数设置
                    predictor = rf.fit(X_train, Y_train)
                    status = 0
                    cluster = X_test[index][1]
            # print(line)
            results.append(new_result[0])
        print(results)
        for index in range(len(results)):
            if results[index] == 0 and Y_test[index] == 0:
                yes = yes + 1
            if results[index] == 0:
                more = more + 1
            if Y_test[index] == 0:
                less = less + 1

        if less != 0:
            recall0 = yes / less
            if more == 0:
                precision0 = 1
                # recall.append(yes / less)
            else:
                precision0 = yes / more
                # recall.append(yes / less)
            precision.append(precision0)
            recall.append(recall0)
            build_save.append(1-num_build/num_test)

print(functions.get_median(precision))
print(functions.get_median(recall))
print(build_save)
print(functions.get_median(build_save))
book = xlwt.Workbook(encoding='utf-8', style_compression=0)
sheet1 = book.add_sheet('test_line', cell_overwrite_ok=True)
sheet2 = book.add_sheet('test_case', cell_overwrite_ok=True)
sheet3 = book.add_sheet('assert_case', cell_overwrite_ok=True)


for index in range(len(precision)):
    sheet1.write(index,1,precision[index])
    sheet2.write(index,1,recall[index])
    #sheet1.write(index,2,f_score[index])

#book.save(r'cross_project_performance1.xls')
