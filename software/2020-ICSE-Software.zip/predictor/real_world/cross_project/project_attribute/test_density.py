import numpy as np
from sklearn.cluster import DBSCAN
from sklearn.cluster import AffinityPropagation
from sklearn.cluster import KMeans
import csv
import matplotlib.pyplot as plt
import xlwt

'''
X=np.array([1,2,3,4,5,11,12,13,14,15])
X=X.reshape(-1,1)
y_pred = DBSCAN().fit_predict(X)
y_pred = AffinityPropagation().fit_predict(X)
print(y_pred)
'''

def get_median(data):
    data = sorted(data)
    size = len(data)
    if size % 2 == 0:  # 判断列表长度为偶数
        median = (data[size // 2] + data[size // 2 - 1]) / 2
        data[0] = median
    if size % 2 == 1:  # 判断列表长度为奇数
        median = data[(size - 1) // 2]
        data[0] = median
    return data[0]

def plot(X):
    Sum_of_squared_distances = []
    K = range(1, 15)
    for k in K:
        km = KMeans(n_clusters=k)
        km = km.fit(X)
        Sum_of_squared_distances.append(km.inertia_)

    plt.plot(K, Sum_of_squared_distances, 'bx-')
    plt.xlabel('k')
    plt.ylabel('Sum_of_squared_distances')
    plt.title('Elbow Method For Optimal k')
    plt.show()


project_names=['jackson-core.csv', 'go-lang-idea-plugin.csv', 'jphp.csv', 'rultor.csv', 'AsciidocFX.csv', 'vraptor4.csv', 'geoserver.csv', 'core.csv', 'jodd.csv', 'airlift.csv', 'redpen.csv', 'querydsl.csv', 'pdfsam.csv', 'jOOQ.csv', 'gradle.csv', 'checkstyle.csv', 'deeplearning4j.csv', 'lenskit.csv', 'zxing.csv', 'jcabi-github.csv', 'tajo.csv', 'JRAW.csv', 'flink.csv', 'mockito.csv', 'p6spy.csv', 'jackson-databind.csv', 'javaslang.csv', 'jedis.csv', 'intellij-haskforce.csv', 'blueflood.csv', 'morphia.csv', 'closure-compiler.csv', 'graylog2-server.csv', 'Achilles.csv', 'RoaringBitmap.csv', 'quickml.csv', 'HikariCP.csv']


passes_length=[]
test_density=[]
'''
X=np.array(test_density)
X=X.reshape(-1,1)
y_pred0 = KMeans(n_clusters=3).fit_predict(X)
cluster=[[],[],[]]
cluster1=[[],[],[]]
names=[[],[],[]]
result=[[],[],[]]
for index in range(len(y_pred0)):
    if y_pred0[index]==0:
        cluster[0].append(index)
        cluster1[0].append(test_density[index])
        names[0].append(project_names[index])
    elif y_pred0[index]==1:
        cluster[1].append(index)
        cluster1[1].append(test_density[index])
        names[1].append(project_names[index])
    else:
        cluster[2].append(index)
        cluster1[2].append(test_density[index])
        names[2].append(project_names[index])

for item in cluster1:
    #print(get_median(item))
    print(max(item))
    print(min(item))
print(names)
'''
failure_ratio=[]
for nameindex in range(len(project_names)):
    file_name = project_names[nameindex]
    #file_name = file_name.split("/")[1]
    #print(file_name)

    string = "/Users/jinxianhao/Documents/src/python/CI/Data_Base/esem_dataset/" + file_name
    csv_file = csv.reader(open(string, 'r'))
    pre = []
    final = []
    for item in csv_file:
        pre.append(item)

    for i in range(len(pre[0])):
        temp = []
        for index in range(1, len(pre)):
            # print(index)
            # print(pre[index][i])
            temp.append(pre[index][i])
        final.append(temp)
    '''
    build_result = []
    for item in final[42]:
        if item == 'passed':
            build_result.append(1)
        else:
            build_result.append(0)
    '''

    indices = []
    for index in range(len(final[33])):
        if final[33][index] == 'passed':
            indices.append(index)
        else:
            if final[33][index - 1] == 'passed':
                indices.append(index)

    build_result = []
    for item in indices:
        if final[33][item] == 'passed':
            build_result.append(1)
        else:
            build_result.append(0)

    # print(final[42])
    # print(indices)

    team = []

    for index in range(len(final[35])):
        try:
            team.append(float(final[26][index]))
        except:
            index = index

    failure_ratio.append(1 - sum(build_result) / len(build_result))
    # test_density.append(sum(test_line)/len(test_line))
    test_density.append(get_median(team))
    # '''
print(test_density)
'''

for index in range(len(cluster)):
    for item in cluster[index]:
        try:
            #result[index].append(failures_length[item])
            result[index].append(failure_ratio[item])
        except:
            print(item)

#for item in result:
    #print(get_median(item))
    #print(sum(item)/len(item))

book = xlwt.Workbook(encoding='utf-8', style_compression=0)
sheet1 = book.add_sheet('test_line', cell_overwrite_ok=True)
sheet2 = book.add_sheet('test_case', cell_overwrite_ok=True)
sheet3 = book.add_sheet('assert_case', cell_overwrite_ok=True)
col=0

for index in range(len(result)):
    print(get_median(result[index]))
    print(sum(result[index]) / len(result[index]))
    string='cluster '+ str(index)
    for item in result[index]:
        sheet1.write(col,0,string)
        sheet1.write(col,1,item)
        col=col+1
book.save(r'cluster_fail_ratio_test_density.xls')
'''
