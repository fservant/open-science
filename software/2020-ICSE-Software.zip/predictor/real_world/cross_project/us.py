import csv
import numpy as np
import xlwt
import math
from sklearn.model_selection import KFold
from sklearn.ensemble import RandomForestClassifier

all_project_age=[17.93727662037037, 19.121140046296297, 20.609096450617283, 15.588740354938272, 12.814837962962963, 21.87333603395062, 22.594797453703702, 14.85992476851852, 21.29057137345679, 22.565575231481482, 22.468806712962962, 15.53714313271605, 22.33132638888889, 16.904368827160493, 17.330614197530863, 22.799449459876545, 17.303841049382715, 22.834096450617285, 18.50705825617284, 16.146770447530866, 15.330529706790124, 13.623905478395061, 13.689577160493828, 20.818514274691356, 21.233930169753087, 17.66437847222222, 15.69138348765432, 17.97262885802469, 14.543631172839506, 23.393461419753088, 19.223894675925926, 13.203061728395062, 39.94107214506173, 23.42955015432099, 17.37164313271605, 23.447115740740742, 21.766220679012346]
all_project_size=[16066.5, 35096.0, 54018.5, 4840.0, 3878.0, 11213.5, 292590.0, 52340.0, 77649.0, 23805.0, 4763.0, 46486.0, 8645.0, 94244.0, 167751.0, 28987.5, 33606.5, 26557.0, 34565.0, 15028.0, 140237.5, 4870.0, 127280.0, 33382.0, 4120.0, 47874.0, 4111.0, 12379.0, 24544.0, 15093.0, 11325.0, 126109.0, 50613.5, 17352.0, 6497.0, 5017.0, 2294.0]
all_team_size=[3.0, 8.0, 5.0, 6.0, 4.0, 23.0, 42.0, 9.0, 3.0, 9.0, 7.0, 7.0, 2.0, 4.0, 30.0, 11.0, 5.0, 4.0, 3.0, 5.0, 5.0, 1.0, 25.0, 9.0, 5.0, 3.0, 1.0, 13.0, 3.0, 16.0, 3.0, 23.0, 7.0, 3.0, 4.0, 8.0, 7.0]
all_test_density=[476.773623785693, 138.416457722865, 86.2553343089207, 497.832817337461, 0.0, 1136.19719567741, 464.211633651122, 1298.748215053885, 417.507842489405, 761.8877858563875, 980.533046913834, 1119.47683923706, 700.878409616274, 1267.69709939191, 164.907565423701, 1184.37878002419, 57.8281239074191, 534.7080591944805, 211.60994308282, 898.785425101215, 273.79298014236804, 289.736992567181, 888.553194926892, 590.953991678391, 511.46611698016, 643.761067680214, 966.4377689791055, 573.108584868679, 23.3590188405212, 476.708667430317, 1228.2724911632, 819.165169843112, 129.444709772792, 1756.0760053027, 725.993505489408, 268.7440224445, 1650.48375950242]

project_names=['jackson-core.csv', 'go-lang-idea-plugin.csv', 'jphp.csv', 'rultor.csv', 'AsciidocFX.csv', 'vraptor4.csv', 'geoserver.csv', 'core.csv', 'jodd.csv', 'airlift.csv', 'redpen.csv', 'querydsl.csv', 'pdfsam.csv', 'jOOQ.csv', 'gradle.csv', 'checkstyle.csv', 'deeplearning4j.csv', 'lenskit.csv', 'zxing.csv', 'jcabi-github.csv', 'tajo.csv', 'JRAW.csv', 'flink.csv', 'mockito.csv', 'p6spy.csv', 'jackson-databind.csv', 'javaslang.csv', 'jedis.csv', 'intellij-haskforce.csv', 'blueflood.csv', 'morphia.csv', 'closure-compiler.csv', 'graylog2-server.csv', 'Achilles.csv', 'RoaringBitmap.csv', 'quickml.csv', 'HikariCP.csv']







all_src_churn = []
all_file_churn = []
all_test_churn = []
all_build_result = []
new_team_size = []
all_git_num_all_built_commits = []
new_test_density=[]
new_project_age=[]
new_project_size=[]


print(len(project_names))


for nameindex in range(len(project_names)):
    file_name = project_names[nameindex]
    #file_name = file_name.split("/")[1]
    #print(file_name)

    string="/Users/jinxianhao/Documents/src/python/CI/Data_Base/esem_dataset/" + file_name
    csv_file = csv.reader(open(string, 'r'))
    pre = []
    final = []
    for item in csv_file:
        pre.append(item)

    for i in range(len(pre[0])):
        temp = []
        for index in range(1, len(pre)):
            # print(index)
            # print(pre[index][i])
            temp.append(pre[index][i])
        final.append(temp)
    #print(len(final[42]))

    indices = []
    for index in range(len(final[42])):
        if final[42][index] == 'passed':
            indices.append(index)
        else:
            #if final[42][index - 1] == 'passed':
            indices.append(index)
    src_churn=[]
    file_churn=[]
    test_churn=[]
    build_result=[]
    team_size=[]
    git_num_all_built_commits=[]
    test_density=[]
    project_age=[]
    project_size=[]

    for index in indices:
        src_churn.append(float(final[14][index]))
        file_churn.append(float(final[21][index]))
        test_churn.append(float(final[15][index]))
        git_num_all_built_commits.append(float(final[10][index]))

        if all_test_density[nameindex]>=0 and all_test_density[nameindex]<675:
            test_density.append(0)
        elif all_test_density[nameindex]>679 and all_test_density[nameindex]<1609:
            test_density.append(1)
        else:
            test_density.append(2)

        if all_team_size[nameindex]>=0 and all_team_size[nameindex]<=18:
            team_size.append(0)
        elif all_team_size[nameindex]>=19 and all_team_size[nameindex]<=51:
            team_size.append(1)
        elif all_team_size[nameindex]>=72 and all_team_size[nameindex]<=93:
            team_size.append(2)
        else:
            team_size.append(3)

        if all_project_age[nameindex]>12 and all_project_age[nameindex]<29.4:
            project_age.append(0)
        elif all_project_age[nameindex]>29.5 and all_project_age[nameindex]<44.8:
            project_age.append(1)
        else:
            project_age.append(2)

        if all_project_size[nameindex]>=696 and all_project_size[nameindex]<=101107:
            project_size.append(0)
        elif all_project_size[nameindex]>=121745 and all_project_size[nameindex]<=429028:
            project_size.append(1)
        else:
            project_size.append(2)

        if final[33][index] == 'passed':
            build_result.append(1)
        else:
            build_result.append(0)


    all_src_churn.append(src_churn)
    all_file_churn.append(file_churn)
    all_test_churn.append(test_churn)
    all_build_result.append(build_result)
    new_team_size.append(team_size)
    all_git_num_all_built_commits.append(git_num_all_built_commits)
    new_test_density.append(test_density)
    new_project_age.append(project_age)
    new_project_size.append(project_size)

print('done')

argument_test=[]
argument_train=[]
result_test=[]
result_train=[]

def all(list):
    newlist=[]
    for item in list:
        for item1 in item:
            newlist.append(item1)
    return newlist
breakpoint=30

src_churn_train=all(all_src_churn[:breakpoint])
src_churn_test=all(all_src_churn[(breakpoint+1):])

file_churn_train=all(all_file_churn[:breakpoint])
file_churn_test=all(all_file_churn[(breakpoint+1):])

test_churn_train=all(all_test_churn[:breakpoint])
test_churn_test=all(all_test_churn[(breakpoint+1):])

test_density_train=all(new_test_density[:breakpoint])
test_density_test=all(new_test_density[(breakpoint+1):])

project_size_train=all(new_project_size[:breakpoint])
project_size_test=all(new_project_size[(breakpoint+1):])

project_age_train=all(new_project_age[:breakpoint])
project_age_test=all(new_project_age[(breakpoint+1):])

team_size_train=all(new_team_size[:breakpoint])
team_size_test=all(new_team_size[(breakpoint+1):])

build_result_train=all(all_build_result[:breakpoint])
build_result_test=all(all_build_result[(breakpoint+1):])

git_num_all_built_commits_train=all(all_git_num_all_built_commits[:breakpoint])
git_num_all_built_commits_test=all(all_git_num_all_built_commits[(breakpoint+1):])

for index in range(len(src_churn_train)):
    argument_train.append([])
for index in range(len(src_churn_train)):
    argument_train[index].append(src_churn_train[index])
    argument_train[index].append(file_churn_train[index])
    argument_train[index].append(test_churn_train[index])
    argument_train[index].append(test_density_train[index])
    argument_train[index].append(project_size_train[index])
    argument_train[index].append(project_age_train[index])
    #argument_train[index].append(team_size_train[index])
    argument_train[index].append(git_num_all_built_commits_train[index])

for index in range(len(src_churn_test)):
    argument_test.append([])
for index in range(len(src_churn_test)):
    argument_test[index].append(src_churn_test[index])
    argument_test[index].append(file_churn_test[index])
    argument_test[index].append(test_churn_test[index])
    argument_test[index].append(test_density_test[index])
    #argument_test[index].append(project_size_test[index])
    argument_test[index].append(project_age_test[index])
    argument_test[index].append(team_size_test[index])
    argument_test[index].append(git_num_all_built_commits_test[index])

X_train = np.array(argument_train)
Y_train = np.array(build_result_train)
indices = []
for index in range(len(Y_train)):
    if Y_train[index] == 1:
        indices.append(index)
    else:
        if Y_train[index - 1] == 1:
            indices.append(index)
New_X_train = []
New_Y_train = []
for item in indices:
    New_X_train.append(X_train[item])
    New_Y_train.append(Y_train[item])
X_train = np.array(New_X_train)
Y_train = np.array(New_Y_train)

num_feature=7
middle_failures=0
last_failures=0


X_train = X_train.reshape((int(len(X_train)), num_feature))
rf = RandomForestClassifier()  # 这里使用了默认的参数设置
predictor = rf.fit(X_train, Y_train)

X_test = np.array(argument_test)
Y_test = np.array(build_result_test)


for index in range(len(Y_test)):
    if index != len(Y_test) and Y_test[index] == 0 and Y_test[index - 1] == 0:
        middle_failures = middle_failures + 1
    if index == len(Y_test) and Y_test[index] == 0:
        middle_failures = middle_failures + 1
    if Y_test[index] == 1 and Y_test[index - 1] == 0:
        last_failures = last_failures + 1
indices = []
for index in range(len(Y_test)):
    if Y_test[index] == 1:
        indices.append(index)
    else:
        if Y_test[index - 1] == 1:
            indices.append(index)
        if index == 0:
            indices.append(index)
New_X_test = []
New_Y_test = []
for item in indices:
    New_X_test.append(X_test[item])
    New_Y_test.append(Y_test[item])
X_test = np.array(New_X_test)
Y_test = np.array(New_Y_test)
X_test = X_test.reshape((int(len(X_test)), num_feature))
Y_result=(predictor.predict(X_test))

yes=0
more=0
less=0
for index in range(len(Y_result)):
    if Y_result[index] == 0 and Y_test[index] == 0:
        yes = yes + 1
    if Y_result[index] == 0:
        more = more + 1
    if Y_test[index] == 0:
        less = less + 1
precision0 = (yes + middle_failures) / (more + middle_failures + last_failures)
recall0 = (yes + middle_failures) / (less + middle_failures)

print(precision0)
print(recall0)