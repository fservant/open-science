import csv
import numpy as np
import xlwt
import sys
sys.path.insert(0, '/Users/jinxianhao/Desktop/folder/')
import functions
from sklearn.model_selection import KFold
from sklearn.ensemble import RandomForestClassifier
import random

all_project_age=[17.93727662037037, 19.121140046296297, 20.609096450617283, 15.588740354938272, 12.814837962962963, 21.87333603395062, 22.594797453703702, 14.85992476851852, 21.29057137345679, 22.565575231481482, 22.468806712962962, 15.53714313271605, 22.33132638888889, 16.904368827160493, 17.330614197530863, 22.799449459876545, 17.303841049382715, 22.834096450617285, 18.50705825617284, 16.146770447530866, 15.330529706790124, 13.623905478395061, 13.689577160493828, 20.818514274691356, 21.233930169753087, 17.66437847222222, 15.69138348765432, 17.97262885802469, 14.543631172839506, 23.393461419753088, 19.223894675925926, 13.203061728395062, 39.94107214506173, 23.42955015432099, 17.37164313271605, 23.447115740740742, 21.766220679012346]
all_project_size=[16066.5, 35096.0, 54018.5, 4840.0, 3878.0, 11213.5, 292590.0, 52340.0, 77649.0, 23805.0, 4763.0, 46486.0, 8645.0, 94244.0, 167751.0, 28987.5, 33606.5, 26557.0, 34565.0, 15028.0, 140237.5, 4870.0, 127280.0, 33382.0, 4120.0, 47874.0, 4111.0, 12379.0, 24544.0, 15093.0, 11325.0, 126109.0, 50613.5, 17352.0, 6497.0, 5017.0, 2294.0]
all_team_size=[3.0, 8.0, 5.0, 6.0, 4.0, 23.0, 42.0, 9.0, 3.0, 9.0, 7.0, 7.0, 2.0, 4.0, 30.0, 11.0, 5.0, 4.0, 3.0, 5.0, 5.0, 1.0, 25.0, 9.0, 5.0, 3.0, 1.0, 13.0, 3.0, 16.0, 3.0, 23.0, 7.0, 3.0, 4.0, 8.0, 7.0]
all_test_density=[476.773623785693, 138.416457722865, 86.2553343089207, 497.832817337461, 0.0, 1136.19719567741, 464.211633651122, 1298.748215053885, 417.507842489405, 761.8877858563875, 980.533046913834, 1119.47683923706, 700.878409616274, 1267.69709939191, 164.907565423701, 1184.37878002419, 57.8281239074191, 534.7080591944805, 211.60994308282, 898.785425101215, 273.79298014236804, 289.736992567181, 888.553194926892, 590.953991678391, 511.46611698016, 643.761067680214, 966.4377689791055, 573.108584868679, 23.3590188405212, 476.708667430317, 1228.2724911632, 819.165169843112, 129.444709772792, 1756.0760053027, 725.993505489408, 268.7440224445, 1650.48375950242]

project_names=['jackson-core.csv', 'go-lang-idea-plugin.csv', 'jphp.csv', 'rultor.csv', 'AsciidocFX.csv', 'vraptor4.csv', 'geoserver.csv', 'core.csv', 'jodd.csv', 'airlift.csv', 'redpen.csv', 'querydsl.csv', 'pdfsam.csv', 'jOOQ.csv', 'gradle.csv', 'checkstyle.csv', 'deeplearning4j.csv', 'lenskit.csv', 'zxing.csv', 'jcabi-github.csv', 'tajo.csv', 'JRAW.csv', 'flink.csv', 'mockito.csv', 'p6spy.csv', 'jackson-databind.csv', 'javaslang.csv', 'jedis.csv', 'intellij-haskforce.csv', 'blueflood.csv', 'morphia.csv', 'closure-compiler.csv', 'graylog2-server.csv', 'Achilles.csv', 'RoaringBitmap.csv', 'quickml.csv', 'HikariCP.csv']

threshold=0.6
thresholds=[0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1]
thresholds=[0.2]

ratio=0.1
ratios=[0.1, 0.5, 0.8, 2, 5, 10]
bootstraps=[True, False]
estimators = [100, 200, 500, 1000]
depths=[10, 50, 100]
features=['auto', 'sqrt']


def function(selected_projects):
    all_src_churn = []
    all_file_churn = []
    all_test_churn = []
    all_build_result = []
    new_team_size = []
    all_git_num_all_built_commits = []
    new_test_density = []
    new_project_age = []
    new_project_size = []

    for nameindex in range(len(selected_projects)):
        file_name = selected_projects[nameindex]
        # file_name = file_name.split("/")[1]
        # print(file_name)

        string = "/Users/jinxianhao/Documents/src/python/CI/Data_Base/esem_dataset/" + file_name
        csv_file = csv.reader(open(string, 'r'))
        pre = []
        final = []
        for item in csv_file:
            pre.append(item)

        for i in range(len(pre[0])):
            temp = []
            for index in range(1, len(pre)):
                # print(index)
                # print(pre[index][i])
                temp.append(pre[index][i])
            final.append(temp)
        indices = []
        for index in range(len(final[33])):
            if final[33][index] == 'passed':
                indices.append(index)
            else:
                # if final[42][index - 1] == 'passed':
                indices.append(index)

        for index in indices:

            tmp_line = 0
            tmp_file = 0
            tmp_test = 0
            tmp_commit = 0
            temp = index

            while (final[33][temp - 1] != 'passed'):
                temp = temp - 1
                if temp <= 0:
                    break
            # print(temp)

            for index1 in range(temp, index + 1):
                # print(float(final[23][index1]))
                tmp_line = tmp_line + float(final[14][index1])
                tmp_file = tmp_file + float(final[21][index1])
                tmp_test = tmp_test + float(final[15][index1])
                tmp_commit = tmp_commit + float(final[10][index1])

            all_src_churn.append(tmp_line)
            all_file_churn.append(tmp_file)
            all_test_churn.append(tmp_test)
            all_git_num_all_built_commits.append(tmp_commit)

            if all_test_density[nameindex] >= 0 and all_test_density[nameindex] < 675:
                new_test_density.append(0)
            elif all_test_density[nameindex] > 679 and all_test_density[nameindex] < 1609:
                new_test_density.append(1)
            else:
                new_test_density.append(2)

            if all_team_size[nameindex] >= 0 and all_team_size[nameindex] <= 18:
                new_team_size.append(0)
            elif all_team_size[nameindex] >= 19 and all_team_size[nameindex] <= 51:
                new_team_size.append(1)
            elif all_team_size[nameindex] >= 72 and all_team_size[nameindex] <= 93:
                new_team_size.append(2)
            else:
                new_team_size.append(3)

            if all_project_age[nameindex] > 12 and all_project_age[nameindex] < 29.4:
                new_project_age.append(0)
            elif all_project_age[nameindex] > 29.5 and all_project_age[nameindex] < 44.8:
                new_project_age.append(1)
            else:
                new_project_age.append(2)

            if all_project_size[nameindex] >= 696 and all_project_size[nameindex] <= 101107:
                new_project_size.append(0)
            elif all_project_size[nameindex] >= 121745 and all_project_size[nameindex] <= 429028:
                new_project_size.append(1)
            else:
                new_project_size.append(2)

            if final[33][index] == 'passed':
                all_build_result.append(1)
            else:
                all_build_result.append(0)
    return all_src_churn, all_file_churn, all_test_churn, all_build_result, new_team_size, all_git_num_all_built_commits, new_test_density, new_project_age, new_project_size

project_index=[]
for index in range(len(project_names)):
    project_index.append(index)

random.shuffle(project_index)
X_index=np.array(project_index)
KF = KFold(n_splits=8)

#configuration=

for threshold in thresholds:
    precision = []
    recall = []
    build_save = []

    for train_index, test_index in KF.split(X_index):
        # print(0)
        X_index_train, X_index_test = X_index[train_index], X_index[test_index]
        # print(len(X_index_train)/len(X_index_test))
        # print(X_index_test)
        project_test = []
        project_train = []
        for item in X_index_train:
            project_train.append(project_names[item])
        for item in X_index_test:
            project_test.append(project_names[item])

        src_churn_train, file_churn_train, test_churn_train, build_result_train, team_size_train, git_num_all_built_commits_train, test_density_train, project_age_train, project_size_train = function(
            project_train)

        argument_train = []
        result_train = []

        for index in range(len(src_churn_train)):
            argument_train.append([])
        for index in range(len(src_churn_train)):
            argument_train[index].append(src_churn_train[index])
            argument_train[index].append(file_churn_train[index])
            argument_train[index].append(test_churn_train[index])
            argument_train[index].append(test_density_train[index])
            argument_train[index].append(project_size_train[index])
            argument_train[index].append(project_age_train[index])
            # argument_train[index].append(team_size_train[index])
            argument_train[index].append(git_num_all_built_commits_train[index])
        X_train = np.array(argument_train)
        Y_train = np.array(build_result_train)

        num_feature = 7

        X_train = X_train.reshape((int(len(X_train)), num_feature))
        rf = RandomForestClassifier(class_weight={0:ratio,1:1})  # 这里使用了默认的参数设置
        predictor = rf.fit(X_train, Y_train)

        # print(1)

        for item in project_test:
            print(item)
            more = 0
            less = 0
            yes = 0
            num_test = 0
            num_build = 0

            new_project_test = []
            new_project_test.append(item)
            src_churn_test, file_churn_test, test_churn_test, build_result_test, team_size_test, git_num_all_built_commits_test, test_density_test, project_age_test, project_size_test = function(
                new_project_test)
            argument_test = []
            result_test = []
            for index in range(len(src_churn_test)):
                argument_test.append([])
            for index in range(len(src_churn_test)):
                argument_test[index].append(src_churn_test[index])
                argument_test[index].append(file_churn_test[index])
                argument_test[index].append(test_churn_test[index])
                argument_test[index].append(test_density_test[index])
                argument_test[index].append(project_size_test[index])
                argument_test[index].append(project_age_test[index])
                # argument_test[index].append(team_size_test[index])
                argument_test[index].append(git_num_all_built_commits_test[index])

            X_test = np.array(argument_test)
            Y_test = np.array(build_result_test)
            num_test = len(Y_test)
            # print(Y_test)
            # print(build_result_test)
            X_test = X_test.reshape((int(len(X_test)), num_feature))
            # Y_result = (predictor.predict(X_test))

            new_build = X_test[0]
            flag = 0
            line = 0
            file = 0
            test = 0
            commit = 0
            results = []
            fail = 1
            # print(X_test)

            for index in range(len(X_test)):
                # print(new_build)
                if fail == 0:
                    # print('last build is fail')
                    num_build = num_build + 1
                    results.append(Y_test[index])
                    fail = Y_test[index]
                    # print('fail:' + str(fail))
                    new_build = X_test[index]
                    # print(new_build)
                    X_train = X_train.tolist()
                    X_train.append(new_build)
                    Y_train = Y_train.tolist()
                    Y_train.append(Y_test[index])
                    X_train = np.array(X_train)
                    Y_train = np.array(Y_train)
                    # print(X_train)
                    X_train = X_train.reshape((int(len(X_train)), num_feature))
                    rf = RandomForestClassifier(class_weight={0:ratio,1:1})  # 这里使用了默认的参数设置
                    predictor = rf.fit(X_train, Y_train)
                else:
                    if index == 0:
                        # print('start')
                        new_build = new_build.reshape((1, num_feature))

                        new_result = predictor.predict(new_build)
                        # print(New_build[0][0])
                        if new_result[0] == 1:
                            flag = 0
                            line = line + new_build[0][0]
                            file = file + new_build[0][1]
                            test = test + new_build[0][2]
                            commit = commit + new_build[0][6]
                            fail = 1
                        else:
                            flag = 1
                            num_build = num_build + 1
                            X_train = X_train.tolist()
                            X_train.append(new_build[0])
                            Y_train = Y_train.tolist()
                            Y_train.append(Y_test[index])
                            X_train = np.array(X_train)
                            Y_train = np.array(Y_train)
                            X_train = X_train.reshape((int(len(X_train)), num_feature))
                            rf = RandomForestClassifier(class_weight={0:ratio,1:1})  # 这里使用了默认的参数设置
                            predictor = rf.fit(X_train, Y_train)
                            fail = 0
                    if index != 0 and flag == 0:
                        # print('not start, old lines')
                        new_line = line + X_test[index][0]
                        new_file = file + X_test[index][1]
                        new_test = test + X_test[index][2]
                        new_commit = commit + X_test[index][6]
                        new_build = []
                        new_build.append(new_line)
                        new_build.append(new_file)
                        new_build.append(new_test)
                        new_build.append(X_test[index][3])
                        new_build.append(X_test[index][4])
                        new_build.append(X_test[index][5])
                        new_build.append(new_commit)
                        new_build = np.array(new_build)

                        # new_build = X_test[index]

                        new_build = new_build.reshape((1, num_feature))

                        new_result = predictor.predict(new_build)
                        if new_result[0] == 1:
                            flag = 0
                            line = new_build[0][0]
                            file = new_build[0][1]
                            test = new_build[0][2]
                            commit = new_build[0][6]
                            fail = 1
                        else:
                            flag = 1
                            num_build = num_build + 1
                            X_train = X_train.tolist()
                            X_train.append(new_build[0])
                            Y_train = Y_train.tolist()
                            Y_train.append(Y_test[index])
                            X_train = np.array(X_train)
                            Y_train = np.array(Y_train)
                            X_train = X_train.reshape((int(len(X_train)), num_feature))
                            rf = RandomForestClassifier(class_weight={0:ratio,1:1})  # 这里使用了默认的参数设置
                            predictor = rf.fit(X_train, Y_train)
                            fail = 0
                    elif index != 0 and flag == 1:
                        # print('not start, no old lines.')
                        new_build = X_test[index]
                        new_build = new_build.reshape((1, num_feature))
                        new_result = predictor.predict(new_build)

                        # print(predict_result)
                        # print(new_result)
                        if new_result[0] == 1:
                            flag = 0
                            line = new_build[0][0]
                            file = new_build[0][1]
                            test = new_build[0][2]
                            commit = new_build[0][6]
                            fail = 1
                        else:
                            flag = 1
                            num_build = num_build + 1
                            X_train = X_train.tolist()
                            X_train.append(new_build[0])
                            Y_train = Y_train.tolist()
                            Y_train.append(Y_test[index])
                            X_train = np.array(X_train)
                            Y_train = np.array(Y_train)
                            X_train = X_train.reshape((int(len(X_train)), num_feature))
                            rf = RandomForestClassifier(class_weight={0:ratio,1:1})  # 这里使用了默认的参数设置
                            predictor = rf.fit(X_train, Y_train)
                            fail = 0
                    # print(line)
                    results.append(new_result[0])
                # print('index: ' + str(index))
                # print(Y_test[index])
                # print(results[-1])
                # print(fail)
                # print(flag)
                # print(num_build)

            # print(results)
            for index in range(len(results)):
                if results[index] == 0 and Y_test[index] == 0:
                    yes = yes + 1
                if results[index] == 0:
                    more = more + 1
                if Y_test[index] == 0:
                    less = less + 1

            if less != 0:
                recall0 = yes / less
                if more == 0:
                    precision0 = 1
                    # recall.append(yes / less)
                else:
                    precision0 = yes / more
                    # recall.append(yes / less)
                precision.append(precision0)
                recall.append(recall0)
                build_save.append(1 - num_build / num_test)
                print(precision0)
                print(recall0)
                print(1 - num_build / num_test)

    #print(functions.get_median(precision))
    print(functions.get_median(recall))
    print(functions.get_median(build_save))
    a=functions.get_median(recall)
    b=functions.get_median(build_save)
    print(2*a*b/(a+b))

    book = xlwt.Workbook(encoding='utf-8', style_compression=0)
    sheet1 = book.add_sheet('test_line', cell_overwrite_ok=True)
    sheet2 = book.add_sheet('test_case', cell_overwrite_ok=True)
    sheet3 = book.add_sheet('assert_case', cell_overwrite_ok=True)

    for index in range(len(precision)):
        sheet1.write(index, 1, precision[index])
        sheet2.write(index, 1, recall[index])
        sheet3.write(index, 1, build_save[index])
    bookname='cross_project_performance'+str(int(threshold*10))+'.xls'

    #book.save(bookname)
