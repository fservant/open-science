import csv
import os
import sys
sys.path.insert(0, '/Users/jinxianhao/Desktop/folder/')
import functions
import time


file_names=functions.eachFile("/Users/jinxianhao/Documents/src/python/CI/Data_Base/esem_dataset/")
print(file_names)
if '.DS_Store' in file_names:
    print('yes')
selected_projects=[]
#file_names=['dozer.csv']
for nameindex in range(len(file_names)):

    file_name = file_names[nameindex]

    if file_name.split('.')[1]=='csv':
        print(file_name)
        string = "/Users/jinxianhao/Documents/src/python/CI/Data_Base/esem_dataset/" + file_name

        csv_file = csv.reader(open(string, 'r'))
        pre = []
        final = []
        for item in csv_file:
            pre.append(item)

        for i in range(len(pre[0])):
            temp = []
            for index in range(1, len(pre)):
                # print(index)
                # print(pre[index][i])
                temp.append(pre[index][i])
            final.append(temp)

        if len(final[0]) >= 200:
            project_size = []
            for item in final[25]:
                project_size.append(float(item))

            if functions.get_median(project_size) > 1000:
                if functions.timestamp(final[35][-1]) - functions.timestamp(final[35][0]) > 31536000:
                    selected_projects.append(file_name)


print((selected_projects))



