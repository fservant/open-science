import csv
import numpy as np
import xlwt
import math
from sklearn.model_selection import KFold
from sklearn.ensemble import RandomForestClassifier

def get_median(data):
    data = sorted(data)
    size = len(data)
    if size % 2 == 0:  # 判断列表长度为偶数
        median = (data[size // 2] + data[size // 2 - 1]) / 2
        data[0] = median
    if size % 2 == 1:  # 判断列表长度为奇数
        median = data[(size - 1) // 2]
        data[0] = median
    return data[0]
yess=0
precision=[]
recall=[]
f_score=[]
no_projects=[]
build_remain=[]
project_names=['jackson-core.csv', 'go-lang-idea-plugin.csv', 'jphp.csv', 'rultor.csv', 'AsciidocFX.csv', 'vraptor4.csv', 'geoserver.csv', 'core.csv', 'jodd.csv', 'airlift.csv', 'redpen.csv', 'querydsl.csv', 'pdfsam.csv', 'jOOQ.csv', 'gradle.csv', 'checkstyle.csv', 'deeplearning4j.csv', 'lenskit.csv', 'zxing.csv', 'jcabi-github.csv', 'tajo.csv', 'JRAW.csv', 'flink.csv', 'mockito.csv', 'p6spy.csv', 'jackson-databind.csv', 'javaslang.csv', 'jedis.csv', 'intellij-haskforce.csv', 'blueflood.csv', 'morphia.csv', 'closure-compiler.csv', 'graylog2-server.csv', 'Achilles.csv', 'RoaringBitmap.csv', 'quickml.csv', 'HikariCP.csv']
#project_names=['jackson-core.csv']
thresholds=[0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1]

for threshold in thresholds:
    precision = []
    recall = []
    build_save = []
    for nameindex in range(len(project_names)):
        file_name = project_names[nameindex]
        # file_name = file_name.split("/")[1]
        print(file_name)

        string = "/Users/jinxianhao/Documents/src/python/CI/Data_Base/esem_dataset/" + file_name
        csv_file = csv.reader(open(string, 'r'))
        pre = []
        final = []
        for item in csv_file:
            pre.append(item)

        for i in range(len(pre[0])):
            temp = []
            for index in range(1, len(pre)):
                # print(index)
                # print(pre[index][i])
                temp.append(pre[index][i])
            final.append(temp)
        # print(len(final[33]))

        indices = []
        for index in range(len(final[33])):
            if final[33][index] == 'passed':
                indices.append(index)
            else:
                # if final[33][index - 1] == 'passed':
                indices.append(index)

        src_churn = []
        file_churn = []
        test_churn = []
        build_result = []
        team_size = []
        git_num_all_built_commits = []
        gh_num_commits_on_files_touched = []
        argument = []
        for index in indices:
            # '''
            tmp_line = 0
            tmp_file = 0
            tmp_test = 0
            tmp_commit = 0
            temp = index

            while (final[33][temp - 1] != 'passed'):
                temp = temp - 1
                if temp <= 0:
                    break
            # print(temp)

            for index1 in range(temp, index + 1):
                # print(float(final[23][index1]))
                tmp_line = tmp_line + float(final[14][index1])
                tmp_file = tmp_file + float(final[21][index1])
                tmp_test = tmp_test + float(final[15][index1])
                tmp_commit = tmp_commit + float(final[10][index1])

            src_churn.append(tmp_line)
            file_churn.append(tmp_file)
            test_churn.append(tmp_test)
            git_num_all_built_commits.append(tmp_commit)
            '''

            src_churn.append(float(final[14][index]))
            file_churn.append(float(final[21][index]))
            test_churn.append(float(final[15][index]))
            git_num_all_built_commits.append(float(final[10][index]))
            #gh_num_commits_on_files_touched.append(float(final[33][index]))
            #'''
            argument.append([])

        for item in indices:
            if final[33][item] == 'passed':
                build_result.append(1)
            else:
                build_result.append(0)

        # print((git_num_all_built_commits))
        # print(build_result)

        gaussian = []
        for index in range(len(build_result)):
            temp = 0
            if 0 not in build_result[0:index]:
                gaussian.append(temp)
            else:
                for index1 in range(len(build_result[0:index])):
                    if build_result[index1] == 0:
                        ft = index - index1
                        gscore = 1 / (3 * math.sqrt(2 * math.pi)) * math.exp(-ft * ft / 18)
                        temp = temp + gscore
                gaussian.append(int(temp * 100))

        last_status = []
        last_status.append(1)
        for index in range(len(build_result)):
            last_status.append(build_result[index - 1])

        for index in range(len(src_churn)):
            argument[index].append(src_churn[index])
            argument[index].append(file_churn[index])
            argument[index].append(test_churn[index])
            # argument[index].append(team_size[index])
            argument[index].append(git_num_all_built_commits[index])
            # argument[index].append(last_status[index])
            # argument[index].append(gh_num_commits_on_files_touched[index])
            # argument[index].append(gaussian[index])
        # print(sum(argument))
        # print(build_result)
        X = np.array(argument)
        Y = np.array(build_result)
        # print(Y)
        # print('aaaa')
        KF = KFold(n_splits=8)  # 建立4折交叉验证方法  查一下KFold函数的参数
        more = 0
        less = 0
        yes = 0
        num_feature = 4
        middle_failures = 0
        last_failures = 0

        num_build = 0
        num_test = 0

        for train_index, test_index in KF.split(X):
            # print("TRAIN:", train_index, "TEST:", test_index)
            X_train, X_test = X[train_index], X[test_index]
            Y_train, Y_test = Y[train_index], Y[test_index]
            # print(X_train, X_test)
            # print(Y_train, Y_test)
            # print(Y_test)
            X_train = X_train.reshape((int(len(X_train)), num_feature))
            rf = RandomForestClassifier()  # 这里使用了默认的参数设置
            predictor = rf.fit(X_train, Y_train)

            # print('aaaaaaaaaaaaaaaaa')
            # print(Y_test)
            new_build = X_test[0]
            flag = 0
            line = 0
            file = 0
            test = 0
            commit = 0
            results = []
            fail = 1
            # print(X_test)
            num_test = num_test + len(Y_test)
            for index in range(len(X_test)):
                if fail == 0:
                    num_build = num_build + 1
                    # new_result=0
                    results.append(Y_test[index])
                    fail = Y_test[index]
                    new_build = X_test[index]
                    # print(new_build)
                    X_train = X_train.tolist()
                    X_train.append(new_build)
                    Y_train = Y_train.tolist()
                    Y_train.append(Y_test[index])
                    X_train = np.array(X_train)
                    Y_train = np.array(Y_train)
                    # print(X_train)
                    X_train = X_train.reshape((int(len(X_train)), num_feature))
                    rf = RandomForestClassifier()  # 这里使用了默认的参数设置
                    predictor = rf.fit(X_train, Y_train)
                else:
                    if index == 0:
                        new_build = new_build.reshape((1, num_feature))
                        predict_result = predictor.predict_proba(new_build)
                        if predict_result[0][0] <= threshold:
                            new_result = [1]
                        else:
                            new_result = [0]
                        # print(New_build[0][0])
                        if new_result[0] == 1:
                            flag = 0
                            line = line + new_build[0][0]
                            file = file + new_build[0][1]
                            test = test + new_build[0][2]
                            commit = commit + new_build[0][3]
                            fail = 1
                        else:
                            num_build = num_build + 1
                            flag = 1
                            X_train = X_train.tolist()
                            X_train.append(new_build[0])
                            Y_train = Y_train.tolist()
                            Y_train.append(Y_test[index])
                            X_train = np.array(X_train)
                            Y_train = np.array(Y_train)
                            X_train = X_train.reshape((int(len(X_train)), num_feature))
                            rf = RandomForestClassifier()  # 这里使用了默认的参数设置
                            predictor = rf.fit(X_train, Y_train)
                            fail = 0
                    if index != 0 and flag == 0:
                        new_line = line + X_test[index][0]
                        new_file = file + X_test[index][1]
                        new_test = test + X_test[index][2]
                        new_commit = commit + X_test[index][3]
                        new_build = []
                        new_build.append(new_line)
                        new_build.append(new_file)
                        new_build.append(new_test)
                        new_build.append(new_commit)
                        new_build = np.array(new_build)

                        # new_build = X_test[index]

                        new_build = new_build.reshape((1, num_feature))
                        predict_result = predictor.predict_proba(new_build)
                        if predict_result[0][0] <= threshold:
                            new_result = [1]
                        else:
                            new_result = [0]
                        if new_result[0] == 1:
                            flag = 0
                            line = new_build[0][0]
                            file = new_build[0][1]
                            test = new_build[0][2]
                            commit = new_build[0][3]
                            fail = 1
                        else:
                            num_build = num_build + 1
                            flag = 1
                            X_train = X_train.tolist()
                            X_train.append(new_build[0])
                            Y_train = Y_train.tolist()
                            Y_train.append(Y_test[index])
                            X_train = np.array(X_train)
                            Y_train = np.array(Y_train)
                            X_train = X_train.reshape((int(len(X_train)), num_feature))
                            rf = RandomForestClassifier()  # 这里使用了默认的参数设置
                            predictor = rf.fit(X_train, Y_train)
                            fail = 0
                    elif index != 0 and flag == 1:
                        new_build = X_test[index]
                        new_build = new_build.reshape((1, num_feature))
                        predict_result = predictor.predict_proba(new_build)
                        if predict_result[0][0] <= threshold:
                            new_result = [1]
                        else:
                            new_result = [0]
                        if new_result[0] == 1:
                            flag = 0
                            line = new_build[0][0]
                            file = new_build[0][1]
                            test = new_build[0][2]
                            commit = new_build[0][3]
                            fail = 1
                        else:
                            num_build = num_build + 1
                            flag = 1
                            X_train = X_train.tolist()
                            X_train.append(new_build[0])
                            Y_train = Y_train.tolist()
                            Y_train.append(Y_test[index])
                            X_train = np.array(X_train)
                            Y_train = np.array(Y_train)
                            X_train = X_train.reshape((int(len(X_train)), num_feature))
                            rf = RandomForestClassifier()  # 这里使用了默认的参数设置
                            predictor = rf.fit(X_train, Y_train)
                            fail = 0
                    # print(line)
                    results.append(new_result[0])
            # print(results)
            for index in range(len(results)):
                if results[index] == 0 and Y_test[index] == 0:
                    yes = yes + 1
                if results[index] == 0:
                    more = more + 1
                if Y_test[index] == 0:
                    less = less + 1

        if less != 0:
            recall0 = yes / less
            if more == 0:
                precision0 = 1
                # recall.append(yes / less)
            else:
                precision0 = yes / more
                # recall.append(yes / less)
            precision.append(precision0)
            recall.append(recall0)
            build_save.append(1 - num_build / num_test)
            print(precision0)
            print(recall0)
            print(1 - num_build / num_test)

    print(get_median(precision))
    print(get_median(recall))
    print(get_median(build_save))

    book = xlwt.Workbook(encoding='utf-8', style_compression=0)
    sheet1 = book.add_sheet('test_line', cell_overwrite_ok=True)
    sheet2 = book.add_sheet('test_case', cell_overwrite_ok=True)
    sheet3 = book.add_sheet('assert_case', cell_overwrite_ok=True)

    for index in range(len(precision)):
        sheet1.write(index, 1, precision[index])
        sheet2.write(index, 1, recall[index])
        sheet3.write(index, 1, build_save[index])
    bookname = 'wihtin_project_performance' + str(int(threshold * 10)) + '.xls'

    book.save(bookname)











