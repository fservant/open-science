import csv
import numpy as np
import xlwt
import math
from sklearn.model_selection import KFold
from sklearn.ensemble import RandomForestClassifier

project_names=['rails/rails', 'myronmarston/vcr', 'concerto/concerto', 'benhoskings/babushka', 'rubinius/rubinius', 'rubychan/coderay', 'codeforamerica/adopt-a-hydrant', 'radiant/radiant', 'saberma/shopqi', 'rspec/rspec-core', 'engineyard/engineyard', 'plataformatec/devise', 'rspec/rspec-rails', 'karmi/retire', 'sferik/rails_admin', 'tdiary/tdiary-core', 'dkubb/veritas', 'sstephenson/sprockets', 'thoughtbot/factory_girl', 'weppos/whois', 'errbit/errbit', 'padrino/padrino-framework', 'thoughtbot/paperclip', 'plataformatec/simple_form', 'huerlisi/bookyt', 'hotsh/rstat.us', 'mperham/dalli', 'innoq/iqvoc', 'cheezy/page-object', 'justinfrench/formtastic', 'nov/fb_graph', 'assaf/vanity', 'activerecord-hackery/ransack', 'jimweirich/rake', 'rspec/rspec-mocks', 'neo4jrb/neo4j', 'diaspora/diaspora', 'test-unit/test-unit', 'Shopify/liquid', 'activeadmin/activeadmin', 'ari/jobsworth', 'thoughtbot/shoulda-matchers', 'rubygems/rubygems', 'rdoc/rdoc', 'spree/spree', 'rubyzip/rubyzip', 'pry/pry', 'jruby/activerecord-jdbc-adapter', 'sass/sass', 'jruby/warbler', 'fatfreecrm/fat_free_crm', 'rspec/rspec-expectations', 'excon/excon', 'typus/typus', 'heroku/heroku', 'nahi/httpclient', 'podio/podio-rb', 'maxdemarzi/neography', 'locomotivecms/engine', 'gedankenstuecke/snpr', 'peter-murach/github', 'jnicklas/capybara', 'travis-ci/travis-core', 'presidentbeef/brakeman', 'mikel/mail', 'randym/axlsx', 'kmuto/review', 'danielweinmann/catarse', 'middleman/middleman', 'rubyworks/facets', 'railsbp/rails_best_practices', 'comfy/comfortable-mexican-sofa', 'mongoid/moped', 'wr0ngway/rubber', 'rslifka/elasticity', 'lsegal/yard', 'NoamB/sorcery', 'puppetlabs/puppet', 'mitchellh/vagrant', 'ai/r18n', 'celluloid/celluloid', 'jordansissel/fpm', 'neo4jrb/neo4j-core', 'orbeon/orbeon-forms', 'redis/redis-rb', 'pivotal/pivotal_workstation', 'jruby/jruby', 'louismullie/treat', 'puma/puma', 'pophealth/popHealth', 'twitter/twitter-cldr-rb', 'gistflow/gistflow', 'adamfisk/LittleProxy', 'awestruct/awestruct', 'jnunemaker/httparty', 'Graylog2/graylog2-server', 'neuland/jade4j', 'sensu/sensu', 'shawn42/gamebox', 'applicationsonline/librarian', 'haml/haml', 'sporkmonger/addressable', 'google/google-api-ruby-client', 'elm-city-craftworks/practicing-ruby-web', 'sunlightlabs/scout', 'floere/phony', 'data-axle/cassandra_object', 'typhoeus/typhoeus', 'shoes/shoes4', 'troessner/reek', 'recurly/recurly-client-ruby', 'CloudifySource/cloudify', 'puppetlabs/puppetlabs-firewall', 'typhoeus/ethon', 'sparklemotion/nokogiri', 'tinkerpop/blueprints', 'tinkerpop/rexster', 'thinkaurelius/titan', 'openSUSE/open-build-service', 'engineyard/ey-cloud-recipes', 'git/git-scm.com', 'honeybadger-io/honeybadger-ruby', 'azagniotov/stubby4j', 'sferik/twitter', 'calagator/calagator', 'openshift/rhc', 'codefirst/AsakusaSatellite', 'DatabaseCleaner/database_cleaner', 'burke/zeus', 'fog/fog', 'twilio/twilio-java', 'twitter/commons', 'Albacore/albacore', 'prawnpdf/prawn', 'enspiral/loomio', 'refinery/refinerycms', 'sevntu-checkstyle/sevntu.checkstyle', 'opal/opal', 'graphhopper/graphhopper', 'sparklemotion/mechanize', 'SomMeri/less4j', 'tent/tentd', 'searchbox-io/Jest', 'square/dagger', 'google/truth', 'square/okhttp', 'square/retrofit', 'maxcom/lorsource', 'jneen/rouge', 'jmkgreen/morphia', 'SpontaneousCMS/spontaneous', 'everzet/capifony', 'killbill/killbill', 'scobal/seyren', 'intuit/simple_deploy', 'projectblacklight/blacklight', 'rapid7/metasploit-framework', 'amahi/platform', 'vcr/vcr', 'Findwise/Hydra', 'structr/structr', 'sachin-handiekar/jInstagram', 'nutzam/nutz', 'slim-template/slim', 'puppetlabs/puppetlabs-stdlib', 'puppetlabs/facter', 'phoet/on_ruby', 'dreamhead/moco', 'travis-ci/travis.rb', 'cloudfoundry/cloud_controller_ng', 'square/assertj-android', 'jmxtrans/jmxtrans', 'twitter/secureheaders', 'nanoc/nanoc', 'expertiza/expertiza', 'asciidoctor/asciidoctor', 'rubber/rubber', 'openMF/mifosx', 'mybatis/mybatis-3', 'test-kitchen/test-kitchen', 'owlcs/owlapi', 'engineyard/engineyard-serverside', 'selendroid/selendroid', 'ruboto/ruboto', 'openfoodfoundation/openfoodnetwork', 'stephanenicolas/robospice', 'joscha/play-authenticate', 'undera/jmeter-plugins', 'cantino/huginn', 'resque/resque', 'albertlatacz/java-repl', 'l0rdn1kk0n/wicket-bootstrap', 'dynjs/dynjs', 'abarisain/dmix', 'dropwizard/dropwizard', 'dropwizard/metrics', 'jberkel/sms-backup-plus', 'rubymotion/sugarcube', 'naver/yobi', 'Shopify/active_shipping', 'projecthydra/sufia', 'rubymotion/BubbleWrap', 'pivotal-sprout/sprout-osx-apps', 'chef/omnibus', 'JodaOrg/joda-time', 'EmmanuelOga/ffaker', 'kostya/eye', 'laurentpetit/ccw', 'puniverse/quasar', 'simpligility/android-maven-plugin', 'jsonld-java/jsonld-java', 'travis-ci/travis-cookbooks', 'FenixEdu/fenixedu-academic', 'threerings/playn', 'restlet/restlet-framework-java', 'jedi4ever/veewee', 'sensu/sensu-community-plugins', 'OpenRefine/OpenRefine', 'chef/chef', 'fluent/fluentd', 'perwendel/spark', 'joelittlejohn/jsonschema2pojo', 'jOOQ/jOOQ', 'springside/springside4', 'github/hub', 'johncarl81/parceler', 'discourse/onebox', 'julianhyde/optiq', 'ruby-ldap/ruby-net-ldap', 'DSpace/DSpace', 'jeremyevans/sequel', 'bikeindex/bike_index', 'doanduyhai/Achilles', 'rackerlabs/blueflood', 'rodjek/librarian-puppet', 'p6spy/p6spy', 'square/wire', 'Nodeclipse/nodeclipse-1', 'rebelidealist/stripe-ruby-mock', 'checkstyle/checkstyle', 'elastic/logstash', 'airlift/airlift', 'lenskit/lenskit', 'MiniProfiler/rack-mini-profiler', 'geoserver/geoserver', 'ocpsoft/rewrite', 'Unidata/thredds', 'torakiki/pdfsam', 'loopj/android-async-http', 'feedbin/feedbin', 'recruit-tech/redpen', 'brettwooldridge/HikariCP', 'puppetlabs/marionette-collective', 'iipc/openwayback', 'caelum/vraptor4', 'dianping/cat', 'jphp-compiler/jphp', 'mockito/mockito', 'oblac/jodd', 'facebook/buck', 'facebook/presto', 'jpos/jPOS', 'hamstergem/hamster', 'mongodb/morphia', 'realestate-com-au/pact', 'inaturalist/inaturalist', 'jtwig/jtwig', 'go-lang-plugin-org/go-lang-idea-plugin', 'square/picasso', 'voltrb/volt', 'zxing/zxing', 'openaustralia/morph', 'GlowstoneMC/Glowstone', 'owncloud/android', 'JakeWharton/u2020', 'rpush/rpush', 'OneBusAway/onebusaway-android', 'rabbit-shocker/rabbit', 'azkaban/azkaban', 'relayrides/pushy', 'deeplearning4j/deeplearning4j', 'github/developer.github.com', 'xetorthio/jedis', 'FasterXML/jackson-core', 'FasterXML/jackson-databind', 'protostuff/protostuff', 'atmos/heaven', 'MrTJP/ProjectRed', 'lemire/RoaringBitmap', 'apache/drill', 'Kapeli/cheatsheets', 'gradle/gradle', 'OpenGrok/OpenGrok', 'spring-io/sagan', 'mendhak/gpslogger', 'thoughtbot/hound', 'teamed/qulice', 'jcabi/jcabi-aspects', 'jcabi/jcabi-github', 'jcabi/jcabi-http', 'yegor256/rultor', 'querydsl/querydsl', 'codevise/pageflow', 'grails/grails-core', 'weld/core', 'thatJavaNerd/JRAW', 'bndtools/bnd', 'igniterealtime/Openfire', 'zendesk/samson', 'bndtools/bndtools', 'xtreemfs/xtreemfs', 'puniverse/capsule', 'broadinstitute/picard', 'github/github-services', 'gavinlaking/vedeu', 'haiwen/seadroid', 'AChep/AcDisplay', 'GoClipse/goclipse', 'hsz/idea-gitignore', 'jsprit/jsprit', 'dblock/waffle', 'numenta/htm.java', 'rightscale/praxis', 'google/error-prone', 'datastax/ruby-driver', 'iluwatar/java-design-patterns', 'Netflix/Hystrix', 'oyachai/HearthSim', 'jayway/JsonPath', 'exteso/alf.io', 'spring-cloud/spring-cloud-config', 'validator/validator', 'HubSpot/jinjava', 'connectbot/connectbot', 'google/physical-web', 'myui/hivemall', 'MarkUsProject/Markus', 'jMonkeyEngine/jmonkeyengine', 'davidmoten/rxjava-jdbc', 'qos-ch/logback', 'Homebrew/homebrew-science', 'GoogleCloudPlatform/DataflowJavaSDK', 'SoftInstigate/restheart', 'naver/pinpoint', 'KronicDeth/intellij-elixir', 'embulk/embulk', 'loomio/loomio', 'openstreetmap/openstreetmap-website', 'activescaffold/active_scaffold', 'tananaev/traccar', 'SonarSource/sonarqube', 'grpc/grpc-java', 'psi-probe/psi-probe', 'orientation/orientation', 'square/keywhiz', 'aws/aws-sdk-java', 'Shopify/shipit-engine', 'perfectsense/brightspot-cms', 'jamesagnew/hapi-fhir']
all_project_age=[60.99788811728395, 42.868221450617284, 56.12528202160494, 47.38550077160494, 60.89705787037037, 58.04270524691358, 47.97162538580247, 39.43006172839506, 16.51641049382716, 60.90738695987654, 58.845846064814815, 60.44828703703703, 60.784233410493826, 25.959506172839507, 60.65283410493827, 60.88418711419753, 19.451444444444444, 43.04281944444445, 60.23046875, 60.91941666666666, 60.945159336419756, 60.88944637345679, 60.910814043209875, 60.75280015432099, 60.883915895061726, 38.06781288580247, 47.86834645061728, 58.839470679012344, 58.33825810185185, 57.8269537037037, 52.96799652777778, 58.61927199074074, 60.82560069444445, 39.30659297839506, 60.700752314814814, 60.78509452160494, 60.659984953703706, 59.82352662037037, 60.06336844135802, 59.15326350308642, 58.4342550154321, 58.18469560185185, 60.237319444444445, 59.89075925925926, 60.254800540123455, 55.31189969135802, 60.021097222222224, 54.19930902777778, 57.831628086419755, 57.95704899691358, 60.006391975308645, 58.52207060185185, 59.44461111111111, 43.26081057098765, 59.48896219135803, 59.39457137345679, 59.20439313271605, 57.95658294753086, 58.65800347222222, 46.04024421296296, 46.013713348765435, 58.68047762345679, 57.627726080246916, 58.29785918209877, 52.95464390432099, 51.74549112654321, 57.37794367283951, 14.453299382716049, 57.1007700617284, 53.271368055555556, 55.32124421296297, 52.05723649691358, 43.529069444444445, 36.7667650462963, 49.225259645061726, 55.526749614197534, 55.006963734567904, 53.90801890432099, 54.56425270061728, 51.86058526234568, 53.30700810185185, 54.26936226851852, 53.59927893518518, 54.370530864197534, 52.85917168209877, 25.43996412037037, 54.36261844135802, 37.16625810185185, 53.49630902777778, 28.66893325617284, 53.42397453703704, 28.72929513888889, 52.68950385802469, 48.20410995370371, 53.015060185185185, 53.27285686728395, 51.30186535493827, 52.570462191358025, 33.83810918209876, 25.024305169753088, 51.88496797839506, 45.57232445987654, 52.44772800925926, 46.33488310185185, 34.77926851851852, 52.22533410493827, 26.196630401234568, 51.46207677469136, 49.489141589506175, 51.868130401234566, 51.39140663580247, 26.961281635802468, 48.6703962191358, 48.860492669753086, 48.44385300925926, 44.0894174382716, 44.08912847222222, 24.933184027777777, 51.03551041666667, 51.033578703703704, 50.799975308641976, 50.75948804012346, 40.67418055555556, 50.10126813271605, 48.93948186728395, 48.76311805555556, 34.21816936728395, 47.743108410493825, 33.77389197530864, 47.093836805555554, 46.99011612654321, 48.36900848765432, 34.424694058641975, 48.469902777777776, 18.663188657407407, 48.09868634259259, 47.51554359567901, 48.06388464506173, 48.15943711419753, 47.83862075617284, 42.562489969135804, 12.432195601851852, 47.66237345679012, 43.77555864197531, 47.46832060185185, 47.41583101851852, 47.178567901234565, 47.32070023148148, 47.07954591049383, 33.15620563271605, 43.660050154320984, 30.775845679012345, 46.25623919753087, 46.43838541666667, 23.170719907407406, 46.561822916666664, 46.42623070987654, 36.76309992283951, 42.868221450617284, 23.105463348765433, 32.6021824845679, 44.09510763888889, 44.74747723765432, 44.01591859567901, 42.333927854938274, 44.45114429012346, 44.39661959876543, 35.67860802469136, 39.34556365740741, 31.170439043209875, 39.08877276234568, 42.89688348765432, 43.423280478395064, 43.72543711419753, 43.722099922839504, 43.585711805555555, 36.7667650462963, 35.63576427469136, 42.82634066358025, 43.09385918209877, 42.23184645061728, 42.6890212191358, 40.08030709876543, 41.1078587962963, 42.792724151234566, 19.804082947530866, 40.75303780864198, 40.62701311728395, 28.943190586419753, 41.348618055555555, 34.81962962962963, 41.52046682098766, 38.76906134259259, 35.7932137345679, 41.32337808641975, 39.86753973765432, 39.651275462962964, 40.2630212191358, 34.39949074074074, 40.44909452160494, 41.057862654320985, 30.885082175925927, 37.56645100308642, 27.87531674382716, 40.24755362654321, 26.12271836419753, 31.698124614197532, 38.72930902777778, 39.79056057098765, 38.83317399691358, 40.00625077160494, 39.83346759259259, 39.83037847222222, 29.33731597222222, 34.86043904320988, 35.62693325617284, 30.103962577160495, 36.58764814814815, 26.53098302469136, 39.00409992283951, 38.772607638888886, 38.56100655864198, 32.03689390432099, 18.31864776234568, 37.96038348765432, 36.49455594135802, 37.578162422839505, 15.330040895061728, 25.03303549382716, 37.65068287037037, 37.70125347222222, 37.0254949845679, 36.98812422839506, 36.89062692901235, 31.061488425925926, 36.816104552469135, 36.07600154320988, 29.338535879629628, 36.195125771604935, 23.27287885802469, 35.869599922839505, 35.73228125, 34.563684027777775, 34.43489351851852, 35.59679899691358, 35.359732638888886, 35.23294328703704, 35.47253549382716, 29.785729166666666, 35.19286805555556, 22.532131944444444, 21.96384760802469, 34.60375038580247, 30.271081404320988, 21.87336651234568, 33.983266975308645, 34.77709104938272, 34.573242669753085, 34.33634375, 34.37039660493827, 21.291534722222224, 34.232231481481485, 25.317443287037037, 33.15620563271605, 31.197810956790125, 33.11556481481482, 14.701507716049383, 21.412851080246913, 31.35664737654321, 24.247436728395062, 31.81514236111111, 31.82590547839506, 14.67307214506173, 30.773743055555556, 31.317722222222223, 27.214613811728395, 31.381449074074073, 31.054349922839506, 30.886480709876544, 30.759721064814816, 24.48322299382716, 17.964171296296296, 30.572416280864196, 30.83145138888889, 30.775027006172838, 28.04486574074074, 29.727409722222223, 29.964091435185185, 17.37188850308642, 30.301457175925925, 30.332603395061728, 23.545707175925926, 30.337702932098765, 28.976699459876542, 29.067121913580248, 14.26640162037037, 29.096081404320987, 29.091498456790124, 29.095640817901234, 29.08987538580247, 28.657476080246912, 28.433782021604937, 15.036159722222223, 28.06875115740741, 27.93230825617284, 27.793526234567903, 14.601501543209876, 27.11203665123457, 27.54011265432099, 14.457883101851852, 26.95807561728395, 26.388434799382715, 13.530038194444444, 22.542483410493826, 23.9220887345679, 25.63091975308642, 23.364632330246913, 24.769520833333335, 24.10303125, 12.298489969135803, 24.656851466049382, 24.644858796296297, 24.35935609567901, 24.664117669753086, 24.437304398148147, 24.397274305555555, 24.274322145061728, 12.258020061728395, 21.938689814814815, 23.532486111111112, 23.15061111111111, 23.05472839506173, 21.449680941358025, 22.035605709876542, 22.394292824074075, 20.82385300925926, 22.009229938271606, 21.608474922839505, 21.708291666666668, 17.40260648148148, 20.252540895061728, 19.554871913580246, 18.755581790123458, 19.30111612654321, 18.98716975308642, 18.132243441358025, 18.663188657407407, 18.262356095679014, 18.361248070987653, 18.251556712962962, 17.762991898148147, 17.667185570987655, 17.434983410493828, 16.742409336419755, 17.298449074074075, 15.90389737654321, 15.381609953703704, 13.467878858024692, 14.577877314814815]
all_project_size=[53819.0, 3033.0, 5167.0, 5289.0, 415786.0, 9680.0, 13826.0, 10610.0, 9928.5, 5052.5, 4460.0, 3230.0, 1872.0, 2527.0, 4626.0, 18435.0, 3036.0, 2395.0, 1587.0, 11103.0, 3225.5, 7700.0, 3159.0, 1751.0, 4789.0, 2105.0, 1331.5, 4506.0, 5795.0, 2723.5, 4044.0, 2363.0, 2619.0, 3596.0, 3154.0, 3600.0, 16739.0, 6524.0, 2328.0, 6354.0, 15153.0, 3503.5, 17088.0, 16547.5, 12032.0, 2859.0, 6565.0, 7132.0, 11448.0, 7685.0, 8486.0, 3174.0, 1864.0, 3483.0, 6048.0, 4596.5, 4365.5, 2455.0, 9812.5, 4714.0, 4198.0, 6329.0, 10569.0, 11928.0, 16856.0, 5182.0, 9429.0, 5184.0, 7116.0, 21429.0, 3182.0, 5484.0, 2405.0, 8453.0, 3032.0, 14359.0, 2436.0, 84443.0, 26106.0, 2552.0, 2694.0, 2115.0, 2919.0, 56972.0, 2970.0, 2373.0, 148743.0, 5421.0, 3348.0, 1776.0, 4556.0, 2556.0, 3390.0, 3921.0, 1563.0, 60167.0, 5377.0, 2560.0, 7774.0, 3379.5, 2744.0, 2367.5, 3084.0, 2288.0, 5189.0, 11108.0, 1445.0, 1098.0, 11721.0, 3067.0, 2093.0, 46692.0, 1790.0, 1830.0, 12037.0, 16161.0, 11257.5, 18190.0, 29143.0, 2954.0, 1838.0, 2997.0, 3568.0, 2529.5, 4073.0, 8892.0, 2892.0, 1783.0, 696.0, 125772.0, 8892.0, 26549.0, 3011.0, 8476.0, 19970.5, 6976.0, 6748.0, 19234.0, 27416.0, 4483.0, 19930.0, 4450.0, 4468.0, 3695.0, 2536.0, 15686.0, 3246.0, 23560.5, 10439.0, 12399.0, 16177.0, 1554.0, 63403.0, 3732.0, 2286.0, 6279.0, 598803.5, 5133.0, 3033.0, 13181.0, 59020.0, 3329.0, 48791.0, 1552.0, 3095.0, 5761.0, 2262.0, 5998.0, 3426.0, 13728.0, 18617.0, 6268.0, 1558.0, 6776.5, 27297.0, 8895.0, 8453.0, 51859.0, 18886.0, 4840.0, 121745.0, 7162.5, 26310.0, 3323.0, 25745.0, 7095.0, 5856.0, 28265.0, 7629.0, 2024.0, 2993.0, 13655.0, 25041.0, 22162.0, 12060.5, 7605.0, 6632.0, 6956.0, 7798.0, 4984.0, 6618.0, 3213.0, 3314.0, 4682.5, 30169.0, 3672.0, 4242.0, 10577.0, 35792.5, 15339.0, 6482.0, 8597.0, 320895.0, 32317.0, 122503.0, 14989.0, 15015.0, 44909.0, 49633.5, 9737.0, 4193.5, 3826.0, 98041.0, 8611.0, 699.0, 4577.0, 2068.0, 95265.0, 2464.0, 210877.0, 31415.0, 9899.0, 17358.0, 16185.0, 1197.0, 4120.0, 6434.0, 92286.5, 2408.0, 28991.0, 11456.0, 24578.0, 27541.0, 1749.0, 303998.0, 29431.0, 429028.0, 9755.0, 4934.0, 7444.0, 4729.0, 2296.0, 12567.0, 34716.0, 11214.0, 65988.0, 59233.0, 33268.0, 82611.5, 197810.5, 149663.0, 43503.0, 15402.0, 12399.0, 5825.0, 50757.0, 7118.0, 38405.0, 4615.0, 6658.0, 34688.0, 4561.0, 21968.0, 27970.0, 5857.0, 3950.0, 23655.0, 27697.0, 26612.5, 1402.0, 41251.0, 2140.0, 12640.0, 18237.0, 50343.0, 46324.0, 2565.0, 9634.0, 6695.5, 187386.0, 28421.0, 167848.0, 31402.0, 11458.0, 7802.0, 2475.0, 3765.0, 2370.0, 15359.5, 3178.0, 5530.0, 48110.0, 5153.0, 62271.0, 55502.0, 6403.0, 71235.0, 197546.0, 9471.0, 40734.0, 157570.0, 4825.5, 25958.0, 8628.0, 18305.0, 21749.0, 21248.0, 37444.0, 4427.0, 17544.0, 5786.0, 14740.0, 4157.0, 20796.0, 11046.0, 8725.0, 13000.0, 25357.0, 4604.5, 7942.0, 3532.0, 33077.0, 8998.0, 15279.0, 2059.5, 21994.0, 20245.0, 207832.0, 3281.0, 29163.0, 21412.0, 56485.5, 11518.5, 101107.0, 32303.0, 10462.5, 19970.5, 12181.0, 9288.0, 18196.0, 155481.0, 35640.0, 13811.0, 1447.0, 8163.0, 1033909.0, 3724.0, 35716.0, 533998.0]
all_team_size=[221.0, 10.0, 18.0, 3.0, 43.0, 3.0, 4.0, 8.0, 0.0, 22.0, 11.0, 22.0, 19.0, 0.0, 24.0, 8.0, 1.0, 5.0, 13.0, 2.0, 13.0, 20.0, 26.0, 21.0, 4.0, 13.0, 5.0, 5.0, 4.0, 10.0, 1.0, 6.0, 13.0, 5.0, 16.0, 11.0, 38.0, 2.0, 24.0, 19.0, 5.0, 25.0, 32.0, 7.0, 49.0, 6.0, 20.0, 11.0, 6.0, 5.0, 8.0, 18.0, 6.0, 5.0, 34.0, 3.0, 8.0, 5.0, 9.0, 6.0, 7.0, 12.0, 20.0, 8.0, 10.0, 7.0, 8.0, 7.0, 13.0, 4.0, 7.0, 10.0, 10.0, 9.0, 3.0, 2.0, 7.0, 93.0, 51.0, 2.0, 13.0, 2.0, 7.0, 2.0, 9.0, 12.0, 39.0, 2.0, 6.0, 17.0, 6.0, 2.0, 8.0, 7.0, 6.0, 12.0, 2.0, 7.0, 2.0, 1.0, 8.0, 5.0, 8.0, 5.0, 1.0, 11.0, 4.0, 7.0, 16.0, 12.0, 15.0, 17.0, 20.0, 4.0, 16.0, 11.0, 5.0, 7.0, 20.0, 13.0, 5.0, 7.0, 2.0, 8.0, 11.0, 15.0, 9.0, 4.0, 11.0, 87.0, 6.0, 14.5, 7.0, 16.0, 14.0, 21.0, 7.0, 16.0, 8.0, 7.0, 2.0, 5.0, 9.0, 14.0, 4.0, 18.0, 17.0, 5.0, 12.0, 4.0, 2.0, 5.0, 4.0, 6.0, 10.0, 13.0, 92.0, 6.0, 10.0, 8.0, 9.0, 5.0, 8.0, 7.0, 20.0, 46.0, 8.0, 3.0, 6.0, 72.0, 5.0, 12.0, 8.0, 5.0, 11.0, 5.0, 9.0, 28.0, 12.0, 24.0, 6.0, 16.0, 14.0, 5.0, 16.0, 4.0, 6.0, 10.0, 17.0, 11.0, 3.0, 9.0, 9.0, 7.0, 30.0, 14.0, 2.0, 10.0, 11.0, 33.0, 35.0, 16.0, 5.0, 8.0, 3.0, 7.0, 8.0, 4.0, 5.0, 8.0, 5.0, 21.0, 18.0, 5.0, 8.0, 13.0, 35.0, 5.0, 35.0, 12.0, 4.0, 6.0, 4.0, 1.0, 11.0, 2.0, 10.0, 5.0, 7.0, 34.0, 1.0, 3.0, 3.0, 26.0, 8.0, 5.0, 13.0, 2.0, 9.0, 18.0, 14.0, 11.0, 3.0, 5.0, 51.0, 5.0, 12.0, 2.0, 8.0, 3.0, 8.0, 8.0, 14.0, 10.0, 24.0, 12.0, 5.0, 13.0, 4.0, 46.0, 20.0, 8.0, 4.0, 4.0, 7.0, 9.0, 1.0, 11.0, 10.0, 18.0, 3.0, 8.0, 8.0, 24.0, 9.0, 9.0, 6.0, 5.0, 12.0, 4.0, 13.0, 32.0, 13.0, 3.0, 5.0, 4.0, 3.0, 4.0, 6.0, 16.0, 19.0, 40.0, 6.0, 8.0, 2.0, 38.0, 10.0, 7.0, 11.0, 4.0, 7.0, 10.0, 8.0, 15.0, 8.0, 4.0, 13.0, 15.0, 36.0, 10.0, 13.0, 4.0, 27.0, 17.0, 3.0, 8.0, 3.0, 2.0, 2.0, 3.0, 5.0, 5.0, 8.0, 8.0, 9.0, 9.0, 5.0, 4.0, 4.0, 4.0, 6.0, 3.0, 4.0, 5.0, 15.0, 2.0, 14.0, 9.0, 2.0, 3.0, 45.0, 20.0, 3.0, 17.0, 2.0, 6.0, 14.0, 3.0, 3.0, 5.0, 23.0, 17.0, 8.0, 3.0, 8.0, 8.0, 21.0, 23.0, 5.0]
all_test_density=[2170.36307188935, 1718.822746923845, 416.76561386844, 1061.95672276678, 411.759334683766, 141.322314049587, 22.170867335885, 638.306364182655, 738.51554663992, 1702.791664804805, 562.331838565022, 1900.327858137905, 1205.86666666667, 2476.17107942974, 1608.75, 199.930337861372, 2632.94117647059, 1298.55810008482, 2231.93473193473, 3839.00002533704, 1199.9450700357, 1388.85338105586, 2178.42437551469, 2402.89855072464, 330.258957076978, 1525.59241706161, 1338.79093198992, 324.152145400037, 805.6844600690424, 3448.64269992663, 1588.10297425644, 1187.97629127858, 673.93891312971, 1455.45722713864, 2270.67868504772, 1834.43546411952, 698.2689979977665, 884.273451870018, 1393.69550637156, 1019.28950329529, 645.349231081905, 1163.75545851528, 1210.45545018148, 1241.816073116975, 790.454208226857, 987.994350282486, 1147.032428149015, 976.000641515428, 1285.84691692703, 242.121644404098, 1331.92798541477, 2293.08783579837, 708.873643487786, 555.384606216895, 819.771981883492, 680.291648254529, 86.7020048095621, 1917.32729331823, 272.412085190688, 228.7582377973805, 2178.38405036726, 211.492797213867, 999.48275862069, 811.999236932469, 562.488574736457, 850.197294250282, 515.13868304044, 410.721026802567, 1.20918984280532, 446.026706508544, 2053.9845981326953, 602.925625660909, 1314.364801364265, 192.207202090197, 13.1842126559439, 870.817843866171, 1236.16089207487, 1257.37439222042, 517.702019227057, 644.706336939722, 494.729444834856, 413.456599897278, 924.155513065647, 35.2320639093252, 1286.53780942692, 12.9525074726005, 2605.95545513234, 209.566701626812, 413.198959687906, 480.781348456207, 1173.39865293829, 472.922252010724, 604.149144939725, 465.1195499296765, 1526.31578947368, 213.242106763595, 484.29930019738, 704.761904761905, 297.401595060458, 603.518693056865, 1063.90532544379, 2570.21637675011, 457.793482528465, 564.509215602229, 560.614577477984, 40.1223461676862, 674.220963172805, 2180.97643097643, 563.166011105635, 2211.1801242236, 790.575916230366, 87.8052121502688, 2764.96922216004, 1053.3033033033, 0.0, 811.804346180056, 725.107264388223, 338.873079112123, 721.355955488391, 0.0, 271.761133603239, 1023.24324324324, 1272.14428857715, 2417.35537190083, 1214.6490335707, 801.148519310888, 634.480560866794, 1213.0912167584352, 225.836431226766, 267.310221519259, 233.018443544759, 506.113111311131, 721.674876847291, 1046.13025011798, 355.299269170709, 503.798194066218, 1584.236472266025, 488.418984593113, 424.348013506717, 1406.766262732975, 135.916482634009, 1569.01042439322, 1357.38095238095, 661.071143085532, 1233.130913073915, 1314.87702459508, 1183.781559959125, 196.1207422242155, 156.845847247657, 1436.84010634258, 1073.5211443563, 394.26523297491, 662.672626783394, 397.313104792039, 1160.9649122807, 668.4111670030966, 20.5561630574394, 67.9409931435695, 1718.822746923845, 543.5730558660035, 239.673247513515, 269.396551724138, 397.032395150382, 2013.84083044983, 1338.969251983435, 1246.85859710514, 739.168490153173, 615.549537350485, 436.674008810573, 2072.58984597832, 0.0, 396.139119336311, 141.91194804576747, 1533.5604111767848, 231.389314970138, 1713.92991531418, 192.207202090197, 22.0698126727403, 1402.44391025641, 2700.73664825046, 438.094551166462, 256.997455470738, 201.73568818514, 740.769630785231, 326.465986141122, 1190.28835690968, 43.3743169398907, 977.147577092511, 800.796812749004, 1325.033274179235, 184.91124260355, 220.318316005648, 242.513957029267, 0.0, 942.9503820435585, 771.896176959468, 330.063386658618, 908.568142610696, 278.91156462585, 957.708961125154, 1263.6277302944, 1301.03067295265, 11.8038740920097, 1120.7462347118549, 1807.05827722313, 598.544232922732, 1889.85568760611, 15.5893158574124, 248.16909686149802, 2165.6074037388, 382.799325463744, 19.6828868234008, 7.122862324312065, 148.423520700932, 241.303520530604, 18.5994082006482, 4.76308301373253, 121.790021807824, 1475.341388143695, 821.940406227446, 489.75468975469, 1208.59053497942, 56.68075732856495, 490.089254665585, 0.0, 798.576902025178, 35.405872193437, 373.5168913106405, 525.130679533575, 74.43640801995309, 1787.79468316335, 703.53982300885, 1740.3429043586, 526.951167984548, 162.881754111198, 522.532800912721, 2311.40286177902, 16.0512957520705, 1056.70952851962, 1184.17415342087, 611.897747790554, 753.098080701224, 543.548984886546, 593.998775260257, 471.854415327652, 588.0355805169295, 181.033801100501, 899.58932238193, 0.0, 68.190623789229, 973.4086356086285, 1650.48375950242, 910.659509202454, 168.343374362227, 1136.176941623605, 186.75653138395649, 84.4863594830962, 611.857071519725, 477.208486279833, 661.231992545986, 355.039980615459, 854.8461400444395, 4.32588320115357, 1436.84010634258, 147.296137339056, 352.710890777463, 474.6271970803065, 141.010715388819, 764.844981607987, 383.895650784665, 213.581406268341, 189.676463324278, 45.7020128864692, 90.8068506796054, 0.0, 921.234699308143, 136.240777266418, 37.7126311979732, 283.327249868192, 1054.8079642513699, 73.5664092999046, 0.0, 568.370890881189, 485.712507003673, 651.764646261114, 550.85916587514, 246.286161063331, 0.0, 728.498478312039, 267.73118451389, 0.0, 164.871291837584, 236.829494265359, 436.560486757337, 38.012089335892654, 1552.72919978802, 719.2419367994655, 615.189873417722, 901.347139741835, 577.071577071577, 568.023968405284, 1121.27102756409, 1506.76284941389, 120.956331596887, 1297.19320781742, 284.971179530437, 318.523197866217, 8.70464247598719, 1130.1897571106, 7.43213606900921, 171.8814037870785, 261.320923572579, 468.708012163213, 1047.6135799190101, 21.3379469434833, 1.098951474793485, 6.20522881781266, 94.41741124661056, 65.2621937256698, 770.082064292791, 1183.4528177730099, 723.992947239929, 998.247458815282, 1026.2865640683349, 842.952275249722, 149.663615308261, 1232.80898876404, 531.884686674291, 754.136029411765, 99.0284005979073, 713.322091062395, 12.7581098648608, 465.168299957392, 62.6890959699867, 5.20833333333333, 125.964178323964, 977.837142574453, 118.148605116732, 793.794618341571, 956.601905282207, 0.0, 839.492732105567, 363.49541017362753, 278.081632653061, 368.22400990099, 280.0405095473825, 355.299269170709, 1226.14898273486, 320.103537532355, 173.6640817683205, 1042.58923755653, 312.38591916558, 111.822480902146, 679.858657243816, 810.0442043222, 15.152749650778, 995.439574360274, 0.0, 151.40520167029]

def get_median(data):
    data = sorted(data)
    size = len(data)
    if size % 2 == 0:  # 判断列表长度为偶数
        median = (data[size // 2] + data[size // 2 - 1]) / 2
        data[0] = median
    if size % 2 == 1:  # 判断列表长度为奇数
        median = data[(size - 1) // 2]
        data[0] = median
    return data[0]

def function(selected_projects):
    all_src_churn = []
    all_file_churn = []
    all_test_churn = []
    all_build_result = []
    new_team_size = []
    all_git_num_all_built_commits = []
    new_test_density = []
    new_project_age = []
    new_project_size = []
    for nameindex in range(len(selected_projects)):
        file_name = selected_projects[nameindex] + ".csv"
        file_name = file_name.split("/")[1]
        # print(file_name)

        string = "/Users/jinxianhao/Documents/src/python/CI/Data_Base/all_dataset/" + file_name
        csv_file = csv.reader(open(string, 'r'))
        pre = []
        final = []
        for item in csv_file:
            pre.append(item)
        for i in range(len(pre[0])):
            temp = []
            for index in range(1, len(pre)):
                # print(index)
                # print(pre[index][i])
                temp.append(pre[index][i])
            final.append(temp)
            # print(len(final[42]))

        indices = []
        for index in range(len(final[42])):
            if final[42][index] == 'passed':
                indices.append(index)
            else:
                # if final[42][index - 1] == 'passed':
                indices.append(index)

        for index in indices:
            '''
            tmp_line = 0
            tmp_file = 0
            tmp_test = 0
            tmp_commit = 0
            temp = index-1

            while (final[42][temp - 1] != 'passed'):
                temp = temp - 1
                if temp <= 0:
                    break
            # print(temp)

            for index1 in range(temp, index + 1):
                # print(float(final[23][index1]))
                tmp_line = tmp_line + float(final[23][index1])
                tmp_file = tmp_file + float(final[30][index1])
                tmp_test = tmp_test + float(final[24][index1])
                tmp_commit = tmp_commit + float(final[16][index1])

            all_src_churn.append(tmp_line)
            all_file_churn.append(tmp_file)
            all_test_churn.append(tmp_test)
            all_git_num_all_built_commits.append(tmp_commit)
            '''
            all_src_churn.append(float(final[23][index]))
            all_file_churn.append(float(final[30][index]))
            all_test_churn.append(float(final[24][index]))
            all_git_num_all_built_commits.append(float(final[16][index]))

            if all_test_density[nameindex] >= 0 and all_test_density[nameindex] < 675:
                new_test_density.append(0)
            elif all_test_density[nameindex] > 679 and all_test_density[nameindex] < 1609:
                new_test_density.append(1)
            else:
                new_test_density.append(2)

            if all_team_size[nameindex] >= 0 and all_team_size[nameindex] <= 18:
                new_team_size.append(0)
            elif all_team_size[nameindex] >= 19 and all_team_size[nameindex] <= 51:
                new_team_size.append(1)
            elif all_team_size[nameindex] >= 72 and all_team_size[nameindex] <= 93:
                new_team_size.append(2)
            else:
                new_team_size.append(3)

            if all_project_age[nameindex] > 12 and all_project_age[nameindex] < 29.4:
                new_project_age.append(0)
            elif all_project_age[nameindex] > 29.5 and all_project_age[nameindex] < 44.8:
                new_project_age.append(1)
            else:
                new_project_age.append(2)

            if all_project_size[nameindex] >= 696 and all_project_size[nameindex] <= 101107:
                new_project_size.append(0)
            elif all_project_size[nameindex] >= 121745 and all_project_size[nameindex] <= 429028:
                new_project_size.append(1)
            else:
                new_project_size.append(2)

            if final[42][index] == 'passed':
                all_build_result.append(1)
            else:
                all_build_result.append(0)
    return all_src_churn, all_file_churn,all_test_churn,all_build_result,new_team_size,all_git_num_all_built_commits,new_test_density,new_project_age,new_project_size


project_index=[]
for index in range(len(project_names)):
    project_index.append(index)

X_index=np.array(project_index)
KF = KFold(n_splits=8)


precision=[]
recall=[]
build_save=[]
for train_index, test_index in KF.split(X_index):
    # print("TRAIN:", train_index, "TEST:", test_index)
    X_index_train, X_index_test = X_index[train_index], X_index[test_index]
    #print(len(X_index_train)/len(X_index_test))
    #print(X_index_test)
    project_test=[]
    project_train=[]
    for item in  X_index_train:
        project_train.append(project_names[item])
    for item in X_index_test:
        project_test.append(project_names[item])

    src_churn_train, file_churn_train, test_churn_train, build_result_train, team_size_train, git_num_all_built_commits_train, test_density_train, project_age_train, project_size_train=function(project_train)
    argument_train = []
    result_train = []
    for index in range(len(src_churn_train)):
        argument_train.append([])
    for index in range(len(src_churn_train)):
        argument_train[index].append(src_churn_train[index])
        argument_train[index].append(file_churn_train[index])
        argument_train[index].append(test_churn_train[index])
        argument_train[index].append(test_density_train[index])
        argument_train[index].append(project_size_train[index])
        argument_train[index].append(project_age_train[index])
        # argument_train[index].append(team_size_train[index])
        argument_train[index].append(git_num_all_built_commits_train[index])

    X_train = np.array(argument_train)
    Y_train = np.array(build_result_train)
    num_feature = 7
    X_train = X_train.reshape((int(len(X_train)), num_feature))
    try:
        rf = RandomForestClassifier(class_weight={0: 0.05, 1: 1})  # 这里使用了默认的参数设置
    except:
        rf = RandomForestClassifier()
    predictor = rf.fit(X_train, Y_train)

    for item in project_test:
        new_project_test=[]
        new_project_test.append(item)
        src_churn_test, file_churn_test, test_churn_test, build_result_test, team_size_test, git_num_all_built_commits_test, test_density_test, project_age_test, project_size_test = function(
            new_project_test)

        argument_test = []
        result_test = []

        for index in range(len(src_churn_test)):
            argument_test.append([])
        for index in range(len(src_churn_test)):
            argument_test[index].append(src_churn_test[index])
            argument_test[index].append(file_churn_test[index])
            argument_test[index].append(test_churn_test[index])
            argument_test[index].append(test_density_test[index])
            argument_test[index].append(project_size_test[index])
            argument_test[index].append(project_age_test[index])
            # argument_test[index].append(team_size_test[index])
            argument_test[index].append(git_num_all_built_commits_test[index])

        X_test = np.array(argument_test)
        Y_test = np.array(build_result_test)
        X_test = X_test.reshape((int(len(X_test)), num_feature))
        Y_result = (predictor.predict(X_test))

        yes = 0
        more = 0
        less = 0
        num_test = len(Y_test)
        num_build = 0

        for index in range(len(Y_result)):
            if Y_result[index] == 0 and Y_test[index] == 0 and Y_test[index - 1] == 1 and Y_result[index - 1] == 1:
                yes = yes + 1
            if Y_result[index] == 0 and Y_result[index - 1] == 1:
                more = more + 1
            if Y_test[index] == 0 and Y_test[index - 1] == 1:
                less = less + 1

        if less != 0:
            recall0 = yes / less
            if more == 0:
                precision0 = 1
                # recall.append(yes / less)
            else:
                precision0 = yes / more
                # recall.append(yes / less)
            # print(recall0)
            # print(precision0)
            precision.append(precision0)
            recall.append(recall0)
            build_save.append(1 - more / num_test)


print(get_median(precision))
print(get_median(recall))
print(get_median(build_save))
a=get_median(recall)
b=get_median(build_save)
print((2*a*b)/(a+b))
#print(get_median(f_score))
print(sum(precision)/len(precision))
print(sum(recall)/len(recall))

book = xlwt.Workbook(encoding='utf-8', style_compression=0)
sheet1 = book.add_sheet('test_line', cell_overwrite_ok=True)
sheet2 = book.add_sheet('test_case', cell_overwrite_ok=True)
sheet3 = book.add_sheet('assert_case', cell_overwrite_ok=True)


for index in range(len(precision)):
    sheet1.write(index,0,precision[index])
    sheet1.write(index,1,recall[index])
    if precision[index]==0 and recall[index]==0:
        sheet1.write(index,2,0)
    else:
        sheet1.write(index,2,2*precision[index]*recall[index]/(precision[index]+recall[index]))

f_score=[]
book.save(r'cross_project_performance.xls')
print(precision)
print(recall)
for index in range(len(precision)):
    if precision[index] == 0 and recall[index] == 0:
        f_score.append(0)
    else:
        f_score.append(2*precision[index]*recall[index]/(precision[index]+recall[index]))

print(f_score)
print(len(precision))
print(len(recall))
print(len(f_score))


