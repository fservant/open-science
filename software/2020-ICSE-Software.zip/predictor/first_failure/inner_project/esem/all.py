import csv
import numpy as np
import xlwt
import math
from sklearn.model_selection import KFold
from sklearn.ensemble import RandomForestClassifier

file_name='1.csv'

csv_file = csv.reader(open(file_name, 'r'))
pre = []
final = []
for item in csv_file:
    pre.append(item)

for i in range(len(pre[0])):
    temp = []
    for index in range(1, len(pre)):
        # print(index)
        # print(pre[index][i])
        temp.append(pre[index][i])
    final.append(temp)
print((final[0]))

num=0
indices=[]
for index in range(len(final[20])):
    if final[20][index]=='fail' and final[2][index]=='1':
        #num=num+1
        indices.append(index)
    if final[20][index]=='pass':
        indices.append(index)

book = xlwt.Workbook(encoding='utf-8', style_compression=0)
sheet1 = book.add_sheet('t', cell_overwrite_ok=True)


for index in range(len(final)):
    col=0
    for index1 in range(len(final[index])):
        if index1 in indices:
            sheet1.write(col,index,final[index][index1])
            col=col+1

book.save(r'new_1.xls')