from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import RandomForestClassifier
import numpy as np

final=[[1,1,1],[2,2,3],[3,3,4]]
status=[2,2,5]
final = np.array(final)
final = final.reshape((3, 3))
print(final)
rf = RandomForestClassifier()  # 这里使用了默认的参数设置
predictor = rf.fit(final, status)

test=[101,101,101]
test = np.array(test)
test = test.reshape((1, 3))

print(predictor.predict(test))
