import csv
import numpy as np
import xlwt
import math
from sklearn.model_selection import KFold
from sklearn.ensemble import RandomForestClassifier

def get_median(data):
    data = sorted(data)
    size = len(data)
    if size % 2 == 0:  # 判断列表长度为偶数
        median = (data[size // 2] + data[size // 2 - 1]) / 2
        data[0] = median
    if size % 2 == 1:  # 判断列表长度为奇数
        median = data[(size - 1) // 2]
        data[0] = median
    return data[0]

def cross_validation(X,Y):
    X = np.array(X)
    Y = np.array(Y)
    KF = KFold(n_splits=8)  # 建立4折交叉验证方法  查一下KFold函数的参数
    for train_index, test_index in KF.split(X):
        print("TRAIN:", train_index, "TEST:", test_index)
        X_train, X_test = X[train_index], X[test_index]
        Y_train, Y_test = Y[train_index], Y[test_index]
        print(X_train, X_test)
        print(Y_train, Y_test)


precision=[]
recall=[]
f_score=[]
build_save=[]
project_names=['rails/rails', 'myronmarston/vcr', 'concerto/concerto', 'benhoskings/babushka', 'rubinius/rubinius', 'rubychan/coderay', 'codeforamerica/adopt-a-hydrant', 'radiant/radiant', 'saberma/shopqi', 'rspec/rspec-core', 'engineyard/engineyard', 'plataformatec/devise', 'rspec/rspec-rails', 'karmi/retire', 'sferik/rails_admin', 'tdiary/tdiary-core', 'dkubb/veritas', 'sstephenson/sprockets', 'thoughtbot/factory_girl', 'weppos/whois', 'errbit/errbit', 'padrino/padrino-framework', 'thoughtbot/paperclip', 'plataformatec/simple_form', 'huerlisi/bookyt', 'hotsh/rstat.us', 'mperham/dalli', 'innoq/iqvoc', 'cheezy/page-object', 'justinfrench/formtastic', 'nov/fb_graph', 'assaf/vanity', 'activerecord-hackery/ransack', 'jimweirich/rake', 'rspec/rspec-mocks', 'neo4jrb/neo4j', 'diaspora/diaspora', 'test-unit/test-unit', 'Shopify/liquid', 'activeadmin/activeadmin', 'ari/jobsworth', 'thoughtbot/shoulda-matchers', 'rubygems/rubygems', 'rdoc/rdoc', 'spree/spree', 'rubyzip/rubyzip', 'pry/pry', 'jruby/activerecord-jdbc-adapter', 'sass/sass', 'jruby/warbler', 'fatfreecrm/fat_free_crm', 'rspec/rspec-expectations', 'excon/excon', 'typus/typus', 'heroku/heroku', 'nahi/httpclient', 'podio/podio-rb', 'maxdemarzi/neography', 'locomotivecms/engine', 'gedankenstuecke/snpr', 'peter-murach/github', 'jnicklas/capybara', 'travis-ci/travis-core', 'presidentbeef/brakeman', 'mikel/mail', 'randym/axlsx', 'kmuto/review', 'danielweinmann/catarse', 'middleman/middleman', 'rubyworks/facets', 'railsbp/rails_best_practices', 'comfy/comfortable-mexican-sofa', 'mongoid/moped', 'wr0ngway/rubber', 'rslifka/elasticity', 'lsegal/yard', 'NoamB/sorcery', 'puppetlabs/puppet', 'mitchellh/vagrant', 'ai/r18n', 'celluloid/celluloid', 'jordansissel/fpm', 'neo4jrb/neo4j-core', 'orbeon/orbeon-forms', 'redis/redis-rb', 'pivotal/pivotal_workstation', 'jruby/jruby', 'louismullie/treat', 'puma/puma', 'pophealth/popHealth', 'twitter/twitter-cldr-rb', 'gistflow/gistflow', 'adamfisk/LittleProxy', 'awestruct/awestruct', 'jnunemaker/httparty', 'Graylog2/graylog2-server', 'neuland/jade4j', 'sensu/sensu', 'shawn42/gamebox', 'applicationsonline/librarian', 'haml/haml', 'sporkmonger/addressable', 'google/google-api-ruby-client', 'elm-city-craftworks/practicing-ruby-web', 'sunlightlabs/scout', 'floere/phony', 'data-axle/cassandra_object', 'typhoeus/typhoeus', 'shoes/shoes4', 'troessner/reek', 'recurly/recurly-client-ruby', 'CloudifySource/cloudify', 'puppetlabs/puppetlabs-firewall', 'typhoeus/ethon', 'sparklemotion/nokogiri', 'tinkerpop/blueprints', 'tinkerpop/rexster', 'thinkaurelius/titan', 'openSUSE/open-build-service', 'engineyard/ey-cloud-recipes', 'git/git-scm.com', 'honeybadger-io/honeybadger-ruby', 'azagniotov/stubby4j', 'sferik/twitter', 'calagator/calagator', 'openshift/rhc', 'codefirst/AsakusaSatellite', 'DatabaseCleaner/database_cleaner', 'burke/zeus', 'fog/fog', 'twilio/twilio-java', 'twitter/commons', 'Albacore/albacore', 'prawnpdf/prawn', 'enspiral/loomio', 'refinery/refinerycms', 'sevntu-checkstyle/sevntu.checkstyle', 'opal/opal', 'graphhopper/graphhopper', 'sparklemotion/mechanize', 'SomMeri/less4j', 'tent/tentd', 'searchbox-io/Jest', 'square/dagger', 'google/truth', 'square/okhttp', 'square/retrofit', 'maxcom/lorsource', 'jneen/rouge', 'jmkgreen/morphia', 'SpontaneousCMS/spontaneous', 'everzet/capifony', 'killbill/killbill', 'scobal/seyren', 'intuit/simple_deploy', 'projectblacklight/blacklight', 'rapid7/metasploit-framework', 'amahi/platform', 'vcr/vcr', 'Findwise/Hydra', 'structr/structr', 'sachin-handiekar/jInstagram', 'nutzam/nutz', 'slim-template/slim', 'puppetlabs/puppetlabs-stdlib', 'puppetlabs/facter', 'phoet/on_ruby', 'dreamhead/moco', 'travis-ci/travis.rb', 'cloudfoundry/cloud_controller_ng', 'square/assertj-android', 'jmxtrans/jmxtrans', 'twitter/secureheaders', 'nanoc/nanoc', 'expertiza/expertiza', 'asciidoctor/asciidoctor', 'rubber/rubber', 'openMF/mifosx', 'mybatis/mybatis-3', 'test-kitchen/test-kitchen', 'owlcs/owlapi', 'engineyard/engineyard-serverside', 'selendroid/selendroid', 'ruboto/ruboto', 'openfoodfoundation/openfoodnetwork', 'stephanenicolas/robospice', 'joscha/play-authenticate', 'undera/jmeter-plugins', 'cantino/huginn', 'resque/resque', 'albertlatacz/java-repl', 'l0rdn1kk0n/wicket-bootstrap', 'dynjs/dynjs', 'abarisain/dmix', 'dropwizard/dropwizard', 'dropwizard/metrics', 'jberkel/sms-backup-plus', 'rubymotion/sugarcube', 'naver/yobi', 'Shopify/active_shipping', 'projecthydra/sufia', 'rubymotion/BubbleWrap', 'pivotal-sprout/sprout-osx-apps', 'chef/omnibus', 'JodaOrg/joda-time', 'EmmanuelOga/ffaker', 'kostya/eye', 'laurentpetit/ccw', 'puniverse/quasar', 'simpligility/android-maven-plugin', 'jsonld-java/jsonld-java', 'travis-ci/travis-cookbooks', 'FenixEdu/fenixedu-academic', 'threerings/playn', 'restlet/restlet-framework-java', 'jedi4ever/veewee', 'sensu/sensu-community-plugins', 'OpenRefine/OpenRefine', 'chef/chef', 'fluent/fluentd', 'perwendel/spark', 'joelittlejohn/jsonschema2pojo', 'jOOQ/jOOQ', 'springside/springside4', 'github/hub', 'johncarl81/parceler', 'discourse/onebox', 'julianhyde/optiq', 'ruby-ldap/ruby-net-ldap', 'DSpace/DSpace', 'jeremyevans/sequel', 'bikeindex/bike_index', 'doanduyhai/Achilles', 'rackerlabs/blueflood', 'rodjek/librarian-puppet', 'p6spy/p6spy', 'square/wire', 'Nodeclipse/nodeclipse-1', 'rebelidealist/stripe-ruby-mock', 'checkstyle/checkstyle', 'elastic/logstash', 'airlift/airlift', 'lenskit/lenskit', 'MiniProfiler/rack-mini-profiler', 'geoserver/geoserver', 'ocpsoft/rewrite', 'Unidata/thredds', 'torakiki/pdfsam', 'loopj/android-async-http', 'feedbin/feedbin', 'recruit-tech/redpen', 'brettwooldridge/HikariCP', 'puppetlabs/marionette-collective', 'iipc/openwayback', 'caelum/vraptor4', 'dianping/cat', 'jphp-compiler/jphp', 'mockito/mockito', 'oblac/jodd', 'facebook/buck', 'facebook/presto', 'jpos/jPOS', 'hamstergem/hamster', 'mongodb/morphia', 'realestate-com-au/pact', 'inaturalist/inaturalist', 'jtwig/jtwig', 'go-lang-plugin-org/go-lang-idea-plugin', 'square/picasso', 'voltrb/volt', 'zxing/zxing', 'openaustralia/morph', 'GlowstoneMC/Glowstone', 'owncloud/android', 'JakeWharton/u2020', 'rpush/rpush', 'OneBusAway/onebusaway-android', 'rabbit-shocker/rabbit', 'azkaban/azkaban', 'relayrides/pushy', 'deeplearning4j/deeplearning4j', 'github/developer.github.com', 'xetorthio/jedis', 'FasterXML/jackson-core', 'FasterXML/jackson-databind', 'protostuff/protostuff', 'atmos/heaven', 'MrTJP/ProjectRed', 'lemire/RoaringBitmap', 'apache/drill', 'Kapeli/cheatsheets', 'gradle/gradle', 'OpenGrok/OpenGrok', 'spring-io/sagan', 'mendhak/gpslogger', 'thoughtbot/hound', 'teamed/qulice', 'jcabi/jcabi-aspects', 'jcabi/jcabi-github', 'jcabi/jcabi-http', 'yegor256/rultor', 'querydsl/querydsl', 'codevise/pageflow', 'grails/grails-core', 'weld/core', 'thatJavaNerd/JRAW', 'bndtools/bnd', 'igniterealtime/Openfire', 'zendesk/samson', 'bndtools/bndtools', 'xtreemfs/xtreemfs', 'puniverse/capsule', 'broadinstitute/picard', 'github/github-services', 'gavinlaking/vedeu', 'haiwen/seadroid', 'AChep/AcDisplay', 'GoClipse/goclipse', 'hsz/idea-gitignore', 'jsprit/jsprit', 'dblock/waffle', 'numenta/htm.java', 'rightscale/praxis', 'google/error-prone', 'datastax/ruby-driver', 'iluwatar/java-design-patterns', 'Netflix/Hystrix', 'oyachai/HearthSim', 'jayway/JsonPath', 'exteso/alf.io', 'spring-cloud/spring-cloud-config', 'validator/validator', 'HubSpot/jinjava', 'connectbot/connectbot', 'google/physical-web', 'myui/hivemall', 'MarkUsProject/Markus', 'jMonkeyEngine/jmonkeyengine', 'davidmoten/rxjava-jdbc', 'qos-ch/logback', 'Homebrew/homebrew-science', 'GoogleCloudPlatform/DataflowJavaSDK', 'SoftInstigate/restheart', 'naver/pinpoint', 'KronicDeth/intellij-elixir', 'embulk/embulk', 'loomio/loomio', 'openstreetmap/openstreetmap-website', 'activescaffold/active_scaffold', 'tananaev/traccar', 'SonarSource/sonarqube', 'grpc/grpc-java', 'psi-probe/psi-probe', 'orientation/orientation', 'square/keywhiz', 'aws/aws-sdk-java', 'Shopify/shipit-engine', 'perfectsense/brightspot-cms', 'jamesagnew/hapi-fhir']
#project_names=['rubyworks/facets','apache/drill']

for nameindex in range(len(project_names)):
    file_name = project_names[nameindex] + ".csv"
    file_name = file_name.split("/")[1]
    #print(file_name)

    string="/Users/jinxianhao/Documents/src/python/CI/Data_Base/all_dataset/" + file_name
    csv_file = csv.reader(open(string, 'r'))
    pre = []
    final = []
    for item in csv_file:
        pre.append(item)

    for i in range(len(pre[0])):
        temp = []
        for index in range(1, len(pre)):
            # print(index)
            # print(pre[index][i])
            temp.append(pre[index][i])
        final.append(temp)
    #print(len(final[42]))

    indices = []
    for index in range(len(final[42])):
        if final[42][index] == 'passed':
            indices.append(index)
        else:
            #if final[42][index - 1] == 'passed':
                indices.append(index)
    src_churn=[]
    file_churn=[]
    test_churn=[]
    build_result=[]
    team_size=[]
    git_num_all_built_commits=[]
    gh_num_commits_on_files_touched=[]
    argument=[]
    for index in indices:
        '''
        
        tmp_line = 0
        tmp_file = 0
        tmp_test = 0
        tmp_commit = 0
        temp = index

        while (final[42][temp - 1] != 'passed'):
            temp = temp - 1
            if temp <= 0:
                break
        # print(temp)

        for index1 in range(temp, index + 1):
            # print(float(final[23][index1]))
            tmp_line = tmp_line + float(final[23][index1])
            tmp_file = tmp_file + float(final[30][index1])
            tmp_test = tmp_test + float(final[24][index1])
            tmp_commit = tmp_commit + float(final[16][index1])

        src_churn.append(tmp_line)
        file_churn.append(tmp_file)
        test_churn.append(tmp_test)
        git_num_all_built_commits.append(tmp_commit)
        '''
        src_churn.append(float(final[23][index]))
        file_churn.append(float(final[30][index]))
        test_churn.append(float(final[24][index]))
        git_num_all_built_commits.append(float(final[16][index]))
        argument.append([])


    for item in indices:
        if final[42][item] == 'passed':
            build_result.append(1)
        else:
            build_result.append(0)
    print(len(build_result))

    gaussian = []
    for index in range(len(build_result)):
        temp = 0
        if 0 not in build_result[0:index]:
            gaussian.append(temp)
        else:
            for index1 in range(len(build_result[0:index])):
                if build_result[index1] == 0:
                    ft = index - index1
                    gscore = 1 / (3 * math.sqrt(2 * math.pi)) * math.exp(-ft * ft / 18)
                    temp = temp + gscore
            gaussian.append(int(temp * 100))

    last_status=[]
    last_status.append(1)
    for index in range(len(build_result)):
        last_status.append(build_result[index-1])

    for index in range(len(src_churn)):
        argument[index].append(src_churn[index])
        argument[index].append(file_churn[index])
        argument[index].append(test_churn[index])
        #argument[index].append(team_size[index])
        argument[index].append(git_num_all_built_commits[index])
        #argument[index].append(last_status[index])
        #argument[index].append(gh_num_commits_on_files_touched[index])
        #argument[index].append(gaussian[index])

    X = np.array(argument)
    Y = np.array(build_result)
    KF = KFold(n_splits=8)  # 建立4折交叉验证方法  查一下KFold函数的参数
    more=0
    less=0
    yes=0
    num_feature=4
    num_test=0
    num_build=0
    for train_index, test_index in KF.split(X):

        #print("TRAIN:", train_index, "TEST:", test_index)
        X_train, X_test = X[train_index], X[test_index]
        Y_train, Y_test = Y[train_index], Y[test_index]
        #print(X_train, X_test)
        #print(Y_test)
        num_test = num_test + len(Y_test)
        X_train = X_train.reshape((int(len(X_train)), num_feature))
        try:
            rf = RandomForestClassifier(class_weight={0:0.05,1:1})
            predictor = rf.fit(X_train, Y_train)
        except:
            rf = RandomForestClassifier()
            predictor = rf.fit(X_train, Y_train)

        X_test = X_test.reshape((int(len(X_test)), num_feature))
        Y_result=(predictor.predict(X_test))
        #print(Y_result)
        #print(Y_test)
        #print('aaaaaaaaaaaa')

        for index in range(len(Y_result)):
            if Y_result[index]==0 and Y_test[index]==0 and Y_test[index-1]==1 and Y_result[index-1]==1:
                yes=yes+1
            if Y_result[index] == 0 and Y_result[index-1]==1:
                more=more+1
            if Y_test[index] == 0 and Y_test[index-1]==1:
                less=less+1
    #print(less)
    if less != 0:
        recall0 = yes/less
        if more == 0:
            precision0=1
            #recall.append(yes / less)
        else:
            precision0 = yes / more
            #recall.append(yes / less)
        precision.append(precision0)
        recall.append(recall0)
        build_save.append(1-more/num_test)
        #f_score.append(2*precision0*recall0/(precision0+recall0))

#precision=[0.09084139985107967, 0.17142857142857143, 0.05194805194805195, 0.1111111111111111, 0.14018691588785046, 0.0, 0.1111111111111111, 0.16666666666666666, 0.1388888888888889, 0.12903225806451613, 0.25, 0.05660377358490566, 0.13793103448275862, 0.18421052631578946, 0.1375, 0.11904761904761904, 0.08695652173913043, 0.0, 0.21052631578947367, 0.0, 0.10416666666666667, 0.034782608695652174, 0.17073170731707318, 0.11764705882352941, 0.14285714285714285, 0.15, 0.2413793103448276, 0.11594202898550725, 0.0975609756097561, 0.13043478260869565, 0.0625, 0.3333333333333333, 0.09090909090909091, 0.16666666666666666, 0.06896551724137931, 0.168141592920354, 0.19745222929936307, 0.03125, 0.2222222222222222, 0.038461538461538464, 0.22807017543859648, 0.08695652173913043, 0.07971014492753623, 0.06593406593406594, 0.15416666666666667, 0.0, 0.1320754716981132, 0.10869565217391304, 0.13513513513513514, 0.2, 0.11702127659574468, 0.13636363636363635, 0.07575757575757576, 0.15789473684210525, 0.11214953271028037, 0.13333333333333333, 0.10714285714285714, 0.18518518518518517, 0.21739130434782608, 0.0684931506849315, 0.10869565217391304, 0.1568627450980392, 0.06542056074766354, 0.0, 0.08, 0.09803921568627451, 0.05128205128205128, 0.07547169811320754, 0.11194029850746269, 1, 0.0, 0.15217391304347827, 0.14035087719298245, 0.17073170731707318, 0.1, 0.1388888888888889, 0.06060606060606061, 0.0, 0.038461538461538464, 0.06451612903225806, 0.14084507042253522, 0.20588235294117646, 0.08620689655172414, 0.056, 0.13636363636363635, 0.0625, 0.13607305936073058, 0.14285714285714285, 0.1016949152542373, 0.0, 0.15384615384615385, 0.12, 0.038461538461538464, 0.075, 0.0, 0.0, 0.0, 0.06976744186046512, 0.08333333333333333, 0.0, 0.0, 0.16666666666666666, 0.07142857142857142, 0.11538461538461539, 0.07692307692307693, 0.07692307692307693, 0.14285714285714285, 0.125, 0.12, 0.1111111111111111, 0.0, 0.1111111111111111, 0.0, 0.16666666666666666, 0.14705882352941177, 0.03571428571428571, 0.0, 0.34285714285714286, 0.10410094637223975, 0.0, 1, 0.058823529411764705, 0.07692307692307693, 0.038461538461538464, 0.0, 0.0, 0.0, 0.2222222222222222, 0.15384615384615385, 0.12852664576802508, 0.0, 0.23684210526315788, 0.2857142857142857, 0.11538461538461539, 0.13043478260869565, 0.1111111111111111, 1, 0.1111111111111111, 0.05, 0.16666666666666666, 0.1, 0.1724137931034483, 0.2692307692307692, 0.0, 0.2857142857142857, 0.16025641025641027, 0.0, 0.0, 0.0, 0.14285714285714285, 0.1875, 0.0, 0.14814814814814814, 0.0, 0.0, 0.0, 0.018018018018018018, 0.08333333333333333, 0.14285714285714285, 0.0, 0.1896551724137931, 1, 0.1242603550295858, 0.0, 0.0, 0.0, 0.1111111111111111, 0.046875, 0.08333333333333333, 0.10471204188481675, 0.3333333333333333, 0.0, 0.0, 0.10714285714285714, 0.08641975308641975, 0.0, 0.14285714285714285, 0.0, 0.0, 0.08571428571428572, 0.16666666666666666, 0.0, 0.15, 0.15384615384615385, 0.1553398058252427, 0.3142857142857143, 0.2857142857142857, 0.07142857142857142, 0.0, 0.14814814814814814, 1, 0.15, 0.14285714285714285, 0.16666666666666666, 0.06666666666666667, 0.0, 0.1111111111111111, 0.2857142857142857, 0.0, 0.058823529411764705, 0.07777777777777778, 0.17142857142857143, 0.0625, 0.0, 0.0, 0.17391304347826086, 0.21212121212121213, 0.11627906976744186, 0.07142857142857142, 0.047619047619047616, 0.0, 0.03333333333333333, 0.0, 0.0, 0.07142857142857142, 1, 0.16521739130434782, 0.0, 0.11224489795918367, 0.1111111111111111, 0.0, 0.0, 0.0, 0.045454545454545456, 0.0, 1, 0.2, 0.0, 0.09523809523809523, 0.18181818181818182, 0.06666666666666667, 0.07692307692307693, 0.0, 0.1111111111111111, 0.1724137931034483, 0.06818181818181818, 0.0, 0.0, 0.0, 0.0, 0.1111111111111111, 0.20689655172413793, 0.17647058823529413, 0.18181818181818182, 0.16417910447761194, 0.2, 0.11904761904761904, 0.15, 0.0, 0.05555555555555555, 0.0, 0.25, 1, 0.0, 0.0, 0.125, 0.14285714285714285, 0.14285714285714285, 0.0, 0.08633093525179857, 0.09836065573770492, 0.0, 0.18604651162790697, 0.0, 0.13333333333333333, 0.1509433962264151, 1, 0.07692307692307693, 0.0, 0.0, 0.5, 0.0, 0.0, 0.0, 0.0, 0.175, 0.25, 0.0, 0.5, 0.0, 0.08108108108108109, 0.047619047619047616, 0.11538461538461539, 0.0, 0.0, 1, 0.14285714285714285, 0.1111111111111111, 0.4, 0.25, 0.0, 0.061224489795918366, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.16666666666666666, 0.16666666666666666, 0.09090909090909091, 0.10112359550561797, 1, 0.1328125, 1, 0.1044776119402985, 0.0, 0.0, 0.11711711711711711, 0.0, 0.10344827586206896, 0.14285714285714285, 0.2, 0.14285714285714285, 0.3333333333333333, 0.0, 0.07692307692307693, 0.125, 0.13333333333333333, 0.0, 0.0, 1, 0.0, 0.0, 0.06, 0.0, 0.16842105263157894, 0.0, 0.0, 0.0, 0.14285714285714285, 0.13043478260869565, 0.0, 0.0, 0.0, 0.0, 0.11764705882352941, 0.0, 1, 0.2608695652173913, 0.2085889570552147, 0.0, 0.0, 0.2222222222222222, 0.0, 0.07692307692307693, 0.16194331983805668, 0.2222222222222222, 0.06666666666666667, 0.0, 0.02727272727272727, 0.03333333333333333, 1, 0.058823529411764705, 0.0, 0.11538461538461539, 0.2222222222222222, 0.05263157894736842, 0.19801980198019803]
#recall=[0.1026936026936027, 0.14285714285714285, 0.03508771929824561, 0.07692307692307693, 0.13686131386861314, 0.0, 0.10526315789473684, 0.23529411764705882, 0.15625, 0.08695652173913043, 0.3, 0.045454545454545456, 0.1643835616438356, 0.2692307692307692, 0.1456953642384106, 0.09259259259259259, 0.09523809523809523, 0.0, 0.14285714285714285, 0.0, 0.0847457627118644, 0.036036036036036036, 0.2028985507246377, 0.07142857142857142, 0.3, 0.125, 0.28, 0.10810810810810811, 0.1, 0.10344827586206896, 0.041666666666666664, 0.16666666666666666, 0.08333333333333333, 0.125, 0.022222222222222223, 0.1484375, 0.2152777777777778, 0.038461538461538464, 0.08, 0.028169014084507043, 0.26, 0.08333333333333333, 0.09734513274336283, 0.08333333333333333, 0.19170984455958548, 0.0, 0.12727272727272726, 0.125, 0.11904761904761904, 0.1111111111111111, 0.12643678160919541, 0.08695652173913043, 0.078125, 0.1875, 0.1016949152542373, 0.17391304347826086, 0.10344827586206896, 0.1724137931034483, 0.24752475247524752, 0.13157894736842105, 0.11627906976744186, 0.18604651162790697, 0.03954802259887006, 0.0, 0.07407407407407407, 0.07462686567164178, 0.03333333333333333, 0.10256410256410256, 0.13761467889908258, 0.0, 0.0, 0.14583333333333334, 0.13114754098360656, 0.16666666666666666, 0.07692307692307693, 0.11627906976744186, 0.09523809523809523, 0.0, 0.019417475728155338, 0.09523809523809523, 0.1724137931034483, 0.25925925925925924, 0.06578947368421052, 0.06481481481481481, 0.11320754716981132, 0.14285714285714285, 0.18742138364779873, 0.17857142857142858, 0.13636363636363635, 0.0, 0.07407407407407407, 0.15789473684210525, 0.043478260869565216, 0.0967741935483871, 0.0, 0.0, 0.0, 0.04225352112676056, 0.09090909090909091, 0.0, 0.0, 0.14285714285714285, 0.05555555555555555, 0.07692307692307693, 0.13043478260869565, 0.047619047619047616, 0.16666666666666666, 0.14, 0.041666666666666664, 0.047619047619047616, 0.0, 0.10828025477707007, 0.0, 0.15789473684210525, 0.16666666666666666, 0.02857142857142857, 0.0, 0.2553191489361702, 0.09821428571428571, 0.0, 0.0, 0.03125, 0.05555555555555555, 0.022727272727272728, 0.0, 0.0, 0.0, 0.13793103448275862, 0.25, 0.12852664576802508, 0.0, 0.3, 0.15384615384615385, 0.08823529411764706, 0.09900990099009901, 0.08943089430894309, 0.0, 0.047244094488188976, 0.01639344262295082, 0.14285714285714285, 0.05555555555555555, 0.2, 0.15217391304347827, 0.0, 0.3333333333333333, 0.13966480446927373, 0.0, 0.0, 0.0, 0.04, 0.3, 0.0, 0.12903225806451613, 0.0, 0.0, 0.0, 0.008547008547008548, 0.06666666666666667, 0.11904761904761904, 0.0, 0.2037037037037037, 0.0, 0.14383561643835616, 0.0, 0.0, 0.0, 0.058823529411764705, 0.030303030303030304, 0.034482758620689655, 0.07352941176470588, 0.2222222222222222, 0.0, 0.0, 0.0967741935483871, 0.11290322580645161, 0.0, 0.14285714285714285, 0.0, 0.0, 0.061224489795918366, 0.07692307692307693, 0.0, 0.09375, 0.1791044776119403, 0.16494845360824742, 0.2558139534883721, 0.18181818181818182, 0.058823529411764705, 0.0, 0.125, 0.0, 0.17475728155339806, 0.1111111111111111, 0.4, 0.024390243902439025, 0.0, 0.07142857142857142, 0.26666666666666666, 0.0, 0.034482758620689655, 0.05, 0.14285714285714285, 0.1, 0.0, 0.0, 0.21052631578947367, 0.13333333333333333, 0.125, 0.023809523809523808, 0.06060606060606061, 0.0, 0.07142857142857142, 0.0, 0.0, 0.14285714285714285, 0.0, 0.1357142857142857, 0.0, 0.07534246575342465, 0.04225352112676056, 0.0, 0.0, 0.0, 0.041666666666666664, 0.0, 0.0, 0.08333333333333333, 0.0, 0.08695652173913043, 0.04, 0.037037037037037035, 0.03333333333333333, 0.0, 0.039473684210526314, 0.17857142857142858, 0.07142857142857142, 0.0, 0.0, 0.0, 0.0, 0.07142857142857142, 0.1875, 0.06521739130434782, 0.18181818181818182, 0.1660377358490566, 0.22727272727272727, 0.125, 0.11764705882352941, 0.0, 0.05263157894736842, 0.0, 0.08333333333333333, 0.0, 0.0, 0.0, 0.05263157894736842, 0.09090909090909091, 0.09523809523809523, 0.0, 0.1111111111111111, 0.10650887573964497, 0.0, 0.32, 0.0, 0.06060606060606061, 0.1509433962264151, 0.0, 0.05128205128205128, 0.0, 0.0, 0.14285714285714285, 0.0, 0.0, 0.0, 0.0, 0.23333333333333334, 0.1, 0.0, 0.125, 0.0, 0.125, 0.045454545454545456, 0.05555555555555555, 0.0, 0.0, 0.0, 0.1875, 0.09090909090909091, 0.15384615384615385, 1.0, 0.0, 0.02127659574468085, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.13008130081300814, 0.05172413793103448, 0.07291666666666667, 0.07258064516129033, 0.0, 0.1650485436893204, 0.0, 0.09210526315789473, 0.0, 0.0, 0.08783783783783784, 0.0, 0.07317073170731707, 0.07692307692307693, 0.125, 0.1, 0.058823529411764705, 0.0, 0.08333333333333333, 0.043478260869565216, 0.18181818181818182, 0.0, 0.0, 0.0, 0.0, 0.0, 0.058823529411764705, 0.0, 0.1568627450980392, 0.0, 0.0, 0.0, 0.05555555555555555, 0.10344827586206896, 0.0, 0.0, 0.0, 0.0, 0.09523809523809523, 0.0, 0.0, 0.20689655172413793, 0.2125, 0.0, 0.0, 0.05714285714285714, 0.0, 0.05, 0.132013201320132, 0.08695652173913043, 0.09090909090909091, 0.0, 0.014018691588785047, 0.018867924528301886, 0.0, 0.05555555555555555, 0.0, 0.09090909090909091, 0.24, 0.05405405405405406, 0.19607843137254902]

print(get_median(precision))
print(get_median(recall))
print(get_median(build_save))
a=get_median(recall)
b=get_median(build_save)
print((2*a*b)/(a+b))
#print(get_median(f_score))
print(sum(precision)/len(precision))
print(sum(recall)/len(recall))

book = xlwt.Workbook(encoding='utf-8', style_compression=0)
sheet1 = book.add_sheet('test_line', cell_overwrite_ok=True)
sheet2 = book.add_sheet('test_case', cell_overwrite_ok=True)
sheet3 = book.add_sheet('assert_case', cell_overwrite_ok=True)


for index in range(len(precision)):
    sheet1.write(index,0,precision[index])
    sheet1.write(index,1,recall[index])
    if precision[index]==0 and recall[index]==0:
        sheet1.write(index,2,0)
    else:
        sheet1.write(index,2,2*precision[index]*recall[index]/(precision[index]+recall[index]))

print(precision)
print(recall)
for index in range(len(precision)):
    if precision[index] == 0 and recall[index] == 0:
        f_score.append(0)
    else:
        f_score.append(2*precision[index]*recall[index]/(precision[index]+recall[index]))

print(f_score)
print(len(precision))
print(len(recall))
print(len(f_score))
book.save(r'performance.xls')
