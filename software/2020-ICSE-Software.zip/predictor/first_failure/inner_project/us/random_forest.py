from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import RandomForestClassifier
import numpy as np

final=[[1,1,1],[2,2,3],[3,3,4]]
print(final[:1])
status=[1,1,0]
final = np.array(final)

final = final.reshape((len(final), 3))
print(final)
'''
final=final.tolist()
final.append([1,2,3])
print(final)
'''

rf = RandomForestClassifier()  # 这里使用了默认的参数设置
predictor = rf.fit(final, status)

test=[1,0,1]
test = np.array(test)
test = test.reshape((1, 3))

print(predictor.predict_proba(test))
print(predictor.predict(test))

predict_result=predictor.predict_proba(test)
print(predict_result[0][0])

