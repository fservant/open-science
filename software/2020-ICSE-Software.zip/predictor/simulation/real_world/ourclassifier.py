import csv
import numpy as np
import xlwt
import math
from sklearn.model_selection import KFold
from sklearn.ensemble import RandomForestClassifier

def get_median(data):
    data = sorted(data)
    size = len(data)
    if size % 2 == 0:  # 判断列表长度为偶数
        median = (data[size // 2] + data[size // 2 - 1]) / 2
        data[0] = median
    if size % 2 == 1:  # 判断列表长度为奇数
        median = data[(size - 1) // 2]
        data[0] = median
    return data[0]
yess=0
precision=[]
recall=[]
f_score=[]
no_projects=[]
project_names=['jackson-core.csv', 'go-lang-idea-plugin.csv', 'jphp.csv', 'rultor.csv', 'AsciidocFX.csv', 'vraptor4.csv', 'geoserver.csv', 'core.csv', 'jodd.csv', 'airlift.csv', 'redpen.csv', 'querydsl.csv', 'pdfsam.csv', 'jOOQ.csv', 'gradle.csv', 'checkstyle.csv', 'deeplearning4j.csv', 'lenskit.csv', 'zxing.csv', 'jcabi-github.csv', 'tajo.csv', 'JRAW.csv', 'flink.csv', 'mockito.csv', 'p6spy.csv', 'jackson-databind.csv', 'javaslang.csv', 'jedis.csv', 'intellij-haskforce.csv', 'blueflood.csv', 'morphia.csv', 'closure-compiler.csv', 'graylog2-server.csv', 'Achilles.csv', 'RoaringBitmap.csv', 'quickml.csv', 'HikariCP.csv']
#project_names=['jackson-core.csv']
project_names=['rails/rails', 'myronmarston/vcr', 'concerto/concerto', 'benhoskings/babushka', 'rubinius/rubinius', 'rubychan/coderay', 'codeforamerica/adopt-a-hydrant', 'radiant/radiant', 'saberma/shopqi', 'rspec/rspec-core', 'engineyard/engineyard', 'plataformatec/devise', 'rspec/rspec-rails', 'karmi/retire', 'sferik/rails_admin', 'tdiary/tdiary-core', 'dkubb/veritas', 'sstephenson/sprockets', 'thoughtbot/factory_girl', 'weppos/whois', 'errbit/errbit', 'padrino/padrino-framework', 'thoughtbot/paperclip', 'plataformatec/simple_form', 'huerlisi/bookyt', 'hotsh/rstat.us', 'mperham/dalli', 'innoq/iqvoc', 'cheezy/page-object', 'justinfrench/formtastic', 'nov/fb_graph', 'assaf/vanity', 'activerecord-hackery/ransack', 'jimweirich/rake', 'rspec/rspec-mocks', 'neo4jrb/neo4j', 'diaspora/diaspora', 'test-unit/test-unit', 'Shopify/liquid', 'activeadmin/activeadmin', 'ari/jobsworth', 'thoughtbot/shoulda-matchers', 'rubygems/rubygems', 'rdoc/rdoc', 'spree/spree', 'rubyzip/rubyzip', 'pry/pry', 'jruby/activerecord-jdbc-adapter', 'sass/sass', 'jruby/warbler', 'fatfreecrm/fat_free_crm', 'rspec/rspec-expectations', 'excon/excon', 'typus/typus', 'heroku/heroku', 'nahi/httpclient', 'podio/podio-rb', 'maxdemarzi/neography', 'locomotivecms/engine', 'gedankenstuecke/snpr', 'peter-murach/github', 'jnicklas/capybara', 'travis-ci/travis-core', 'presidentbeef/brakeman', 'mikel/mail', 'randym/axlsx', 'kmuto/review', 'danielweinmann/catarse', 'middleman/middleman', 'rubyworks/facets', 'railsbp/rails_best_practices', 'comfy/comfortable-mexican-sofa', 'mongoid/moped', 'wr0ngway/rubber', 'rslifka/elasticity', 'lsegal/yard', 'NoamB/sorcery', 'puppetlabs/puppet', 'mitchellh/vagrant', 'ai/r18n', 'celluloid/celluloid', 'jordansissel/fpm', 'neo4jrb/neo4j-core', 'orbeon/orbeon-forms', 'redis/redis-rb', 'pivotal/pivotal_workstation', 'jruby/jruby', 'louismullie/treat', 'puma/puma', 'pophealth/popHealth', 'twitter/twitter-cldr-rb', 'gistflow/gistflow', 'adamfisk/LittleProxy', 'awestruct/awestruct', 'jnunemaker/httparty', 'Graylog2/graylog2-server', 'neuland/jade4j', 'sensu/sensu', 'shawn42/gamebox', 'applicationsonline/librarian', 'haml/haml', 'sporkmonger/addressable', 'google/google-api-ruby-client', 'elm-city-craftworks/practicing-ruby-web', 'sunlightlabs/scout', 'floere/phony', 'data-axle/cassandra_object', 'typhoeus/typhoeus', 'shoes/shoes4', 'troessner/reek', 'recurly/recurly-client-ruby', 'CloudifySource/cloudify', 'puppetlabs/puppetlabs-firewall', 'typhoeus/ethon', 'sparklemotion/nokogiri', 'tinkerpop/blueprints', 'tinkerpop/rexster', 'thinkaurelius/titan', 'openSUSE/open-build-service', 'engineyard/ey-cloud-recipes', 'git/git-scm.com', 'honeybadger-io/honeybadger-ruby', 'azagniotov/stubby4j', 'sferik/twitter', 'calagator/calagator', 'openshift/rhc', 'codefirst/AsakusaSatellite', 'DatabaseCleaner/database_cleaner', 'burke/zeus', 'fog/fog', 'twilio/twilio-java', 'twitter/commons', 'Albacore/albacore', 'prawnpdf/prawn', 'enspiral/loomio', 'refinery/refinerycms', 'sevntu-checkstyle/sevntu.checkstyle', 'opal/opal', 'graphhopper/graphhopper', 'sparklemotion/mechanize', 'SomMeri/less4j', 'tent/tentd', 'searchbox-io/Jest', 'square/dagger', 'google/truth', 'square/okhttp', 'square/retrofit', 'maxcom/lorsource', 'jneen/rouge', 'jmkgreen/morphia', 'SpontaneousCMS/spontaneous', 'everzet/capifony', 'killbill/killbill', 'scobal/seyren', 'intuit/simple_deploy', 'projectblacklight/blacklight', 'rapid7/metasploit-framework', 'amahi/platform', 'vcr/vcr', 'Findwise/Hydra', 'structr/structr', 'sachin-handiekar/jInstagram', 'nutzam/nutz', 'slim-template/slim', 'puppetlabs/puppetlabs-stdlib', 'puppetlabs/facter', 'phoet/on_ruby', 'dreamhead/moco', 'travis-ci/travis.rb', 'cloudfoundry/cloud_controller_ng', 'square/assertj-android', 'jmxtrans/jmxtrans', 'twitter/secureheaders', 'nanoc/nanoc', 'expertiza/expertiza', 'asciidoctor/asciidoctor', 'rubber/rubber', 'openMF/mifosx', 'mybatis/mybatis-3', 'test-kitchen/test-kitchen', 'owlcs/owlapi', 'engineyard/engineyard-serverside', 'selendroid/selendroid', 'ruboto/ruboto', 'openfoodfoundation/openfoodnetwork', 'stephanenicolas/robospice', 'joscha/play-authenticate', 'undera/jmeter-plugins', 'cantino/huginn', 'resque/resque', 'albertlatacz/java-repl', 'l0rdn1kk0n/wicket-bootstrap', 'dynjs/dynjs', 'abarisain/dmix', 'dropwizard/dropwizard', 'dropwizard/metrics', 'jberkel/sms-backup-plus', 'rubymotion/sugarcube', 'naver/yobi', 'Shopify/active_shipping', 'projecthydra/sufia', 'rubymotion/BubbleWrap', 'pivotal-sprout/sprout-osx-apps', 'chef/omnibus', 'JodaOrg/joda-time', 'EmmanuelOga/ffaker', 'kostya/eye', 'laurentpetit/ccw', 'puniverse/quasar', 'simpligility/android-maven-plugin', 'jsonld-java/jsonld-java', 'travis-ci/travis-cookbooks', 'FenixEdu/fenixedu-academic', 'threerings/playn', 'restlet/restlet-framework-java', 'jedi4ever/veewee', 'sensu/sensu-community-plugins', 'OpenRefine/OpenRefine', 'chef/chef', 'fluent/fluentd', 'perwendel/spark', 'joelittlejohn/jsonschema2pojo', 'jOOQ/jOOQ', 'springside/springside4', 'github/hub', 'johncarl81/parceler', 'discourse/onebox', 'julianhyde/optiq', 'ruby-ldap/ruby-net-ldap', 'DSpace/DSpace', 'jeremyevans/sequel', 'bikeindex/bike_index', 'doanduyhai/Achilles', 'rackerlabs/blueflood', 'rodjek/librarian-puppet', 'p6spy/p6spy', 'square/wire', 'Nodeclipse/nodeclipse-1', 'rebelidealist/stripe-ruby-mock', 'checkstyle/checkstyle', 'elastic/logstash', 'airlift/airlift', 'lenskit/lenskit', 'MiniProfiler/rack-mini-profiler', 'geoserver/geoserver', 'ocpsoft/rewrite', 'Unidata/thredds', 'torakiki/pdfsam', 'loopj/android-async-http', 'feedbin/feedbin', 'recruit-tech/redpen', 'brettwooldridge/HikariCP', 'puppetlabs/marionette-collective', 'iipc/openwayback', 'caelum/vraptor4', 'dianping/cat', 'jphp-compiler/jphp', 'mockito/mockito', 'oblac/jodd', 'facebook/buck', 'facebook/presto', 'jpos/jPOS', 'hamstergem/hamster', 'mongodb/morphia', 'realestate-com-au/pact', 'inaturalist/inaturalist', 'jtwig/jtwig', 'go-lang-plugin-org/go-lang-idea-plugin', 'square/picasso', 'voltrb/volt', 'zxing/zxing', 'openaustralia/morph', 'GlowstoneMC/Glowstone', 'owncloud/android', 'JakeWharton/u2020', 'rpush/rpush', 'OneBusAway/onebusaway-android', 'rabbit-shocker/rabbit', 'azkaban/azkaban', 'relayrides/pushy', 'deeplearning4j/deeplearning4j', 'github/developer.github.com', 'xetorthio/jedis', 'FasterXML/jackson-core', 'FasterXML/jackson-databind', 'protostuff/protostuff', 'atmos/heaven', 'MrTJP/ProjectRed', 'lemire/RoaringBitmap', 'apache/drill', 'Kapeli/cheatsheets', 'gradle/gradle', 'OpenGrok/OpenGrok', 'spring-io/sagan', 'mendhak/gpslogger', 'thoughtbot/hound', 'teamed/qulice', 'jcabi/jcabi-aspects', 'jcabi/jcabi-github', 'jcabi/jcabi-http', 'yegor256/rultor', 'querydsl/querydsl', 'codevise/pageflow', 'grails/grails-core', 'weld/core', 'thatJavaNerd/JRAW', 'bndtools/bnd', 'igniterealtime/Openfire', 'zendesk/samson', 'bndtools/bndtools', 'xtreemfs/xtreemfs', 'puniverse/capsule', 'broadinstitute/picard', 'github/github-services', 'gavinlaking/vedeu', 'haiwen/seadroid', 'AChep/AcDisplay', 'GoClipse/goclipse', 'hsz/idea-gitignore', 'jsprit/jsprit', 'dblock/waffle', 'numenta/htm.java', 'rightscale/praxis', 'google/error-prone', 'datastax/ruby-driver', 'iluwatar/java-design-patterns', 'Netflix/Hystrix', 'oyachai/HearthSim', 'jayway/JsonPath', 'exteso/alf.io', 'spring-cloud/spring-cloud-config', 'validator/validator', 'HubSpot/jinjava', 'connectbot/connectbot', 'google/physical-web', 'myui/hivemall', 'MarkUsProject/Markus', 'jMonkeyEngine/jmonkeyengine', 'davidmoten/rxjava-jdbc', 'qos-ch/logback', 'Homebrew/homebrew-science', 'GoogleCloudPlatform/DataflowJavaSDK', 'SoftInstigate/restheart', 'naver/pinpoint', 'KronicDeth/intellij-elixir', 'embulk/embulk', 'loomio/loomio', 'openstreetmap/openstreetmap-website', 'activescaffold/active_scaffold', 'tananaev/traccar', 'SonarSource/sonarqube', 'grpc/grpc-java', 'psi-probe/psi-probe', 'orientation/orientation', 'square/keywhiz', 'aws/aws-sdk-java', 'Shopify/shipit-engine', 'perfectsense/brightspot-cms', 'jamesagnew/hapi-fhir']

failure_remain=[]
build_remain=[]

for nameindex in range(len(project_names)):
    file_name = project_names[nameindex] + ".csv"
    file_name = file_name.split("/")[1]
    print(file_name)

    string = "/Users/jinxianhao/Documents/src/python/CI/Data_Base/all_dataset/" + file_name
    csv_file = csv.reader(open(string, 'r'))
    pre = []
    final = []
    for item in csv_file:
        pre.append(item)

    for i in range(len(pre[0])):
        temp = []
        for index in range(1, len(pre)):
            # print(index)
            # print(pre[index][i])
            temp.append(pre[index][i])
        final.append(temp)
    print(len(final[33]))

    indices = []
    for index in range(len(final[33])):
        if final[33][index] == 'passed':
            indices.append(index)
        else:
            #if final[33][index - 1] == 'passed':
                indices.append(index)

    src_churn=[]
    file_churn=[]
    test_churn=[]
    build_result=[]
    team_size=[]
    git_num_all_built_commits=[]
    gh_num_commits_on_files_touched=[]
    argument=[]
    for index in indices:
        #'''
        tmp_line = 0
        tmp_file = 0
        tmp_test = 0
        tmp_commit = 0
        temp = index - 1

        while (final[42][temp - 1] != 'passed'):
            temp = temp - 1
            if temp <= 0:
                break
        # print(temp)

        for index1 in range(temp, index + 1):
            # print(float(final[23][index1]))
            tmp_line = tmp_line + float(final[23][index1])
            tmp_file = tmp_file + float(final[30][index1])
            tmp_test = tmp_test + float(final[24][index1])
            tmp_commit = tmp_commit + float(final[16][index1])


        src_churn.append(tmp_line)
        file_churn.append(tmp_file)
        test_churn.append(tmp_test)
        git_num_all_built_commits.append(tmp_commit)
        '''

        src_churn.append(float(final[23][index]))
        file_churn.append(float(final[30][index]))
        test_churn.append(float(final[24][index]))
        git_num_all_built_commits.append(float(final[16][index]))
        #gh_num_commits_on_files_touched.append(float(final[33][index]))
        #'''
        argument.append([])

    for item in indices:
        if final[42][item] == 'passed':
            build_result.append(1)
        else:
            build_result.append(0)

    #print((git_num_all_built_commits))
    #print(build_result)


    gaussian = []
    for index in range(len(build_result)):
        temp = 0
        if 0 not in build_result[0:index]:
            gaussian.append(temp)
        else:
            for index1 in range(len(build_result[0:index])):
                if build_result[index1] == 0:
                    ft = index - index1
                    gscore = 1 / (3 * math.sqrt(2 * math.pi)) * math.exp(-ft * ft / 18)
                    temp = temp + gscore
            gaussian.append(int(temp * 100))

    last_status=[]
    last_status.append(1)
    for index in range(len(build_result)):
        last_status.append(build_result[index-1])

    for index in range(len(src_churn)):
        argument[index].append(src_churn[index])
        argument[index].append(file_churn[index])
        argument[index].append(test_churn[index])
        #argument[index].append(team_size[index])
        argument[index].append(git_num_all_built_commits[index])
        #argument[index].append(last_status[index])
        #argument[index].append(gh_num_commits_on_files_touched[index])
        #argument[index].append(gaussian[index])
    #print(sum(argument))
    #print(build_result)
    X = np.array(argument)
    Y = np.array(build_result)
    #print(Y)
    #print('aaaa')
    KF = KFold(n_splits=8)  # 建立4折交叉验证方法  查一下KFold函数的参数
    more=0
    less=0
    yes=0
    num_feature=4
    middle_failures=0
    last_failures=0

    num_build = 0
    num_test = 0
    print('start')

    for train_index, test_index in KF.split(X):
        #print("TRAIN:", train_index, "TEST:", test_index)
        X_train, X_test = X[train_index], X[test_index]
        Y_train, Y_test = Y[train_index], Y[test_index]
        #print(X_train, X_test)
        #print(Y_train, Y_test)
        #print(Y_test)
        X_train = X_train.reshape((int(len(X_train)), num_feature))
        rf = RandomForestClassifier()  # 这里使用了默认的参数设置
        predictor = rf.fit(X_train, Y_train)

        #print('aaaaaaaaaaaaaaaaa')
        #print(Y_test)
        new_build=X_test[0]
        flag=0
        line=0
        file=0
        test=0
        commit=0
        results=[]
        fail=0
        #print(X_test)
        num_test = num_test + len(Y_test)

        for index in range(len(X_test)):
            if fail==1:
                num_build = num_build + 1
                #new_result=0
                results.append(Y_test[index])
                fail=Y_test[index]
                new_build = X_test[index]
                #print(new_build)
                X_train = X_train.tolist()
                X_train.append(new_build)
                Y_train = Y_train.tolist()
                Y_train.append(Y_test[index])
                X_train = np.array(X_train)
                Y_train = np.array(Y_train)
                #print(X_train)
                X_train = X_train.reshape((int(len(X_train)), num_feature))
                rf = RandomForestClassifier()  # 这里使用了默认的参数设置
                predictor = rf.fit(X_train, Y_train)
            else:
                if index == 0:
                    new_build = new_build.reshape((1, num_feature))
                    new_result = predictor.predict(new_build)
                    # print(New_build[0][0])
                    if new_result[0] == 1:
                        flag = 0
                        line = line + new_build[0][0]
                        file = file + new_build[0][1]
                        test = test + new_build[0][2]
                        commit = commit + new_build[0][3]
                        fail=0
                    else:
                        flag = 1
                        num_build = num_build + 1

                        X_train = X_train.tolist()
                        X_train.append(new_build[0])
                        Y_train = Y_train.tolist()
                        Y_train.append(Y_test[index])
                        X_train = np.array(X_train)
                        Y_train = np.array(Y_train)
                        X_train = X_train.reshape((int(len(X_train)), num_feature))
                        rf = RandomForestClassifier()  # 这里使用了默认的参数设置
                        predictor = rf.fit(X_train, Y_train)
                        fail=1
                if index != 0 and flag == 0:
                    new_line = line + X_test[index][0]
                    new_file = file + X_test[index][1]
                    new_test = test + X_test[index][2]
                    new_commit = commit + X_test[index][3]
                    new_build = []
                    new_build.append(new_line)
                    new_build.append(new_file)
                    new_build.append(new_test)
                    new_build.append(new_commit)
                    new_build = np.array(new_build)

                    # new_build = X_test[index]

                    new_build = new_build.reshape((1, num_feature))
                    new_result = predictor.predict(new_build)
                    if new_result[0] == 1:
                        flag = 0
                        line = new_build[0][0]
                        file = new_build[0][1]
                        test = new_build[0][2]
                        commit = new_build[0][3]
                        fail=0
                    else:
                        flag = 1
                        num_build = num_build + 1
                        X_train = X_train.tolist()
                        X_train.append(new_build[0])
                        Y_train = Y_train.tolist()
                        Y_train.append(Y_test[index])
                        X_train = np.array(X_train)
                        Y_train = np.array(Y_train)
                        X_train = X_train.reshape((int(len(X_train)), num_feature))
                        rf = RandomForestClassifier()  # 这里使用了默认的参数设置
                        predictor = rf.fit(X_train, Y_train)
                        fail=1
                if index != 0 and flag == 1:

                    new_build = X_test[index]
                    new_build = new_build.reshape((1, num_feature))
                    new_result = predictor.predict(new_build)
                    if new_result[0] == 1:
                        flag = 0
                        line = new_build[0][0]
                        file = new_build[0][1]
                        test = new_build[0][2]
                        commit = new_build[0][3]
                        fail=0
                    else:
                        num_build = num_build + 1
                        flag = 1
                        X_train = X_train.tolist()
                        X_train.append(new_build[0])
                        Y_train = Y_train.tolist()
                        Y_train.append(Y_test[index])
                        X_train = np.array(X_train)
                        Y_train = np.array(Y_train)
                        X_train = X_train.reshape((int(len(X_train)), num_feature))
                        rf = RandomForestClassifier()  # 这里使用了默认的参数设置
                        predictor = rf.fit(X_train, Y_train)
                        fail=1
                # print(line)
                results.append(new_result[0])
        #print(results)
        for index in range(len(results)):
            if results[index]==0 and Y_test[index]==0:
                yes=yes+1
            if results[index]==0:
                more=more+1
            if Y_test[index]==0:
                less=less+1

    if less != 0:
        recall0 = yes/less
        if more == 0:
            precision0=1
            #recall.append(yes / less)
        else:
            precision0 = yes / more
            #recall.append(yes / less)
        precision.append(precision0)
        recall.append(recall0)
    build_remain.append(num_build/num_test)

print(sum(recall)/len(recall))
print(sum(build_remain)/len(build_remain))


book = xlwt.Workbook(encoding='utf-8', style_compression=0)
sheet1 = book.add_sheet('precision', cell_overwrite_ok=True)
sheet2 = book.add_sheet('recall', cell_overwrite_ok=True)
sheet3 = book.add_sheet('f-score', cell_overwrite_ok=True)


for index in range(len(precision)):
    sheet1.write(index,0,'new predictor')
    sheet1.write(index,1,precision[index])
    sheet2.write(index, 0, 'new predictor')
    sheet2.write(index,1,recall[index])

#book.save(r'performance.xls')









'''
        for index in range(len(Y_test)):
            if index!= len(Y_test) and Y_test[index]==0 and Y_test[index-1]==0:
                middle_failures=middle_failures+1
            if index==len(Y_test) and Y_test[index]==0:
                middle_failures=middle_failures+1
            if Y_test[index]==1 and Y_test[index-1]==0:
                last_failures=last_failures+1
        #print(Y_test)
        indices = []
        for index in range(len(Y_test)):
            if Y_test[index] == 1:
                indices.append(index)
            else:
                if Y_test[index - 1] == 1:
                    indices.append(index)
                if index==0:
                    indices.append(index)
        New_X_test = []
        New_Y_test = []
        for item in indices:
            New_X_test.append(X_test[item])
            New_Y_test.append(Y_test[item])
        X_test = np.array(New_X_test)
        Y_test= np.array(New_Y_test)
        #print(Y_test)

        X_test = X_test.reshape((int(len(X_test)), num_feature))
        Y_result=(predictor.predict(X_test))
        for index in range(len(Y_result)):
            if Y_result[index]==0 and Y_test[index]==0:
                yes=yes+1
            if Y_result[index] == 0:
                more=more+1
            if Y_test[index] == 0:
                less=less+1
        #print(Y_result)
        #print(Y_test)
    #print(yes)
    #print(more)
    #print(less)
    precision0 = (yes + middle_failures) / (more + middle_failures + last_failures)
    recall0 = (yes + middle_failures) / (less + middle_failures)
    if (precision0+recall0)>0:
        f_score.append( 2 * precision0 * recall0 / (precision0+recall0))
        precision.append( precision0)
        recall.append( recall0)
    else:
        f_score.append(0)
        precision.append(0)
        recall.append(0)

print(len(precision))
print((precision))
print((recall))
print((f_score))

book = xlwt.Workbook(encoding='utf-8', style_compression=0)
sheet1 = book.add_sheet('precision', cell_overwrite_ok=True)
sheet2 = book.add_sheet('recall', cell_overwrite_ok=True)
sheet3 = book.add_sheet('f-score', cell_overwrite_ok=True)


for index in range(len(precision)):
    sheet1.write(index,0,'Ours')
    sheet1.write(index,1,precision[index])
    sheet2.write(index, 0, 'Ours')
    sheet2.write(index,1,recall[index])
    sheet3.write(index, 0, 'Ours')
    sheet3.write(index,1,f_score[index])

book.save(r'performance.xls')
'''

