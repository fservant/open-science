import csv
import numpy as np
import xlwt
import time
import xlrd

book = xlwt.Workbook(encoding='utf-8', style_compression=0)
sheet = book.add_sheet('fail_ratio', cell_overwrite_ok=True)

worksheet = xlrd.open_workbook('fail_ratio.xls')
sheet2 = worksheet.sheet_by_index(0)
project_names = sheet2.col_values(1)


def get_median(data):
    data = sorted(data)
    size = len(data)
    if size % 2 == 0:  # 判断列表长度为偶数
        median = (data[size // 2] + data[size // 2 - 1]) / 2
        data[0] = median
    if size % 2 == 1:  # 判断列表长度为奇数
        median = data[(size - 1) // 2]
        data[0] = median
    return data[0]


#project_names={'rails/rails','openSUSE/open-build-service', 'checkstyle/checkstyle', 'fog/fog', 'rapid7/metasploit-framework', 'opal/opal', 'github/linguist', 'dreamhead/moco', 'rubinius/rubinius', 'bbatsov/rubocop', 'yegor256/rultor', 'mbj/mutant', 'facebook/presto', 'languagetool-org/languagetool', 'ging/social_stream', 'SonarSource/sonarqube', 'caelum/vraptor4', 'thoughtbot/hound', 'cloudfoundry/cloud_controller_ng', 'maxcom/lorsource', 'rubygems/rubygems', 'bikeindex/bike_index', 'gradle/gradle', 'pry/pry', 'ManageIQ/manageiq', 'mitchellh/vagrant', 'orbeon/orbeon-forms', 'apache/flink', 'heroku/heroku', 'jruby/jruby', 'spree/spree', 'deeplearning4j/deeplearning4j'}
col=0
#project_names=['checkstyle/checkstyle']
print(project_names)
for name in project_names:
    file_name = name + ".csv"
    file_name = file_name.split("/")[1]
    print(file_name)

    string="C:/Users/15847/OneDrive/Documents/research/src/python/CI/Data_Base/dataset/" + file_name
    csv_file = csv.reader(open(string, 'r'))
    pre = []
    final = []
    for item in csv_file:
        pre.append(item)

    for i in range(len(pre[0])):
        temp = []
        for index in range(1, len(pre)):
            # print(index)
            # print(pre[index][i])
            temp.append(pre[index][i])
        final.append(temp)
    print(len(final[42]))

    timestamp = []
    for item in final[41]:
        tm = time.strptime(item, '%Y-%m-%d %H:%M:%S')
        times = int(time.mktime(tm))
        timestamp.append(times)

    indices = []
    for index in range(len(final[42])):
        if final[42][index]=='failed':
            indices.append(index)

    final_result=[]
    result=[]
    for index in range(1,len(indices)):
        if timestamp[indices[index]] - timestamp[indices[index - 1]]>0:
            result.append(timestamp[indices[index]] - timestamp[indices[index - 1]])
    tmp = result
    record = []
    if len(tmp) != 0:
        mean = sum(tmp) / len(tmp)
        temp = np.array(tmp)
        st = np.std(temp)
        # print(mean)
        for index in range(len(tmp)):
            if tmp[index] >= (mean - 3 * st) and tmp[index] <= (mean + 3 * st):
                final_result.append(result[index])

    #for item in final_result:
    if len(final_result)>0:
        sheet.write(col, 1, name)
        sheet.write(col, 2, get_median(final_result))
        col = col + 1


book.save(r'survival_median.xls')
